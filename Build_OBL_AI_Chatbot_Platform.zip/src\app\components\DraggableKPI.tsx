import { useDrag } from 'react-dnd';
import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';
import { useState, memo } from 'react';

interface DraggableKPIProps {
  id: string;
  title: string;
  value: string | number | React.ReactNode;
  icon: LucideIcon;
  gradient: string;
  index: number;
}

// Memoize to prevent re-renders
export const DraggableKPI = memo(function DraggableKPI({ id, title, value, icon: Icon, gradient, index }: DraggableKPIProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'kpi',
    item: { id },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }), [id]);

  return (
    <motion.div
      ref={drag as any}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        delay: index * 0.05,
        duration: 0.3
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.02, y: -8 }}
      className={'relative overflow-hidden rounded-3xl p-6 cursor-move group ' + (isDragging ? 'opacity-50 scale-95' : 'opacity-100')}
      style={{
        background: `linear-gradient(135deg, ${gradient})`,
        boxShadow: isHovered 
          ? '0 25px 70px rgba(0, 212, 255, 0.4), 0 0 60px rgba(147, 51, 234, 0.3), inset 0 0 40px rgba(255, 255, 255, 0.1)'
          : '0 15px 40px rgba(0, 212, 255, 0.2), 0 0 30px rgba(147, 51, 234, 0.15)',
        transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
      }}
    >
      {/* Multi-layer glass effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/15 to-transparent backdrop-blur-2xl" />
      <div className="absolute inset-0 bg-gradient-to-tl from-black/10 to-transparent" />
      
      {/* Animated border glow */}
      <motion.div 
        className="absolute inset-0 rounded-3xl border border-white/30"
        animate={{
          borderColor: isHovered ? 'rgba(255, 255, 255, 0.5)' : 'rgba(255, 255, 255, 0.3)',
        }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-20 h-20 bg-gradient-to-br from-white/20 to-transparent rounded-3xl" />
      <div className="absolute bottom-0 right-0 w-16 h-16 bg-gradient-to-tl from-white/20 to-transparent rounded-3xl" />
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <motion.div 
            className="p-4 rounded-2xl bg-gradient-to-br from-white/25 to-white/10 backdrop-blur-sm border border-white/20 shadow-2xl relative overflow-hidden"
            whileHover={{ scale: 1.15, rotate: 5 }}
            transition={{ duration: 0.2, type: "spring", stiffness: 300 }}
            style={{
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3), inset 0 0 20px rgba(255, 255, 255, 0.1)',
            }}
          >
            {/* Icon glow */}
            <motion.div
              className="absolute inset-0 blur-xl"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.3)' }}
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.3, 0.5, 0.3],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            />
            <Icon className="w-7 h-7 text-white drop-shadow-lg relative z-10" />
          </motion.div>
          
          {/* Multiple animated particles */}
          <div className="flex gap-1">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-1.5 h-1.5 bg-white rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.3, 1, 0.3],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: i * 0.2,
                }}
              />
            ))}
          </div>
        </div>
        
        <motion.div 
          className="text-4xl font-bold text-white mb-2 drop-shadow-2xl"
          animate={isHovered ? { scale: 1.05, textShadow: '0 0 20px rgba(255, 255, 255, 0.8)' } : { scale: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
        >
          {value}
        </motion.div>
        
        <div className="text-sm text-white/95 font-medium tracking-wide uppercase">
          {title}
        </div>

        {/* Enhanced progress bar */}
        <motion.div 
          className="mt-4 h-1.5 rounded-full overflow-hidden relative"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
          initial={{ width: 0 }}
          animate={{ width: '100%' }}
          transition={{ delay: index * 0.1 + 0.3, duration: 0.8 }}
        >
          <motion.div
            className="h-full bg-gradient-to-r from-white/60 via-white/90 to-white/60 rounded-full relative"
            animate={{
              x: ['-100%', '200%'],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "linear",
            }}
          />
          {/* Glow on progress bar */}
          <motion.div
            className="absolute inset-0 blur-sm"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.4)' }}
            animate={{
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          />
        </motion.div>
      </div>

      {/* Enhanced multiple glow effects */}
      <motion.div 
        className="absolute -top-32 -right-32 w-64 h-64 rounded-full blur-3xl"
        style={{ backgroundColor: 'rgba(255, 255, 255, 0.15)' }}
        animate={{
          scale: isHovered ? 1.3 : 1,
          opacity: isHovered ? 0.4 : 0.2,
        }}
        transition={{ duration: 0.5 }}
      />
      
      <motion.div 
        className="absolute -bottom-20 -left-20 w-48 h-48 bg-cyan-400/25 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.15, 1],
          opacity: [0.2, 0.3, 0.2],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div 
        className="absolute top-1/2 left-1/2 w-32 h-32 bg-blue-600/20 rounded-full blur-3xl"
        animate={{
          x: ['-50%', '-40%', '-50%'],
          y: ['-50%', '-60%', '-50%'],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      {/* Enhanced shimmer effect */}
      <motion.div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none"
        style={{
          background: 'linear-gradient(110deg, transparent 25%, rgba(255,255,255,0.3) 50%, transparent 75%)',
        }}
        animate={isHovered ? {
          x: ['-150%', '250%'],
        } : {}}
        transition={{
          duration: 1.2,
          ease: "easeInOut",
        }}
      />

      {/* Floating particles on hover */}
      {isHovered && (
        <>
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-white/60 rounded-full"
              initial={{
                x: Math.random() * 100 + '%',
                y: '100%',
                opacity: 0,
              }}
              animate={{
                y: '-20%',
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: 2,
                delay: i * 0.2,
                repeat: Infinity,
              }}
            />
          ))}
        </>
      )}
    </motion.div>
  );
});