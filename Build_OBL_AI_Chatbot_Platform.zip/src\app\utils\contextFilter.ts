export interface ExcelData {
    [sheetName: string]: any[];
}

export function getRelevantExcelContext(query: string, data: ExcelData): string {
    if (!data) return "No excel data available.";

    const stopWords = new Set(['what', 'when', 'where', 'which', 'who', 'how', 'why', 'the', 'and', 'for', 'that', 'this', 'with', 'from', 'about', 'can', 'you', 'tell', 'show', 'give', 'me', 'some', 'any', 'all', 'details', 'information', 'data', 'please', 'is', 'are', 'was', 'were', 'have', 'has', 'had', 'does', 'do', 'did', 'very', 'much', 'too', 'also', 'just', 'only']);

    // Improved keyword extraction: capture numbers (item codes), and relevant business terms
    const keywords = query.toLowerCase()
        .split(/[\s,]+/) // Don't split by hyphen or dot so we keep codes like EMP-0103 intact
        .filter(k => (k.length >= 3 || /\d/.test(k)) && !stopWords.has(k));

    const relevantContext: any = {};
    const MAX_ROWS_PER_SHEET = 5; // Reduced drastically to fit within the free Groq API key token rate limits

    Object.keys(data).forEach(sheetName => {
        const sheet = data[sheetName];
        if (!Array.isArray(sheet) || sheet.length === 0) return;

        // Schema Sample: Always include headers/first few rows
        const schemaSample = sheet.slice(0, 3);

        // Advanced Search: Look for keyword matches anywhere in the row string (including column headers/keys!)
        const scoredRows = sheet.map(row => {
            const rowValuesString = JSON.stringify(row).toLowerCase();
            // Count how many keywords match this row
            const matchScore = keywords.filter(kw => rowValuesString.includes(kw)).length;

            // Only consider it a match if it contains a highly specific keyword (like an ID) 
            // OR if it matches at least 1 generic keyword
            const hasSpecificMatch = keywords.some(kw => /\d/.test(kw) && rowValuesString.includes(kw));

            return { row, matchScore, hasSpecificMatch };
        });

        // Filter and sort by highest match score first so the AI doesn't miss rows due to the 30-row limit
        const matches = scoredRows
            .filter(item => item.hasSpecificMatch || item.matchScore >= 1)
            .sort((a, b) => b.matchScore - a.matchScore)
            .map(item => item.row);

        if (matches.length > 0) {
            // Priority filtering: take the most relevant matches first
            relevantContext[sheetName] = {
                matchCount: matches.length,
                data: [
                    ...schemaSample,
                    ...matches.slice(0, MAX_ROWS_PER_SHEET)
                ]
            };
        } else if (keywords.some(kw => sheetName.toLowerCase().includes(kw))) {
            // If the sheet name itself matches a keyword, provide more samples
            relevantContext[sheetName] = {
                info: `Sheet name '${sheetName}' matches query. Providing sample rows.`,
                sample: sheet.slice(0, MAX_ROWS_PER_SHEET)
            };
        } else {
            // Minimal schema sample if no match
            relevantContext[sheetName] = {
                info: `Showing schema for '${sheetName}'. No specific row matches found.`,
                sample: schemaSample
            };
        }
    });

    return relevantContext;
}
