import { Configuration, PopupRequest } from '@azure/msal-browser';

/**
 * Microsoft Authentication Configuration
 * 
 * IMPORTANT: To use Microsoft authentication, you need to:
 * 1. Register your application in Azure Portal (https://portal.azure.com)
 * 2. Navigate to "Azure Active Directory" > "App registrations" > "New registration"
 * 3. Set redirect URI to: http://localhost:5173 (for development)
 * 4. Copy the "Application (client) ID" and replace YOUR_CLIENT_ID below
 * 5. Copy the "Directory (tenant) ID" and replace YOUR_TENANT_ID below
 * 
 * For production, update the redirect URI to your production domain
 */

export const msalConfig: Configuration = {
  auth: {
    clientId: 'YOUR_CLIENT_ID', // Replace with your Azure AD application client ID
    authority: 'https://login.microsoftonline.com/YOUR_TENANT_ID', // Replace YOUR_TENANT_ID
    redirectUri: window.location.origin, // Will use current domain
  },
  cache: {
    cacheLocation: 'localStorage', // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },
};

// Add scopes for the resources you want to access
export const loginRequest: PopupRequest = {
  scopes: ['User.Read'], // Request permission to read user profile
};

// Graph API endpoint for getting user information
export const graphConfig = {
  graphMeEndpoint: 'https://graph.microsoft.com/v1.0/me',
};

// Roles that require Microsoft authentication
export const MICROSOFT_AUTH_ROLES = ['ceo', 'india_head', 'zonal_manager'];

// Check if a role requires Microsoft authentication
export function requiresMicrosoftAuth(role: string): boolean {
  return MICROSOFT_AUTH_ROLES.includes(role);
}

// Check if Microsoft authentication is properly configured
export function isMicrosoftAuthConfigured(): boolean {
  return msalConfig.auth.clientId !== 'YOUR_CLIENT_ID' && 
         msalConfig.auth.authority !== 'https://login.microsoftonline.com/YOUR_TENANT_ID';
}