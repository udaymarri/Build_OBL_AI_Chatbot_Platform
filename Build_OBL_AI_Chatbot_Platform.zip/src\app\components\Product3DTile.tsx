import { motion } from 'motion/react';
import { memo } from 'react';

interface Product3DTileProps {
  name: string;
  category: string;
  price: number;
  color: string;
  index: number;
}

// Memoize to prevent unnecessary re-renders
export const Product3DTile = memo(function Product3DTile({ name, category, price, color, index }: Product3DTileProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="relative overflow-hidden rounded-2xl backdrop-blur-xl border border-white/10 p-6 hover:border-white/20 transition-all group"
      style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
      whileHover={{ y: -8 }}
    >
      {/* Simplified 3D Tile - removed continuous rotation for better performance */}
      <div className="w-full h-40 mb-4 flex items-center justify-center perspective-1000">
        <motion.div
          className="w-32 h-32 relative preserve-3d"
          whileHover={{
            rotateY: 20,
            rotateX: 10,
            scale: 1.1,
            transition: { duration: 0.3 }
          }}
        >
          {/* Tile front */}
          <div 
            className="absolute inset-0 rounded-lg shadow-2xl"
            style={{ 
              transform: 'translateZ(10px)',
              backgroundColor: color,
              boxShadow: `0 0 20px ${color}40`
            }} 
          />
          {/* Tile back */}
          <div 
            className="absolute inset-0 rounded-lg opacity-80"
            style={{ 
              transform: 'rotateY(180deg) translateZ(10px)',
              backgroundColor: color
            }} 
          />
          {/* Tile sides */}
          <div 
            className="absolute inset-0 rounded-lg opacity-60"
            style={{ 
              transform: 'rotateY(90deg) translateZ(10px)',
              backgroundColor: color
            }} 
          />
          <div 
            className="absolute inset-0 rounded-lg opacity-60"
            style={{ 
              transform: 'rotateY(-90deg) translateZ(10px)',
              backgroundColor: color
            }} 
          />
        </motion.div>
      </div>

      {/* Product Info */}
      <div className="relative z-10">
        <h3 className="text-lg font-semibold text-white mb-1">{name}</h3>
        <p className="text-sm text-gray-400 mb-3">{category}</p>
        
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-cyan-400">
            <span className="font-extrabold">₹</span>{price}
          </span>
          <span className="text-sm text-gray-500">per sq ft</span>
        </div>
      </div>

      {/* Hover glow effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/0 to-blue-600/0 group-hover:from-cyan-500/10 group-hover:to-blue-600/10 transition-all pointer-events-none" />
    </motion.div>
  );
});