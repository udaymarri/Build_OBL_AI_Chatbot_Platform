import { useEffect, useRef } from 'react';

interface Node3D {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  color: string;
}

export function NetworkBackground3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const nodes: Node3D[] = [];
    const nodeCount = 80;
    const colors = ['#00D4FF', '#06B6D4', '#8B5CF6', '#A855F7', '#EC4899'];

    // Create 3D nodes
    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * 1000 - 500, // -500 to 500 for depth
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        vz: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 3 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    let animationId: number;
    const focalLength = 300;

    const project3D = (node: Node3D) => {
      const scale = focalLength / (focalLength + node.z);
      return {
        x: canvas.width / 2 + (node.x - canvas.width / 2) * scale,
        y: canvas.height / 2 + (node.y - canvas.height / 2) * scale,
        scale: scale,
      };
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update and draw nodes
      nodes.forEach((node, i) => {
        // Update position
        node.x += node.vx;
        node.y += node.vy;
        node.z += node.vz;

        // Wrap around edges
        if (node.x < 0) node.x = canvas.width;
        if (node.x > canvas.width) node.x = 0;
        if (node.y < 0) node.y = canvas.height;
        if (node.y > canvas.height) node.y = 0;
        if (node.z < -500) node.z = 500;
        if (node.z > 500) node.z = -500;

        const projected = project3D(node);
        
        // Draw connections
        nodes.forEach((otherNode, j) => {
          if (i >= j) return;
          
          const dx = node.x - otherNode.x;
          const dy = node.y - otherNode.y;
          const dz = node.z - otherNode.z;
          const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);

          if (distance < 200) {
            const otherProjected = project3D(otherNode);
            const opacity = (1 - distance / 200) * 0.3;
            
            const gradient = ctx.createLinearGradient(
              projected.x,
              projected.y,
              otherProjected.x,
              otherProjected.y
            );
            gradient.addColorStop(0, node.color);
            gradient.addColorStop(1, otherNode.color);

            ctx.strokeStyle = gradient;
            ctx.globalAlpha = opacity;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(projected.x, projected.y);
            ctx.lineTo(otherProjected.x, otherProjected.y);
            ctx.stroke();
          }
        });

        // Draw node with 3D effect
        const nodeSize = node.size * projected.scale;
        
        // Ensure radius is always positive
        const glowRadius = Math.max(0.1, Math.abs(nodeSize * 4));
        const coreRadius = Math.max(0.1, Math.abs(nodeSize));
        
        const gradient = ctx.createRadialGradient(
          projected.x,
          projected.y,
          0,
          projected.x,
          projected.y,
          glowRadius
        );

        gradient.addColorStop(0, node.color);
        gradient.addColorStop(0.5, node.color + '80');
        gradient.addColorStop(1, 'transparent');

        ctx.globalAlpha = Math.abs(projected.scale);
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(projected.x, projected.y, glowRadius, 0, Math.PI * 2);
        ctx.fill();

        // Core glow
        ctx.globalAlpha = Math.abs(projected.scale) * 0.8;
        ctx.fillStyle = node.color;
        ctx.beginPath();
        ctx.arc(projected.x, projected.y, coreRadius, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.globalAlpha = 1;
      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.7 }}
    />
  );
}