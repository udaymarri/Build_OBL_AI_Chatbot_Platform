import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

interface EnhancedChatBubbleProps {
  type: 'user' | 'ai';
  content: string;
  suggestions?: string[];
  onSuggestionClick?: (suggestion: string) => void;
}

export function EnhancedChatBubble({ type, content, suggestions, onSuggestionClick }: EnhancedChatBubbleProps) {
  return (
    <div className={'max-w-[80%] ' + (type === 'user' ? 'ml-auto' : 'mr-auto')}>
      {type === 'ai' && (
        <motion.div 
          className="flex items-center gap-3 mb-3"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <motion.div 
            className="relative w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-500 to-indigo-600 flex items-center justify-center shadow-lg"
            style={{ boxShadow: '0 10px 30px rgba(6, 182, 212, 0.5)' }}
            animate={{
              boxShadow: [
                '0 10px 30px rgba(6, 182, 212, 0.5)',
                '0 10px 30px rgba(59, 130, 246, 0.5)',
                '0 10px 30px rgba(6, 182, 212, 0.5)',
              ],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Sparkles className="w-5 h-5 text-white" />
            <motion.div
              className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400 to-purple-500"
              animate={{
                opacity: [0.5, 0.8, 0.5],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </motion.div>
          <div>
            <span className="text-sm font-semibold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              OBL AI Assistant
            </span>
            <div className="flex gap-1 mt-0.5">
              <motion.div
                className="w-1 h-1 bg-green-400 rounded-full"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
              <span className="text-xs text-gray-500">Online</span>
            </div>
          </div>
        </motion.div>
      )}
      
      <motion.div
        initial={{ opacity: 0, y: 10, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className={'relative rounded-3xl px-6 py-4 group ' + (
          type === 'user'
            ? 'bg-gradient-to-br from-cyan-500 via-blue-500 to-indigo-600 text-white shadow-lg shadow-cyan-500/30'
            : 'bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-2xl border border-white/20 text-gray-100 shadow-xl'
        )}
      >
        {/* Animated border for AI messages */}
        {type === 'ai' && (
          <motion.div
            className="absolute inset-0 rounded-3xl"
            style={{
              background: 'linear-gradient(90deg, rgba(6, 182, 212, 0.5), rgba(147, 51, 234, 0.5), rgba(6, 182, 212, 0.5))',
              backgroundSize: '200% 200%',
            }}
            animate={{
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "linear",
            }}
          />
        )}
        
        {/* Glow effect for user messages */}
        {type === 'user' && (
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-cyan-400/20 to-purple-600/20 blur-xl -z-10" />
        )}
        
        <div className="relative z-10">
          <p className="leading-relaxed whitespace-pre-wrap text-sm md:text-base">
            {content}
          </p>
        </div>

        {/* Shimmer effect */}
        <motion.div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 rounded-3xl overflow-hidden"
          style={{
            background: type === 'user' 
              ? 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)'
              : 'linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)',
          }}
          animate={{
            x: ['-100%', '200%'],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </motion.div>

      {/* Enhanced Suggestions */}
      {suggestions && suggestions.length > 0 && (
        <motion.div 
          className="mt-4 space-y-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <p className="text-xs text-gray-500 font-medium mb-3 flex items-center gap-2">
            <span className="w-1 h-1 bg-cyan-400 rounded-full" />
            Suggested follow-ups:
          </p>
          {suggestions.map((suggestion, idx) => (
            <motion.button
              key={idx}
              onClick={() => onSuggestionClick?.(suggestion)}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + idx * 0.1 }}
              className="group/btn relative block w-full text-left px-5 py-3 rounded-2xl bg-gradient-to-br from-white/5 to-white/0 hover:from-white/10 hover:to-white/5 border border-white/10 hover:border-cyan-500/30 text-sm text-gray-300 transition-all duration-300 overflow-hidden"
              whileHover={{ x: 6, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="relative z-10 flex items-center gap-2">
                <motion.div
                  className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500"
                  animate={{
                    scale: [1, 1.3, 1],
                    opacity: [0.7, 1, 0.7],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: idx * 0.2,
                  }}
                />
                {suggestion}
              </div>
              
              {/* Hover glow effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/10 to-purple-500/0 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300"
                initial={false}
              />
              
              {/* Border animation */}
              <motion.div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover/btn:opacity-100"
                style={{
                  background: 'linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.3), transparent)',
                  backgroundSize: '200% 100%',
                }}
                animate={{
                  backgroundPosition: ['0% 0%', '200% 0%'],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
            </motion.button>
          ))}
        </motion.div>
      )}
    </div>
  );
}