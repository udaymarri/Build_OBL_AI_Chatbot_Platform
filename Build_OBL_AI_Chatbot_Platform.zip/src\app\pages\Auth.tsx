import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  Briefcase,
  Building2,
  MapPin,
  Globe,
  Crown,
  ChevronRight,
  Sparkles,
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
  Loader2,
  Shield,
  UserCheck
} from 'lucide-react';
import { NetworkBackground3D } from '../components/NetworkBackground3D';
import { FloatingShapes3D } from '../components/FloatingShapes3D';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Logo3D } from '../components/Logo3D';
import { toast } from 'sonner';
import { auth, db } from '../lib/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';

const roles = [
  { id: 'salesperson', name: 'Salesperson', description: 'Territory sales & dealer management', color: 'from-blue-500 to-cyan-500', icon: Briefcase, requiresMicrosoft: false },
  { id: 'branch_head', name: 'Branch Head', description: 'Branch operations & team oversight', color: 'from-indigo-600 to-blue-600', icon: Building2, requiresMicrosoft: false },
  { id: 'zonal_manager', name: 'Zonal Manager', description: 'Zone-wide performance tracking', color: 'from-green-500 to-emerald-500', icon: MapPin, requiresMicrosoft: false },
  { id: 'india_head', name: 'India Head', description: 'Regional analytics & strategy', color: 'from-orange-500 to-red-500', icon: Globe, requiresMicrosoft: true },
  { id: 'ceo', name: 'CEO', description: 'Complete enterprise oversight', color: 'from-yellow-500 to-orange-500', icon: Crown, requiresMicrosoft: true },
];

interface UserCredentials {
  email: string;
  password: string;
  name: string;
  role: string;
}

export default function Auth() {
  const [mode, setMode] = useState<'select' | 'signin' | 'signup'>('select');
  const [selectedRole, setSelectedRole] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [pendingAuthUser, setPendingAuthUser] = useState({ name: '', email: '' });
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const navigate = useNavigate();

  // Get stored users from localStorage
  const getStoredUsers = (): UserCredentials[] => {
    const users = localStorage.getItem('obl_users');
    if (!users) {
      // Initialize with demo accounts
      const demoAccounts: UserCredentials[] = [
        { email: 'ceo@orientbell.com', password: 'demo123', name: 'Deepak Malhotra', role: 'ceo' },
        { email: 'indiahead@orientbell.com', password: 'demo123', name: 'Vikram Singh', role: 'india_head' },
        { email: 'zonalmanager@orientbell.com', password: 'demo123', name: 'Amit Patel', role: 'zonal_manager' },
        { email: 'branchhead@orientbell.com', password: 'demo123', name: 'Rajesh Kumar', role: 'branch_head' },
        { email: 'sales@orientbell.com', password: 'demo123', name: 'Priya Sharma', role: 'salesperson' },
      ];
      localStorage.setItem('obl_users', JSON.stringify(demoAccounts));
      return demoAccounts;
    }
    return JSON.parse(users);
  };

  // Save user to localStorage
  const saveUser = (user: UserCredentials) => {
    const users = getStoredUsers();
    users.push(user);
    localStorage.setItem('obl_users', JSON.stringify(users));
  };

  // Find user by email
  const findUser = (email: string): UserCredentials | undefined => {
    const users = getStoredUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase());
  };

  // Validate form
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (mode === 'signup' && !formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (mode === 'signup' && formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (mode === 'signup' && formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle traditional sign in
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsLoading(true);

    try {
      const userCredential = await signInWithEmailAndPassword(auth, formData.email, formData.password);
      const user = userCredential.user;

      // Fetch additional user data from Firestore
      const userDoc = await getDoc(doc(db, 'users', user.uid));

      if (userDoc.exists()) {
        const userData = userDoc.data();

        if (userData.role !== selectedRole) {
          setErrors({ email: `This account is registered as ${roles.find(r => r.id === userData.role)?.name}` });
          setIsLoading(false);
          await auth.signOut();
          return;
        }

        // Success
        localStorage.setItem('userRole', userData.role);
        localStorage.setItem('userName', userData.name || 'User');
        localStorage.setItem('userEmail', user.email || '');
        localStorage.setItem('authMethod', 'traditional');

        toast.success(`Welcome back, ${userData.name}!`);
        setIsLoading(false);
        navigate('/dashboard');
      } else {
        // Handle case where auth exists but firestore record doesn't
        setErrors({ email: 'User profile not found. Please contact support.' });
        setIsLoading(false);
      }
    } catch (error: any) {
      console.error("Firebase Sign In Error:", error);
      let message = "Authentication failed. Please check your credentials.";
      if (error.code === 'auth/user-not-found') message = "Account not found.";
      if (error.code === 'auth/wrong-password') message = "Incorrect password.";

      setErrors({ email: message });
      setIsLoading(false);
    }
  };

  // Handle sign up
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsLoading(true);

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const user = userCredential.user;

      // Save additional user data to Firestore
      const userData = {
        name: formData.name,
        email: formData.email,
        role: selectedRole,
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'users', user.uid), userData);

      // Success
      localStorage.setItem('userRole', userData.role);
      localStorage.setItem('userName', userData.name);
      localStorage.setItem('userEmail', userData.email);
      localStorage.setItem('authMethod', 'traditional');

      toast.success(`Account created! Welcome, ${userData.name}!`);
      setIsLoading(false);
      navigate('/dashboard');
    } catch (error: any) {
      console.error("Firebase Sign Up Error:", error);
      let message = "Account creation failed.";
      if (error.code === 'auth/email-already-in-use') message = "Email already in use.";

      setErrors({ email: message });
      setIsLoading(false);
    }
  };

  // Handle role selection
  const handleRoleSelect = (roleId: string) => {
    setSelectedRole(roleId);
    setMode('signin');
  };

  // Reset form
  const resetForm = () => {
    setFormData({ name: '', email: '', password: '', confirmPassword: '' });
    setErrors({});
    setMode('select');
    setSelectedRole('');
  };

  // Handle Guest Login
  const handleGuestLogin = async () => {
    setIsLoading(true);

    // Simulate quick loading
    await new Promise(resolve => setTimeout(resolve, 800));

    // Set guest user data
    localStorage.setItem('userRole', 'salesperson');
    localStorage.setItem('userName', 'Guest User');
    localStorage.setItem('userEmail', 'guest@demo.com');
    localStorage.setItem('authMethod', 'guest');
    localStorage.setItem('isGuest', 'true');

    toast.success('Welcome, Guest! Exploring as Salesperson role.');
    setIsLoading(false);
    navigate('/dashboard');
  };

  const selectedRoleData = roles.find(r => r.id === selectedRole);

  return (
    <div className="fixed inset-0 w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-900 overflow-y-auto">
      <NetworkBackground3D />
      <FloatingShapes3D />

      {/* Animated Gradient Orbs with more vibrant colors */}
      <motion.div
        className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-cyan-500/20 rounded-full blur-3xl"
        animate={{
          x: [0, 50, 0],
          y: [0, 30, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div
        className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-3xl"
        animate={{
          x: [0, -30, 0],
          y: [0, -50, 0],
          scale: [1, 1.15, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div
        className="absolute top-1/2 left-1/2 w-[400px] h-[400px] bg-indigo-600/15 rounded-full blur-3xl"
        animate={{
          x: [-200, -150, -200],
          y: [-200, -250, -200],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Grid overlay for futuristic effect */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,#000,transparent)]" />

      <div className="relative z-10 min-h-full flex items-center justify-center p-4 sm:p-6 md:p-8">
        <AnimatePresence mode="wait">
          {mode === 'select' ? (
            // Role Selection View
            <motion.div
              key="select"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3 }}
              className="w-full max-w-5xl"
            >
              {/* Header */}
              <div className="text-center mb-8 sm:mb-12">
                <div className="flex justify-center mb-4 sm:mb-6">
                  <Logo3D />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="flex items-center justify-center gap-2 mb-3 sm:mb-4">
                    <Building2 className="w-6 h-6 sm:w-8 sm:h-8 text-cyan-400" />
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                      OBL AI
                    </h1>
                  </div>

                  <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-2">Conversational Intelligence Assistant</p>
                  <p className="text-sm sm:text-base text-gray-500">Powered by Advanced AI for Orientbell Limited</p>
                </motion.div>
              </div>

              {/* Role Selection */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="backdrop-blur-xl border border-white/10 rounded-3xl p-4 sm:p-6 md:p-8"
                style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
              >
                <h2 className="text-xl sm:text-2xl font-semibold text-white mb-6 text-center">
                  Select Your Role to Continue
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {roles.map((role, idx) => (
                    <motion.button
                      key={role.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 + idx * 0.1 }}
                      onClick={() => handleRoleSelect(role.id)}
                      className="group relative overflow-hidden rounded-2xl p-6 text-left transition-all duration-300"
                      whileHover={{
                        y: -8,
                        rotateX: 5,
                        rotateY: 5,
                        transition: { duration: 0.2 }
                      }}
                      whileTap={{ scale: 0.98 }}
                      style={{
                        transformStyle: 'preserve-3d',
                        perspective: 1000,
                      }}
                    >
                      {/* Animated gradient background */}
                      <motion.div
                        className={`absolute inset-0 bg-gradient-to-br ${role.color} opacity-30`}
                        animate={{
                          opacity: [0.3, 0.4, 0.3],
                        }}
                        transition={{
                          duration: 3,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />

                      {/* Glassmorphism layers */}
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-xl" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />

                      {/* Animated neon border */}
                      <motion.div
                        className={`absolute inset-0 rounded-2xl border-2`}
                        style={{
                          borderImage: `linear-gradient(135deg, transparent, rgba(6,182,212,0.5), transparent) 1`,
                        }}
                        animate={{
                          opacity: [0.3, 0.6, 0.3],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />

                      {/* Inner glow on hover */}
                      <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[inset_0_0_60px_rgba(6,182,212,0.3)]" />

                      <div className="relative z-10">
                        {/* Icon with 3D effect and glow */}
                        <motion.div
                          className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${role.color} mb-4 shadow-2xl relative`}
                          whileHover={{
                            scale: 1.1,
                            rotateZ: [0, -5, 5, 0],
                            transition: { duration: 0.5 }
                          }}
                        >
                          <role.icon className="w-6 h-6 text-white relative z-10" />
                          {/* Icon glow */}
                          <div className={`absolute inset-0 bg-gradient-to-br ${role.color} blur-xl opacity-50 rounded-xl`} />
                        </motion.div>

                        <h3 className="text-xl font-semibold text-white mb-2 flex items-center gap-2 group-hover:text-cyan-300 transition-colors">
                          {role.name}
                        </h3>
                        <p className="text-sm text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors">
                          {role.description}
                        </p>
                      </div>

                      {/* Animated arrow */}
                      <motion.div
                        className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                        animate={{
                          x: [0, 5, 0],
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      >
                        <ChevronRight className="w-6 h-6 text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
                      </motion.div>

                      {/* Shine effect on hover */}
                      <motion.div
                        className="absolute inset-0 opacity-0 group-hover:opacity-100"
                        style={{
                          background: 'linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.1) 50%, transparent 100%)',
                        }}
                        animate={{
                          x: ['-100%', '100%'],
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          repeatDelay: 2,
                          ease: "easeInOut"
                        }}
                      />

                      {/* Outer glow on hover */}
                      <div className={`absolute -inset-1 bg-gradient-to-br ${role.color} opacity-0 group-hover:opacity-30 blur-2xl transition-all duration-300 rounded-2xl -z-10`} />
                    </motion.button>
                  ))}
                </div>

                {/* Divider */}
                <div className="relative my-8">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/10"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 text-gray-400 bg-transparent">or</span>
                  </div>
                </div>

                {/* Guest Login Button */}
                <motion.button
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.1 }}
                  onClick={handleGuestLogin}
                  disabled={isLoading}
                  className="group relative w-full overflow-hidden rounded-2xl p-6 transition-all duration-300"
                  whileHover={{
                    y: -4,
                    scale: 1.02,
                    transition: { duration: 0.2 }
                  }}
                  whileTap={{ scale: 0.98 }}
                >
                  {/* Animated gradient background */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-teal-500 opacity-40"
                    animate={{
                      opacity: [0.4, 0.5, 0.4],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />

                  {/* Glassmorphism layers */}
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-xl" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />

                  {/* Animated border */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl border-2 border-emerald-400/50"
                    animate={{
                      borderColor: ['rgba(52, 211, 153, 0.5)', 'rgba(20, 184, 166, 0.7)', 'rgba(52, 211, 153, 0.5)'],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />

                  {/* Inner glow on hover */}
                  <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[inset_0_0_60px_rgba(52,211,153,0.3)]" />

                  <div className="relative z-10 flex items-center justify-center gap-3">
                    {/* Icon */}
                    <motion.div
                      className="inline-flex p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 shadow-2xl relative"
                      whileHover={{
                        scale: 1.1,
                        rotate: [0, -5, 5, 0],
                        transition: { duration: 0.5 }
                      }}
                    >
                      {isLoading ? (
                        <Loader2 className="w-6 h-6 text-white relative z-10 animate-spin" />
                      ) : (
                        <UserCheck className="w-6 h-6 text-white relative z-10" />
                      )}
                      {/* Icon glow */}
                      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-teal-500 blur-xl opacity-50 rounded-xl" />
                    </motion.div>

                    <div className="text-left">
                      <h3 className="text-xl font-bold text-white flex items-center gap-2 group-hover:text-emerald-300 transition-colors">
                        Continue as Guest
                      </h3>
                      <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">
                        Explore the platform without signing in
                      </p>
                    </div>

                    {/* Animated sparkles */}
                    <motion.div
                      className="absolute right-6 opacity-0 group-hover:opacity-100 transition-opacity"
                      animate={{
                        rotate: [0, 360],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "linear"
                      }}
                    >
                      <Sparkles className="w-6 h-6 text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                    </motion.div>
                  </div>

                  {/* Shine effect on hover */}
                  <motion.div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100"
                    style={{
                      background: 'linear-gradient(135deg, transparent 0%, rgba(255,255,255,0.1) 50%, transparent 100%)',
                    }}
                    animate={{
                      x: ['-100%', '100%'],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      repeatDelay: 2,
                      ease: "easeInOut"
                    }}
                  />

                  {/* Outer glow on hover */}
                  <div className="absolute -inset-1 bg-gradient-to-br from-emerald-500 to-teal-500 opacity-0 group-hover:opacity-40 blur-2xl transition-all duration-300 rounded-2xl -z-10" />
                </motion.button>
              </motion.div>

              {/* Guest Info */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2 }}
                className="mt-6 p-4 bg-emerald-500/10 border border-emerald-400/30 rounded-2xl"
              >
                <div className="flex gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-emerald-300">
                    <p className="font-semibold mb-1">Guest Access Available</p>
                    <p className="text-emerald-300/80">
                      Try the platform instantly as a Salesperson with full demo features. No signup required!
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Footer */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="text-center text-gray-500 mt-8 text-sm"
              >
                Enterprise AI Platform • Secure Authentication • Role-Based Access
              </motion.p>
            </motion.div>
          ) : (
            // Authentication Form View
            <motion.div
              key="auth"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="w-full max-w-md"
            >
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8">
                {/* Back Button */}
                <button
                  onClick={resetForm}
                  className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-6"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" />
                  <span className="text-sm">Change Role</span>
                </button>

                {/* Selected Role Badge */}
                {selectedRoleData && (
                  <div className="flex items-center gap-3 mb-6 p-4 bg-white/5 rounded-xl border border-white/10">
                    <div className={`p-2 rounded-lg bg-gradient-to-br ${selectedRoleData.color}`}>
                      <selectedRoleData.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-semibold">{selectedRoleData.name}</p>
                      <p className="text-xs text-gray-400">{selectedRoleData.description}</p>
                    </div>
                  </div>
                )}

                {/* Show info for Microsoft roles */}
                {selectedRoleData?.requiresMicrosoft && (
                  <div className="mb-6 p-4 bg-blue-500/10 border border-blue-400/30 rounded-xl">
                    <div className="flex gap-2">
                      <Shield className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                      <div className="text-sm text-blue-300">
                        <p className="font-semibold mb-1">Multi-Factor Authentication Required</p>
                        <p className="text-blue-300/80">
                          After signing in, you'll need to verify with QR code and OTP.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Sign In/Up Form for ALL roles */}
                <div>
                  {/* Toggle Tabs */}
                  <div className="flex gap-2 mb-6 p-1 bg-white/5 rounded-xl">
                    <button
                      onClick={() => setMode('signin')}
                      className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-all ${mode === 'signin'
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg'
                        : 'text-gray-400 hover:text-white'
                        }`}
                    >
                      Sign In
                    </button>
                    <button
                      onClick={() => setMode('signup')}
                      className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-all ${mode === 'signup'
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg'
                        : 'text-gray-400 hover:text-white'
                        }`}
                    >
                      Sign Up
                    </button>
                  </div>

                  <form onSubmit={mode === 'signin' ? handleSignIn : handleSignUp} className="space-y-4">
                    {/* Name (Sign Up Only) */}
                    {mode === 'signup' && (
                      <div>
                        <Label htmlFor="name" className="text-white mb-2 block">Full Name</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                          <Input
                            id="name"
                            type="text"
                            value={formData.name}
                            onChange={(e) => {
                              setFormData({ ...formData, name: e.target.value });
                              setErrors({ ...errors, name: '' });
                            }}
                            className="pl-10 bg-white/5 border-white/10 text-white h-12"
                            placeholder="Enter your full name"
                          />
                        </div>
                        {errors.name && (
                          <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                            <AlertCircle className="w-4 h-4" />
                            {errors.name}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Email */}
                    <div>
                      <Label htmlFor="email" className="text-white mb-2 block">Email Address</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => {
                            setFormData({ ...formData, email: e.target.value });
                            setErrors({ ...errors, email: '' });
                          }}
                          className="pl-10 bg-white/5 border-white/10 text-white h-12"
                          placeholder="Enter your email"
                        />
                      </div>
                      {errors.email && (
                        <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                          <AlertCircle className="w-4 h-4" />
                          {errors.email}
                        </p>
                      )}
                    </div>

                    {/* Password */}
                    <div>
                      <Label htmlFor="password" className="text-white mb-2 block">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          value={formData.password}
                          onChange={(e) => {
                            setFormData({ ...formData, password: e.target.value });
                            setErrors({ ...errors, password: '' });
                          }}
                          className="pl-10 pr-10 bg-white/5 border-white/10 text-white h-12"
                          placeholder="Enter your password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                      {errors.password && (
                        <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                          <AlertCircle className="w-4 h-4" />
                          {errors.password}
                        </p>
                      )}
                    </div>

                    {/* Confirm Password (Sign Up Only) */}
                    {mode === 'signup' && (
                      <div>
                        <Label htmlFor="confirmPassword" className="text-white mb-2 block">Confirm Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                          <Input
                            id="confirmPassword"
                            type={showPassword ? 'text' : 'password'}
                            value={formData.confirmPassword}
                            onChange={(e) => {
                              setFormData({ ...formData, confirmPassword: e.target.value });
                              setErrors({ ...errors, confirmPassword: '' });
                            }}
                            className="pl-10 bg-white/5 border-white/10 text-white h-12"
                            placeholder="Confirm your password"
                          />
                        </div>
                        {errors.confirmPassword && (
                          <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                            <AlertCircle className="w-4 h-4" />
                            {errors.confirmPassword}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="w-full h-12 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white rounded-xl font-semibold mt-6"
                    >
                      {isLoading ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          {mode === 'signin' ? 'Sign In' : 'Create Account'}
                          <ChevronRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </Button>
                  </form>

                  {/* Info Message */}
                  {mode === 'signup' && (
                    <div className="mt-6 p-4 bg-green-500/10 border border-green-400/30 rounded-xl">
                      <div className="flex gap-2">
                        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                        <div className="text-sm text-green-300">
                          <p className="font-semibold mb-1">Demo Mode</p>
                          <p className="text-green-300/80">
                            Your credentials will be stored locally in your browser for demonstration purposes.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Demo Credentials Helper */}
                  {mode === 'signin' && (
                    <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-400/30 rounded-xl">
                      <div className="flex gap-2">
                        <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                        <div className="text-sm text-yellow-300">
                          <p className="font-semibold mb-2">Demo Credentials Available</p>
                          <div className="space-y-1 font-mono text-xs text-yellow-300/90">
                            <p>All Roles Password: <span className="font-bold">demo123</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}