import { useState } from 'react';
import { excelData } from '../data/excelData';
import { FileText, Database, Package, X } from 'lucide-react';

export function ExcelDataGrid() {
    const [activeTab, setActiveTab] = useState<'SalesOrders' | 'CustomerMaster' | 'PlantDetails'>('SalesOrders');
    const [selectedRow, setSelectedRow] = useState<any | null>(null);

    const tabs = [
        { id: 'SalesOrders', label: 'Sales Orders', icon: FileText, data: excelData.SalesOrders },
        { id: 'CustomerMaster', label: 'Order Line Items', icon: Package, data: excelData.CustomerMaster },
        { id: 'PlantDetails', label: 'Plant Details', icon: Database, data: excelData.PlantDetails },
    ];

    const currentData = tabs.find(t => t.id === activeTab)?.data || [];
    const columns = currentData.length > 0 ? Object.keys(currentData[0]) : [];

    return (
        <div className="w-full h-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-0">
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/20">
                <div>
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Database className="w-5 h-5 text-cyan-400" />
                        Enterprise Data Hub
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">Live data feed from ERP / Excel Source</p>
                </div>

                <div className="flex gap-2">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${activeTab === tab.id
                                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white border border-transparent'
                                }`}
                        >
                            <tab.icon className="w-4 h-4" />
                            {tab.label}
                            <span className="ml-1 text-[10px] bg-black/30 px-1.5 py-0.5 rounded-full">{tab.data.length}</span>
                        </button>
                    ))}
                </div>
            </div>

            <div className="flex-1 overflow-auto custom-scrollbar">
                <table className="w-full text-left text-sm text-gray-300">
                    <thead className="text-xs text-gray-400 uppercase bg-black/40 sticky top-0 z-10 backdrop-blur-md">
                        <tr>
                            {columns.map(col => (
                                <th key={col} className="px-4 py-3 font-semibold tracking-wider whitespace-nowrap">
                                    {col.replace(/([A-Z])/g, ' $1').trim()}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {currentData.slice(0, 100).map((row, i) => (
                            <tr
                                key={`${activeTab}-${i}`}
                                onClick={() => setSelectedRow(row)}
                                className="border-b border-white/5 hover:bg-white/10 transition-colors cursor-pointer animate-in fade-in slide-in-from-bottom-2 duration-500"
                                style={{ animationFillMode: 'both', animationDelay: `${Math.min(i * 20, 500)}ms` }}
                            >
                                {columns.map(col => (
                                    <td key={col} className="px-4 py-3 whitespace-nowrap">
                                        {(row as any)[col]}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
                {currentData.length > 100 && (
                    <div className="p-3 text-center text-xs text-gray-500 bg-black/20">
                        Showing first 100 rows of {currentData.length} total records.
                    </div>
                )}
            </div>

            {/* Detail Modal */}
            {selectedRow && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
                    <div
                        className="bg-gray-900 border border-white/10 rounded-2xl p-6 shadow-2xl relative max-w-2xl w-full max-h-[80vh] flex flex-col animate-in zoom-in-95 duration-200"
                    >
                        <button
                            onClick={() => setSelectedRow(null)}
                            className="absolute top-4 right-4 p-2 rounded-full hover:bg-white/10 transition-colors text-gray-400 hover:text-white"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
                            <FileText className="w-5 h-5 text-cyan-400" />
                            Record Details
                        </h3>

                        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 pb-2">
                            <div className="grid grid-cols-2 gap-4">
                                {Object.entries(selectedRow).map(([key, value]) => (
                                    <div key={key} className="bg-white/5 border border-white/5 rounded-xl p-4">
                                        <div className="text-xs text-gray-400 font-medium mb-1 uppercase tracking-wider">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                                        <div className="text-sm text-gray-100 font-semibold break-words">
                                            {String(value)}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
