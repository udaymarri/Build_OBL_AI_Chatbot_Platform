import { salesData, dealers, getKPIData, getSalesRecommendations, getVisitRecommendations, schemes, sapMaterials, sapSalesOrders } from '../data/mockData';

// Groq API Configuration
const GROQ_API_KEY = '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';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

export interface AIResponse {
  text: string;
  chart?: {
    type: 'line' | 'bar' | 'table';
    data: any[];
    title: string;
  };
  suggestions?: string[];
}

export async function callGrokAPI(query: string, userRole: string, contextData: string): Promise<string> {
  try {
    console.log(`[OBL AI] Processing query: "${query}" for role: ${userRole}`);

    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        messages: [
          {
            role: 'system',
            content: `You are OBL AI, the elite enterprise conversational intelligence assistant for Orientbell Limited (OBL). 
You are currently assisting a user with the role: **${userRole}**. 

**CORE MISSION:**
Provide precise, data-driven, and actionable business intelligence based **ONLY** on the exact text of the context data provided below. 

**STRICT DATA RULE:**
1. YOU MUST NOT hallucinate, invent, or bring in any outside knowledge. 
2. If the user asks a question and the exact answer is NOT present within the provided \`CONTEXT DATA\` block, you MUST reply: "I do not have enough data in my current context to answer that accurately."
3. Every figure, metric, product, order, and dealer you mention MUST exist verbatim in the \`CONTEXT DATA\`. 
4. DO NOT attempt to answer questions using general industry knowledge. Your world is limited strictly to the JSON context below.

**DATA SOURCE MAPPING:**
- **Dealers**: Found in 'dealers' array or 'CustomerMaster' sheet of 'excelDatabase'. Focus on 'salesPotential', 'outstandingAmount', and 'lastPurchase'. 
- **Orders & Materials**: Found in 'orders', 'materials' or 'SalesOrders' / 'PlantDetails' sheets in 'excelDatabase'. Focus on quantities and line totals.
- **Excel Database**: This is a direct dump from our ERP. If queries mention specific transaction IDs or items, ONLY pull from the 'excelDatabase' node. 

**OUTPUT PROTOCOL:**
1. **Clarity**: Use bullet points and precise numbers. NO full markdown tables unless explicitly asked.
2. **Formatting**: Bold crucial figures (e.g., **₹2.5 Cr**, **140 Units**).
3. **Currency**: Always use the ₹ symbol.
4. **Accuracy Verification**: Before outputting a number, verify it appears in the JSON context exactly as written.

**CONTEXT DATA (CONSOLIDATED OBL DATABASE):**
${contextData}

Be professional, concise, and strictly stick to the data above. Do not expose internal IDs unless requested.`
          },
          {
            role: 'user',
            content: query
          }
        ],
        model: 'llama-3.3-70b-versatile',
        temperature: 0.1, // Minimum temperature for maximum deterministic accuracy
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('[OBL AI] API Error:', response.status, errorData);

      throw new Error(`Groq API error: ${response.status} - ${errorData.error?.message || response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || 'I apologize, I could not generate a response at this time.';
  } catch (error) {
    console.error('Grok API Error:', error);
    // Fallback to local processing if API fails
    return '';
  }
}

export function aiResponseEngine(query: string, userRole: string): AIResponse {
  const lowerQuery = query.toLowerCase();
  const kpiData = getKPIData(userRole);

  // Outstanding amount query
  if (lowerQuery.includes('outstanding') || lowerQuery.includes('payment') || lowerQuery.includes('dues')) {
    return {
      text: `Based on your current portfolio, your total outstanding amount is ₹${(kpiData.outstanding / 100000).toFixed(2)} Lakhs.\n\nBreakdown:\n- Overdue (>30 days): ₹${((kpiData.outstanding * 0.4) / 100000).toFixed(2)} Lakhs\n- Current (0-30 days): ₹${((kpiData.outstanding * 0.6) / 100000).toFixed(2)} Lakhs\n\nTop 3 dealers with highest outstanding:\n1. Marble Palace Tiles - ₹8.5 Lakhs\n2. Crystal Tiles Co. - ₹4.5 Lakhs\n3. Premium Flooring Solutions - ₹2.8 Lakhs`,
      suggestions: [
        'Show dealers with overdue payments',
        'Generate collection report',
        'Which dealer should I visit for collection?',
      ],
    };
  }

  // Sales growth query
  if (lowerQuery.includes('sales') && (lowerQuery.includes('growth') || lowerQuery.includes('trend') || lowerQuery.includes('month') || lowerQuery.includes('6 month'))) {
    return {
      text: `Here's your sales performance for the last 6 months:\n\nTotal Revenue: ₹${(salesData.reduce((sum, d) => sum + d.revenue, 0) / 10000000).toFixed(2)} Cr\nAverage Monthly Growth: ${(salesData.reduce((sum, d) => sum + d.growth, 0) / salesData.length).toFixed(1)}%\n\nBest Performing Month: December 2025 (₹6.1 Cr, +27% growth)\nTarget Achievement: ${kpiData.targetAchievement}%\n\nThe chart shows a strong upward trend with February 2026 reaching ₹6.7 Cr, which is 8% above target!`,
      chart: {
        type: 'line',
        data: salesData,
        title: 'Sales Growth - Last 6 Months',
      },
      suggestions: [
        'Compare with last year same period',
        'Show top performing products',
        'Which territory is performing best?',
      ],
    };
  }

  // Visit recommendation query
  if (lowerQuery.includes('visit') || lowerQuery.includes('dealer') && lowerQuery.includes('should')) {
    const recommendations = getVisitRecommendations();
    const topDealer = recommendations[0];

    return {
      text: `Based on AI analysis, here are your top visit priorities:\n\n🎯 HIGHEST PRIORITY:\n${topDealer.dealer.name} - ${topDealer.dealer.location}\n• ${topDealer.reason}\n• Sales Potential: ${topDealer.dealer.salesPotential.toUpperCase()}\n• Last Purchase: ₹${(topDealer.dealer.lastPurchase / 100000).toFixed(2)} Lakhs\n• Outstanding: ₹${(topDealer.dealer.outstandingAmount / 100000).toFixed(2)} Lakhs\n\nOther Priority Visits:\n${recommendations.slice(1, 4).map((r, i) => `${i + 2}. ${r.dealer.name} (${r.daysSinceVisit} days)`).join('\n')}`,
      chart: {
        type: 'table',
        data: recommendations.slice(0, 5).map(r => ({
          dealer: r.dealer.name,
          location: r.dealer.location,
          daysSinceVisit: r.daysSinceVisit,
          potential: r.dealer.salesPotential,
          priority: r.priority,
        })),
        title: 'Visit Recommendations',
      },
      suggestions: [
        'Show route optimization for top 5 dealers',
        'What products to showcase to this dealer?',
        'Show dealer purchase history',
      ],
    };
  }

  // Gap selling / upsell opportunities
  if (lowerQuery.includes('gap') || lowerQuery.includes('upsell') || lowerQuery.includes('cross') || lowerQuery.includes('opportunity') || lowerQuery.includes('opportunities')) {
    const dealer = dealers[0]; // Marble Palace Tiles
    const recommendations = getSalesRecommendations(dealer.id);

    return {
      text: `🎯 GAP SELLING OPPORTUNITIES\n\nAnalyzing dealer "${dealer.name}":\n\nCurrently Purchasing:\n${dealer.products.map(p => `✓ ${p}`).join('\n')}\n\nUPSELL OPPORTUNITIES:\n${recommendations.slice(0, 3).map((r, i) =>
        `${i + 1}. ${r.product.name}\n   Category: ${r.product.category}\n   Potential Revenue: ₹${(r.potentialRevenue / 100000).toFixed(2)} Lakhs\n   ${r.reason}`
      ).join('\n\n')}\n\nRecommended Action: Schedule product demo for Marble Series Premium tiles.`,
      suggestions: [
        'Show all dealers with gap opportunities',
        'Generate proposal for Marble Series',
        'Show scheme applicability',
      ],
    };
  }

  // Schemes query
  if (lowerQuery.includes('scheme') || lowerQuery.includes('offer') || lowerQuery.includes('discount')) {
    return {
      text: `🎁 ACTIVE SCHEMES & OFFERS\n\n${schemes.map((s, i) =>
        `${i + 1}. ${s.name}\n   Discount: ${s.discount}% OFF\n   Valid Till: ${new Date(s.validTill).toLocaleDateString()}\n   Applicable On: ${s.applicableOn}`
      ).join('\n\n')}\n\nRecommendation: Festival Bonanza offers best value for Marble Series with 15% discount.`,
      suggestions: [
        'Which dealers are eligible for bulk offer?',
        'Calculate scheme impact on revenue',
        'Send scheme details to dealers',
      ],
    };
  }

  // Target achievement query
  if (lowerQuery.includes('target') || lowerQuery.includes('achievement') || lowerQuery.includes('performance')) {
    return {
      text: `📊 YOUR PERFORMANCE SNAPSHOT\n\nCurrent Month (March 2026):\n• Sales Revenue: ₹${(kpiData.salesRevenue / 100000).toFixed(2)} Lakhs\n• Target Achievement: ${kpiData.targetAchievement}%\n• Visits Completed: ${kpiData.visitCount}\n• Pending Orders: ${kpiData.pendingOrders}\n\nStatus: ${kpiData.targetAchievement >= 90 ? '🟢 ON TRACK' : kpiData.targetAchievement >= 70 ? '🟡 NEEDS ATTENTION' : '🔴 CRITICAL'}\n\nTo achieve 100% target, you need:\n• Additional Revenue: ₹${((kpiData.salesRevenue / kpiData.targetAchievement * 100 - kpiData.salesRevenue) / 100000).toFixed(2)} Lakhs\n• Recommended: Focus on high-potential dealers and gap selling`,
      suggestions: [
        'Show weekly target breakdown',
        'Compare with peer performance',
        'Generate action plan to achieve target',
      ],
    };
  }

  // Product query
  if (lowerQuery.includes('product') || lowerQuery.includes('catalog') || lowerQuery.includes('marble') || lowerQuery.includes('tile')) {
    return {
      text: `📦 ORIENTBELL PRODUCT CATALOG\n\nTop Selling Categories:\n\n1. Marble Series Premium\n   Price: ₹850/sq ft\n   Features: Premium finish, 800x800mm\n\n2. Vitrified Elegance\n   Price: ₹550/sq ft\n   Features: High durability, polished\n\n3. Designer Wall Pro\n   Price: ₹680/sq ft\n   Features: Digital print, 300x600mm\n\n4. Ceramic Classic\n   Price: ₹350/sq ft\n   Features: Economical, versatile\n\n5. Parking Heavy Duty\n   Price: ₹420/sq ft\n   Features: Anti-skid, outdoor use\n\nAll products available with current schemes!`,
      suggestions: [
        'Show product comparison',
        'Which product is best for this dealer?',
        'Show scheme applicability',
      ],
    };
  }

  // KPI / Dashboard query
  if (lowerQuery.includes('kpi') || lowerQuery.includes('dashboard') || lowerQuery.includes('overview')) {
    return {
      text: `📈 YOUR BUSINESS DASHBOARD\n\nKey Performance Indicators:\n\n💰 Sales Revenue: ₹${(kpiData.salesRevenue / 100000).toFixed(2)} Lakhs\n📊 Outstanding: ₹${(kpiData.outstanding / 100000).toFixed(2)} Lakhs\n📦 Pending Orders: ${kpiData.pendingOrders}\n👥 Visit Count: ${kpiData.visitCount}\n🎯 Target Achievement: ${kpiData.targetAchievement}%\n\nAll metrics are updated in real-time from your ERP and CRM systems.`,
      suggestions: [
        'Show detailed sales breakdown',
        'Compare with last month',
        'Export dashboard report',
      ],
    };
  }

  // SAP Material Query
  if (lowerQuery.includes('material') || lowerQuery.includes('item code') || lowerQuery.includes('strategy')) {
    return {
      text: `📦 SAP MATERIAL MASTER DATA\n\nHere are some of the materials from the system:\n\n${sapMaterials.map((m, i) =>
        `${i + 1}. ${m.itemDesc} (${m.itemCode})\n   Plant: ${m.mfgPlant} | Strategy: ${m.strategy} | MTO: ${m.mfgStrategy}\n   Price: ₹${m.listPrice}/${m.unitOfMeasure}`
      ).join('\n\n')}`,
      suggestions: [
        'Show non-retained materials',
        'Which materials have MTO strategy?',
        'Display materials for Plant1',
      ],
    };
  }

  // SAP Sales Order Query
  if (lowerQuery.includes('sales order') || lowerQuery.includes('sap order') || lowerQuery.includes('sap sales')) {
    return {
      text: `📋 SAP SALES ORDERS\n\nRecent sales orders from the system:\n\n${sapSalesOrders.map((o, i) =>
        `${i + 1}. Order ${o.salesOrg}-${o.division} for ${o.customer}\n   Material: ${o.material}\n   Date: ${o.billingDate} | Net Value: ₹${o.netValue} ${o.currency}`
      ).join('\n\n')}`,
      suggestions: [
        'Total sales value from orders',
        'Orders by specific division',
        'Calculate total tax amount',
      ],
    };
  }

  // Default response
  return {
    text: `I can help you with:\n\n📊 Sales Analytics & Growth Trends\n💰 Outstanding Amount & Collections\n👥 Dealer Visit Recommendations\n🎯 Gap Selling Opportunities\n🎁 Active Schemes & Offers\n📦 Product Catalog & Information\n📈 Target Achievement & KPIs\n📦 SAP Material Master Data\n📋 SAP Sales Orders\n\nWhat would you like to explore?`,
    suggestions: [
      'Show SAP Sales Orders',
      'Show SAP Materials',
      'Sales growth last 6 months',
      'Which dealer should I visit?',
    ],
  };
}