import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check } from 'lucide-react';
import { Button } from './ui/button';

interface AvatarSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  currentAvatar: string;
  onSelect: (avatar: string) => void;
  userName: string;
}

const avatarOptions = [
  { id: 'male-premium-royal', gradient: 'from-indigo-600 via-blue-700 to-blue-800', emoji: '👨‍💼', label: 'Royal Executive' },
  { id: 'female-premium-royal', gradient: 'from-blue-600 via-indigo-600 to-blue-700', emoji: '👩‍💼', label: 'Royal Executive' },
  { id: 'male-premium-ocean', gradient: 'from-blue-600 via-cyan-600 to-teal-600', emoji: '👨‍💻', label: 'Ocean Professional' },
  { id: 'female-premium-ocean', gradient: 'from-sky-600 via-blue-600 to-indigo-600', emoji: '👩‍💻', label: 'Ocean Professional' },
  { id: 'male-premium-sunset', gradient: 'from-orange-600 via-red-600 to-rose-600', emoji: '👨‍🔬', label: 'Sunset Leader' },
  { id: 'female-premium-sunset', gradient: 'from-amber-600 via-orange-600 to-red-600', emoji: '👩‍🔬', label: 'Sunset Leader' },
  { id: 'male-premium-emerald', gradient: 'from-green-600 via-emerald-600 to-teal-600', emoji: '👨‍🎓', label: 'Emerald Scholar' },
  { id: 'female-premium-emerald', gradient: 'from-teal-600 via-green-600 to-lime-600', emoji: '👩‍🎓', label: 'Emerald Scholar' },
  { id: 'male-premium-gold', gradient: 'from-yellow-600 via-amber-600 to-orange-600', emoji: '👨‍⚖️', label: 'Gold Elite' },
  { id: 'female-premium-gold', gradient: 'from-amber-600 via-yellow-600 to-orange-600', emoji: '👩‍⚖️', label: 'Gold Elite' },
  { id: 'male-premium-cosmic', gradient: 'from-violet-600 via-purple-600 to-indigo-600', emoji: '👨‍🚀', label: 'Cosmic Voyager' },
  { id: 'female-premium-cosmic', gradient: 'from-fuchsia-600 via-violet-600 to-purple-600', emoji: '👩‍🚀', label: 'Cosmic Voyager' },
];

export function AvatarSelector({ isOpen, onClose, currentAvatar, onSelect, userName }: AvatarSelectorProps) {
  const [selectedAvatar, setSelectedAvatar] = useState(currentAvatar);

  useEffect(() => {
    setSelectedAvatar(currentAvatar);
  }, [currentAvatar]);

  const handleSelect = () => {
    onSelect(selectedAvatar);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative bg-gray-900/95 backdrop-blur-xl border border-white/10 rounded-2xl p-6 w-full max-w-3xl max-h-[80vh] overflow-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Choose Your Avatar</h2>
              <p className="text-sm text-gray-400 mt-1">Select your premium character avatar</p>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="icon"
              className="text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Avatar Grid */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {avatarOptions.map((avatar) => {
              const isSelected = selectedAvatar === avatar.id;
              const baseClasses = 'relative w-full aspect-square rounded-2xl bg-gradient-to-br flex items-center justify-center text-5xl transition-all shadow-lg shadow-purple-500/20';
              const selectedClasses = isSelected 
                ? 'ring-4 ring-cyan-400 ring-offset-2 ring-offset-gray-900'
                : 'group-hover:ring-2 group-hover:ring-white/30';
              
              return (
                <motion.button
                  key={avatar.id}
                  onClick={() => setSelectedAvatar(avatar.id)}
                  className="group relative"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <div className={`${baseClasses} ${avatar.gradient} ${selectedClasses}`}>
                    {avatar.emoji}
                    
                    {/* Check mark for selected */}
                    {isSelected && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-2 -right-2 w-8 h-8 bg-cyan-400 rounded-full flex items-center justify-center shadow-lg"
                      >
                        <svg className="w-5 h-5 text-gray-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </motion.div>
                    )}
                  </div>
                  <p className="text-xs text-gray-400 text-center mt-2 group-hover:text-white transition-colors">
                    {avatar.label}
                  </p>
                </motion.button>
              );
            })}
          </div>

          {/* Preview */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
            <p className="text-sm text-gray-400 mb-3">Preview:</p>
            <div className="flex items-center gap-3">
              <div className={
                'w-16 h-16 rounded-full bg-gradient-to-br ' +
                (avatarOptions.find(a => a.id === selectedAvatar)?.gradient || 'from-indigo-600 via-purple-600 to-pink-600') +
                ' flex items-center justify-center text-4xl shadow-xl shadow-purple-500/30'
              }>
                {avatarOptions.find(a => a.id === selectedAvatar)?.emoji || '👨‍💼'}
              </div>
              <div>
                <p className="text-white font-semibold">{userName}</p>
                <p className="text-gray-400 text-sm">Your profile</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 border-white/10 text-gray-300 hover:bg-white/5"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSelect}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
            >
              Save Avatar
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}