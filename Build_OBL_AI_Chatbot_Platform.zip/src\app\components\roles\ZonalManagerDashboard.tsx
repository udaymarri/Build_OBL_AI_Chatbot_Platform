import { motion } from 'motion/react';
import { Building2, TrendingUp, Users, Target, MapPin, Star } from 'lucide-react';
import { zoneBranches, zoneMarketData } from '../../data/roleFeatures';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend
} from 'recharts';

export function ZonalManagerDashboard() {
  const totalSales = zoneBranches.reduce((sum, b) => sum + b.sales, 0);
  const totalTarget = zoneBranches.reduce((sum, b) => sum + b.target, 0);
  const avgAchievement = (totalSales / totalTarget) * 100;

  const branchComparisonData = zoneBranches.map(b => ({
    name: b.location,
    achievement: ((b.sales / b.target) * 100).toFixed(1),
    sales: b.sales / 10000000,
    target: b.target / 10000000,
  }));

  const marketRadarData = zoneMarketData.map(m => ({
    city: m.city,
    marketShare: m.marketShare,
    growth: m.growth,
    competition: 100 - (m.competitors * 3), // Inverse for visualization
  }));

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Header Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Building2 className="w-5 h-5 text-cyan-400" />
              <span className="text-sm text-gray-400">Total Branches</span>
            </div>
            <p className="text-2xl font-bold text-white">{zoneBranches.length}</p>
            <p className="text-xs text-cyan-400 mt-1">In West Zone</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl border border-green-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-sm text-gray-400">Zone Sales</span>
            </div>
            <p className="text-2xl font-bold text-white">
              <span className="font-extrabold">₹</span> {(totalSales / 10000000).toFixed(1)}Cr
            </p>
            <p className="text-xs text-green-400 mt-1">{avgAchievement.toFixed(1)}% of target</p>
          </div>

          <div className="bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">Total Team</span>
            </div>
            <p className="text-2xl font-bold text-white">
              {zoneBranches.reduce((sum, b) => sum + b.teamSize, 0)}
            </p>
            <p className="text-xs text-blue-400 mt-1">Salespeople</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl border border-orange-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Star className="w-5 h-5 text-orange-400" />
              <span className="text-sm text-gray-400">Avg Rating</span>
            </div>
            <p className="text-2xl font-bold text-white">
              {(zoneBranches.reduce((sum, b) => sum + b.rating, 0) / zoneBranches.length).toFixed(1)}
            </p>
            <p className="text-xs text-orange-400 mt-1">Out of 5.0</p>
          </div>
        </div>

        {/* Branch Comparison Chart */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-cyan-400" />
            Branch Performance Comparison
          </h3>

          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%" key="zonal-branch-comparison">
              <BarChart data={branchComparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" key="grid-branch" />
                <XAxis dataKey="name" stroke="#9CA3AF" key="xaxis-branch" />
                <YAxis stroke="#9CA3AF" key="yaxis-branch" />
                <Tooltip
                  key="tooltip-branch"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
                <Legend key="legend-branch" />
                <Bar dataKey="sales" name="Sales (Cr)" fill="#06B6D4" radius={[8, 8, 0, 0]} key="bar-branch-sales" />
                <Bar dataKey="target" name="Target (Cr)" fill="#9333EA" radius={[8, 8, 0, 0]} key="bar-branch-target" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Branch Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {zoneBranches.map((branch, idx) => {
            const achievement = ((branch.sales / branch.target) * 100).toFixed(1);
            const isOnTrack = parseFloat(achievement) >= 85;

            return (
              <motion.div
                key={branch.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white text-lg">{branch.name}</h4>
                      <p className="text-sm text-gray-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {branch.location}
                      </p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-lg text-xs font-medium ${
                    isOnTrack
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-orange-500/20 text-orange-400'
                  }`}>
                    {achievement}%
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Sales</p>
                    <p className="text-lg font-bold text-white">
                      <span className="font-extrabold">₹</span> {(branch.sales / 10000000).toFixed(1)}Cr
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Target</p>
                    <p className="text-lg font-bold text-gray-300">
                      <span className="font-extrabold">₹</span> {(branch.target / 10000000).toFixed(1)}Cr
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Team Size</p>
                    <p className="text-lg font-bold text-cyan-400">{branch.teamSize}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Rating</p>
                    <p className="text-lg font-bold text-yellow-400 flex items-center gap-1">
                      {branch.rating} <Star className="w-4 h-4 fill-yellow-400" />
                    </p>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      isOnTrack
                        ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                        : 'bg-gradient-to-r from-orange-500 to-red-500'
                    }`}
                    style={{ width: `${Math.min(parseFloat(achievement), 100)}%` }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Market Analysis Radar */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <MapPin className="w-5 h-5 text-purple-400" />
            Zone Market Analysis
          </h3>

          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%" key="zonal-market-radar">
              <RadarChart data={marketRadarData}>
                <PolarGrid stroke="#374151" key="polargrid-radar" />
                <PolarAngleAxis dataKey="city" stroke="#9CA3AF" key="polarangle-radar" />
                <PolarRadiusAxis stroke="#9CA3AF" key="polarradius-radar" />
                <Radar name="Market Share %" dataKey="marketShare" stroke="#06B6D4" fill="#06B6D4" fillOpacity={0.6} key="radar-marketshare" />
                <Radar name="Growth %" dataKey="growth" stroke="#10B981" fill="#10B981" fillOpacity={0.6} key="radar-growth" />
                <Legend key="legend-radar" />
                <Tooltip
                  key="tooltip-radar"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          {/* Market Data Table */}
          <div className="mt-4 grid grid-cols-4 gap-3">
            {zoneMarketData.map((market, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-white/5 border border-white/10">
                <p className="text-sm font-semibold text-white mb-2">{market.city}</p>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Share:</span>
                    <span className="text-cyan-400">{market.marketShare}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Growth:</span>
                    <span className="text-green-400">{market.growth}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Competitors:</span>
                    <span className="text-orange-400">{market.competitors}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}