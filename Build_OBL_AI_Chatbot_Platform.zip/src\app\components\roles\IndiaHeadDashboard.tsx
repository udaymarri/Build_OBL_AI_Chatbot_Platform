import { motion } from 'motion/react';
import { Globe, TrendingUp, MapPin, Package, Users, Award } from 'lucide-react';
import { regionalZones, statePerformance, productCategoryNational } from '../../data/roleFeatures';
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['#06B6D4', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#EC4899'];

export function IndiaHeadDashboard() {
  const totalSales = regionalZones.reduce((sum, z) => sum + z.sales, 0);
  const totalTarget = regionalZones.reduce((sum, z) => sum + z.target, 0);
  const overallAchievement = ((totalSales / totalTarget) * 100).toFixed(1);

  const topStates = [...statePerformance].sort((a, b) => b.sales - a.sales).slice(0, 3);

  const zonePerformanceData = regionalZones.map(z => ({
    name: z.name.replace(' Zone', ''),
    sales: z.sales / 10000000,
    target: z.target / 10000000,
    achievement: z.achievement,
  }));

  const productShareData = productCategoryNational.map(p => ({
    name: p.category.replace(' Tiles', ''),
    value: p.share,
    sales: p.sales / 10000000,
  }));

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Header Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Globe className="w-5 h-5 text-cyan-400" />
              <span className="text-sm text-gray-400">Total Zones</span>
            </div>
            <p className="text-2xl font-bold text-white">{regionalZones.length}</p>
            <p className="text-xs text-cyan-400 mt-1">Pan India coverage</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl border border-green-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-sm text-gray-400">National Sales</span>
            </div>
            <p className="text-2xl font-bold text-white">
              <span className="font-extrabold">₹</span> {(totalSales / 10000000).toFixed(0)}Cr
            </p>
            <p className="text-xs text-green-400 mt-1">{overallAchievement}% achieved</p>
          </div>

          <div className="bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <MapPin className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">Total Branches</span>
            </div>
            <p className="text-2xl font-bold text-white">
              {regionalZones.reduce((sum, z) => sum + z.branches, 0)}
            </p>
            <p className="text-xs text-blue-400 mt-1">Across India</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl border border-orange-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-orange-400" />
              <span className="text-sm text-gray-400">Total Dealers</span>
            </div>
            <p className="text-2xl font-bold text-white">
              {statePerformance.reduce((sum, s) => sum + s.dealers, 0)}
            </p>
            <p className="text-xs text-orange-400 mt-1">Active dealers</p>
          </div>

          <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 backdrop-blur-xl border border-yellow-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-gray-400">Best Zone</span>
            </div>
            <p className="text-xl font-bold text-white">
              {regionalZones.reduce((prev, curr) => prev.achievement > curr.achievement ? prev : curr).name}
            </p>
            <p className="text-xs text-yellow-400 mt-1">Top performer</p>
          </div>
        </div>

        {/* Zone Performance Chart */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Globe className="w-5 h-5 text-cyan-400" />
            Zone-wise Performance Overview
          </h3>

          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%" key="india-zone-performance">
              <ComposedChart data={zonePerformanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" key="grid-india" />
                <XAxis dataKey="name" stroke="#9CA3AF" key="xaxis-india" />
                <YAxis yAxisId="left" stroke="#9CA3AF" label={{ value: 'Crores (₹)', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }} key="yaxis-india-left" />
                <YAxis yAxisId="right" orientation="right" stroke="#9CA3AF" label={{ value: 'Achievement %', angle: 90, position: 'insideRight', fill: '#9CA3AF' }} key="yaxis-india-right" />
                <Tooltip
                  key="tooltip-india"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
                <Legend key="legend-india" />
                <Bar yAxisId="left" dataKey="sales" name="Sales (Cr)" fill="#06B6D4" radius={[8, 8, 0, 0]} key="bar-zone-sales" />
                <Bar yAxisId="left" dataKey="target" name="Target (Cr)" fill="#9333EA" radius={[8, 8, 0, 0]} key="bar-zone-target" />
                <Line yAxisId="right" type="monotone" dataKey="achievement" name="Achievement %" stroke="#10B981" strokeWidth={3} key="line-zone-achievement" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Regional Zones Detail */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {regionalZones.map((zone, idx) => (
            <motion.div
              key={zone.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h4 className="font-semibold text-white text-xl mb-1">{zone.name}</h4>
                  <p className="text-sm text-gray-400">Manager: {zone.manager}</p>
                </div>
                <div className={`px-3 py-1 rounded-lg text-sm font-bold ${
                  zone.achievement >= 95
                    ? 'bg-green-500/20 text-green-400'
                    : zone.achievement >= 85
                    ? 'bg-cyan-500/20 text-cyan-400'
                    : 'bg-orange-500/20 text-orange-400'
                }`}>
                  {zone.achievement}%
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="text-center p-2 rounded-lg bg-white/5">
                  <p className="text-xs text-gray-400 mb-1">Branches</p>
                  <p className="text-lg font-bold text-white">{zone.branches}</p>
                </div>
                <div className="text-center p-2 rounded-lg bg-white/5">
                  <p className="text-xs text-gray-400 mb-1">Sales</p>
                  <p className="text-lg font-bold text-cyan-400">₹{(zone.sales / 10000000).toFixed(0)}Cr</p>
                </div>
                <div className="text-center p-2 rounded-lg bg-white/5">
                  <p className="text-xs text-gray-400 mb-1">Target</p>
                  <p className="text-lg font-bold text-purple-400">₹{(zone.target / 10000000).toFixed(0)}Cr</p>
                </div>
              </div>

              <div className="w-full bg-gray-800 rounded-full h-3 overflow-hidden">
                <div 
                  className={`h-full rounded-full ${
                    zone.achievement >= 95
                      ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                      : zone.achievement >= 85
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600'
                      : 'bg-gradient-to-r from-orange-500 to-red-500'
                  }`}
                  style={{ width: `${zone.achievement}%` }}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* State Performance and Product Category */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top States */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
              <MapPin className="w-5 h-5 text-green-400" />
              Top Performing States
            </h3>

            <div className="space-y-3">
              {topStates.map((state, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-4 rounded-xl bg-white/5 border border-white/10"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-white">{state.state}</h4>
                    <div className="flex items-center gap-2">
                      {idx === 0 && <Award className="w-5 h-5 text-yellow-400 fill-yellow-400" />}
                      <span className="text-green-400 font-bold">+{state.growth}%</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-gray-400 text-xs">Sales</p>
                      <p className="text-white font-semibold">
                        <span className="font-extrabold">₹</span> {(state.sales / 10000000).toFixed(1)}Cr
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Dealers</p>
                      <p className="text-cyan-400 font-semibold">{state.dealers}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Product Category Distribution */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
              <Package className="w-5 h-5 text-purple-400" />
              Product Category Distribution
            </h3>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%" key="india-product-share">
                <PieChart>
                  <Pie
                    data={productShareData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {productShareData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(17, 24, 39, 0.9)',
                      border: '1px solid rgba(255, 255, 255, 0.1)',
                      borderRadius: '8px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-4">
              {productCategoryNational.map((product, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: COLORS[idx] }}
                  />
                  <span className="text-gray-400">{product.category}</span>
                  <span className="text-white font-semibold ml-auto">{product.share}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}