import { dealers } from '../data/mockData';

// Fix for default marker icons in Leaflet
// @ts-ignore
import icon from 'leaflet/dist/images/marker-icon.png';
// @ts-ignore
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

export function LocationMap() {
    // Default center (India)
    const center: [number, number] = [20.5937, 78.9629];

    return (
        <div className="w-full h-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative bg-[#1a1a1a]">
            {typeof window !== 'undefined' && (
                <MapContainer
                    center={center}
                    zoom={5}
                    style={{ height: '100%', width: '100%' }}
                    scrollWheelZoom={true}
                    className="z-0"
                >
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                    />
                    {dealers.map((dealer) => (
                        dealer.latitude && dealer.longitude && (
                            <Marker
                                key={dealer.id}
                                position={[dealer.latitude, dealer.longitude]}
                            >
                                <Popup className="custom-popup">
                                    <div className="p-3 min-w-[280px] text-gray-800 font-sans">
                                        <h3 className="font-bold text-lg text-cyan-600 border-b pb-1 mb-2">{dealer.name}</h3>

                                        <div className="space-y-1.5 text-sm mb-3">

                                            <p className="flex justify-between border-b border-gray-100 pb-1">
                                                <span className="text-gray-500">Address:</span>
                                                <span className="font-medium text-right max-w-[150px] truncate" title={dealer.address}>{dealer.location}</span>
                                            </p>
                                            <p className="flex justify-between border-b border-gray-100 pb-1">
                                                <span className="text-gray-500">Last Purchase:</span>
                                                <span className="font-semibold text-green-600">₹{(dealer.lastPurchase / 100000).toFixed(2)}L</span>
                                            </p>
                                            <p className="flex justify-between border-b border-gray-100 pb-1">
                                                <span className="text-gray-500">Outstanding:</span>
                                                <span className="font-semibold text-red-500">₹{(dealer.outstandingAmount / 100000).toFixed(2)}L</span>
                                            </p>
                                        </div>

                                        <div className="mb-3">
                                            <p className="text-xs text-gray-500 mb-1">Products Carried:</p>
                                            <div className="flex flex-wrap gap-1">
                                                {dealer.products.slice(0, 3).map(p => (
                                                    <span key={p} className="bg-gray-100 border border-gray-200 text-gray-700 text-[10px] px-1.5 py-0.5 rounded-md">
                                                        {p.replace('Series ', '')}
                                                    </span>
                                                ))}
                                                {dealer.products.length > 3 && (
                                                    <span className="bg-gray-100 text-gray-600 text-[10px] px-1.5 py-0.5 rounded-md">+{dealer.products.length - 3}</span>
                                                )}
                                            </div>
                                        </div>

                                        <div className="mt-3 flex justify-between gap-2 border-t pt-2">
                                            <div className={`px-2 py-1 rounded-md text-xs font-semibold text-center flex-1 capitalize ${dealer.salesPotential === 'high' ? 'bg-green-100 text-green-700 border border-green-200' :
                                                dealer.salesPotential === 'medium' ? 'bg-yellow-100 text-yellow-700 border border-yellow-200' :
                                                    'bg-red-100 text-red-700 border border-red-200'
                                                }`}>
                                                {dealer.salesPotential} Potential
                                            </div>
                                            <div className="bg-blue-50 border border-blue-200 text-blue-700 px-2 py-1 rounded-md text-xs font-semibold text-center flex-1">
                                                Visited: {dealer.lastVisit}
                                            </div>
                                        </div>
                                    </div>
                                </Popup>
                            </Marker>
                        )
                    ))}
                </MapContainer>
            )}

            {/* Decorative Overlay */}
            <div className="absolute top-4 right-4 z-[1000] bg-black/60 backdrop-blur-md p-4 rounded-xl border border-white/10 text-white pointer-events-none">
                <h4 className="font-semibold text-cyan-400 mb-1">Live Dealer Map</h4>
                <p className="text-xs text-gray-400">Visualizing {dealers.length} locations</p>
            </div>
        </div>
    );
}
