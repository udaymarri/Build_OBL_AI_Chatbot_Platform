# Sample AI Queries - Quick Reference

Copy and paste these queries into the AI chat to explore different features!

---

## 💰 Outstanding & Payments

```
What is my outstanding amount?
```

```
Show dealers with overdue payments
```

```
Which dealer has the highest outstanding?
```

---

## 📊 Sales Analytics

```
Show sales growth for last 6 months
```

```
What is my sales revenue?
```

```
Compare this month with last month
```

```
Show my target achievement
```

```
How much to achieve 100% target?
```

---

## 👥 Dealer Visits

```
Which dealer should I visit today?
```

```
Show top priority visits
```

```
Dealer visit recommendations
```

```
Who haven't I visited in 15 days?
```

```
Show route optimization for top 5 dealers
```

---

## 🎯 Recommendations

```
Show gap selling opportunities
```

```
Which products can I upsell?
```

```
Show me cross-selling options
```

```
Gap analysis for Marble Palace Tiles
```

```
Which dealers need Marble Series?
```

---

## 🎁 Schemes & Offers

```
What are the active schemes?
```

```
Show current discount offers
```

```
Which dealers qualify for bulk discount?
```

```
Calculate scheme impact on revenue
```

---

## 📦 Products

```
Show product catalog
```

```
What is the price of Marble Series?
```

```
Show all vitrified tiles
```

```
Product comparison
```

```
Which product is best for this dealer?
```

---

## 📈 Performance & KPIs

```
Show my dashboard
```

```
What are my KPIs?
```

```
Show performance overview
```

```
Compare with peer performance
```

```
Weekly target breakdown
```

---

## 📊 Charts & Data

```
Show sales trends
```

```
Generate sales report
```

```
Visual analysis of last quarter
```

```
Show dealer performance table
```

---

## 🔍 Dealer-Specific Queries

```
Show dealer purchase history
```

```
Dealer information for Elite Surfaces
```

```
What products does Marble Palace buy?
```

```
Outstanding for Crystal Tiles Co
```

---

## 🎯 Strategic Insights

```
Which territory is performing best?
```

```
Top performing products
```

```
Seasonal trends analysis
```

```
Market opportunity analysis
```

---

## ⚡ Quick Commands

```
Help
```

```
What can you do?
```

```
Show examples
```

---

## 🎨 Try These Conversational Queries

```
I need to collect payments, who should I visit?
```

```
My boss wants to know why we're behind target
```

```
Recommend a dealer for product demo
```

```
What should I focus on this week?
```

```
Show me my best performing month
```

---

## 📋 Complex Multi-Part Queries

```
Show my sales for last 6 months, then suggest which dealers to visit for gap selling
```

```
What is my outstanding and which dealers can I collect from today?
```

```
Show active schemes and tell me which dealers would be interested
```

---

**Pro Tip**: After each response, click the suggested follow-up questions to continue the conversation naturally!
