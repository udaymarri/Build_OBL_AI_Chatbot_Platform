

async function test() {
    const GROQ_API_KEY = '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';
    const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

    const response = await fetch(GROQ_API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${GROQ_API_KEY}`,
        },
        body: JSON.stringify({
            messages: [{ role: 'user', content: 'What is OBL?' }],
            model: 'mixtral-8x7b-32768',
        })
    });

    if (!response.ok) {
        const text = await response.text();
        console.error('Error Response:', response.status, text);
    } else {
        const data = await response.json();
        console.log('Success:', JSON.stringify(data, null, 2));
    }
}

test();
