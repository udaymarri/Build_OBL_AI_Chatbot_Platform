import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Sparkles, Building2, ChevronRight, Briefcase, Users, MapPin, Globe, Crown } from 'lucide-react';
import { Button } from '../components/ui/button';
import { ParticleBackground } from '../components/ParticleBackground';
import { Logo3D } from '../components/Logo3D';

const roles = [
  { id: 'salesperson', name: 'Salesperson', description: 'Territory sales & dealer management', color: 'from-blue-500 to-cyan-500', icon: Briefcase },
  { id: 'branch_head', name: 'Branch Head', description: 'Branch operations & team oversight', color: 'from-indigo-600 to-blue-600', icon: Building2 },
  { id: 'zonal_manager', name: 'Zonal Manager', description: 'Zone-wide performance tracking', color: 'from-green-500 to-emerald-500', icon: MapPin },
  { id: 'india_head', name: 'India Head', description: 'Regional analytics & strategy', color: 'from-orange-500 to-red-500', icon: Globe },
  { id: 'ceo', name: 'CEO', description: 'Complete enterprise oversight', color: 'from-yellow-500 to-orange-500', icon: Crown },
];

export default function Login() {
  const [selectedRole, setSelectedRole] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (selectedRole) {
      localStorage.setItem('userRole', selectedRole);
      navigate('/dashboard');
    }
  };

  return (
    <div className="fixed inset-0 w-full h-full bg-gradient-to-br from-gray-900 via-black to-gray-900 overflow-y-auto">
      <ParticleBackground />
      
      {/* Gradient Orbs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />

      <div className="relative z-10 min-h-full flex items-center justify-center p-4 sm:p-6 md:p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-5xl"
        >
          {/* Header */}
          <div className="text-center mb-8 sm:mb-12">
            <div className="flex justify-center mb-4 sm:mb-6">
              <Logo3D />
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="flex items-center justify-center gap-2 mb-3 sm:mb-4">
                <Building2 className="w-6 h-6 sm:w-8 sm:h-8 text-cyan-400" />
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                  OBL AI
                </h1>
              </div>
              
              <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-2">Conversational Intelligence Assistant</p>
              <p className="text-sm sm:text-base text-gray-500">Powered by Advanced AI for Orientbell Limited</p>
            </motion.div>
          </div>

          {/* Role Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="backdrop-blur-xl border border-white/10 rounded-3xl p-4 sm:p-6 md:p-8"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
          >
            <h2 className="text-xl sm:text-2xl font-semibold text-white mb-4 sm:mb-6 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-cyan-400" />
              Select Your Role
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {roles.map((role, idx) => (
                <motion.button
                  key={role.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + idx * 0.1 }}
                  onClick={() => setSelectedRole(role.id)}
                  className={`group relative overflow-hidden rounded-2xl p-6 text-left transition-all duration-300 ${
                    selectedRole === role.id
                      ? 'ring-2 ring-cyan-400 scale-105 shadow-lg shadow-cyan-400/30'
                      : 'hover:scale-102'
                  }`}
                  whileHover={{ y: -6, transition: { duration: 0.2 } }}
                  whileTap={{ scale: 0.98 }}
                >
                  {/* Gradient background layer */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${role.color} opacity-25`} />
                  
                  {/* Glassmorphism layer */}
                  <div className="absolute inset-0 bg-black/50 backdrop-blur-md" />
                  
                  {/* Border highlight effect */}
                  <div className="absolute inset-0 rounded-2xl border border-white/10" />
                  
                  <div className="relative z-10">
                    <div className={`inline-flex p-2.5 rounded-xl bg-gradient-to-br ${role.color} mb-4 shadow-lg`}>
                      <role.icon className="w-6 h-6 text-white" />
                    </div>
                    
                    <h3 className="text-xl font-semibold text-white mb-2">{role.name}</h3>
                    <p className="text-sm text-gray-400 leading-relaxed">{role.description}</p>
                  </div>

                  {selectedRole === role.id && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-4 right-4 w-7 h-7 bg-cyan-400 rounded-full flex items-center justify-center shadow-lg shadow-cyan-400/50"
                    >
                      <ChevronRight className="w-4 h-4 text-black font-bold" />
                    </motion.div>
                  )}
                  
                  {/* Hover glow effect */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${role.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300 rounded-2xl`} />
                </motion.button>
              ))}
            </div>

            <Button
              onClick={handleLogin}
              disabled={!selectedRole}
              className="w-full h-14 text-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Enter Dashboard
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </motion.div>

          {/* Footer */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-center text-gray-500 mt-8 text-sm"
          >
            Enterprise AI Platform • Secure • Real-time Analytics • Role-Based Access
          </motion.p>
        </motion.div>
      </div>
    </div>
  );
}