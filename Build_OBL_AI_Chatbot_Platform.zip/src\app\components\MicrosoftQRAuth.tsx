import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Smartphone, Shield, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { useMsal } from '@azure/msal-react';
import { loginRequest, isMicrosoftAuthConfigured } from '../utils/authConfig';
import { toast } from 'sonner';

interface MicrosoftQRAuthProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userEmail: string;
  userName: string;
}

export function MicrosoftQRAuth({ isOpen, onClose, onSuccess, userEmail, userName }: MicrosoftQRAuthProps) {
  const [step, setStep] = useState<'qr' | 'otp' | 'success'>('qr');
  const [otp, setOtp] = useState('');
  const [qrValue, setQrValue] = useState('');
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [timeRemaining, setTimeRemaining] = useState(120); // 2 minutes
  const [useMicrosoftAuth, setUseMicrosoftAuth] = useState(false);
  
  const { instance } = useMsal();

  // Generate QR code and OTP when modal opens
  useEffect(() => {
    if (isOpen) {
      // Generate a random session ID for QR code
      const sessionId = Math.random().toString(36).substring(2, 15);
      const qrData = JSON.stringify({
        type: 'microsoft_auth',
        session: sessionId,
        email: userEmail,
        name: userName,
        timestamp: Date.now(),
      });
      setQrValue(qrData);

      // Generate 6-digit OTP
      const generatedCode = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOTP(generatedCode);
      
      // Reset states
      setStep('qr');
      setOtp('');
      setError('');
      setTimeRemaining(120);

      // Simulate QR scan (for demo purposes, auto-advance after some time)
      // In production, this would be detected via backend
      console.log('Generated OTP:', generatedCode); // For demo purposes
    }
  }, [isOpen, userEmail, userName]);

  // Timer countdown
  useEffect(() => {
    if (isOpen && step === 'qr' && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isOpen, step, timeRemaining]);

  // Simulate QR code scan detection
  const handleQRScanned = () => {
    setStep('otp');
  };

  // Verify OTP
  const handleVerifyOTP = async () => {
    setIsVerifying(true);
    setError('');

    // Simulate verification delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Debug logs
    console.log('Entered OTP:', otp);
    console.log('Generated OTP:', generatedOTP);
    console.log('OTP Match:', otp === generatedOTP);
    console.log('OTP Length:', otp.length);

    if (otp === generatedOTP) {
      setStep('success');
      // Proceed with Microsoft authentication
      setTimeout(() => {
        onSuccess();
      }, 2000);
    } else {
      setError(`Invalid OTP. Please try again. (Expected: ${generatedOTP})`);
      setOtp('');
    }
    setIsVerifying(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] bg-gradient-to-br from-slate-900 via-blue-900/30 to-purple-900/30 border-white/10 text-white overflow-hidden">
        {/* Animated background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full">
            <motion.div
              className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.5, 0.3],
              }}
              transition={{ duration: 4, repeat: Infinity }}
            />
            <motion.div
              className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl"
              animate={{
                scale: [1.2, 1, 1.2],
                opacity: [0.5, 0.3, 0.5],
              }}
              transition={{ duration: 4, repeat: Infinity }}
            />
          </div>
        </div>

        <div className="relative z-10">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent flex items-center gap-2">
              <Shield className="w-6 h-6 text-cyan-400" />
              Microsoft Multi-Factor Authentication
            </DialogTitle>
            <DialogDescription className="text-gray-300">
              Secure your account with two-step verification
            </DialogDescription>
          </DialogHeader>

          <AnimatePresence mode="wait">
            {/* Step 1: QR Code Scan */}
            {step === 'qr' && (
              <motion.div
                key="qr-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="py-6 space-y-6"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="bg-white p-4 rounded-2xl shadow-2xl">
                    {qrValue && (
                      <QRCodeSVG
                        value={qrValue}
                        size={200}
                        level="H"
                        includeMargin={true}
                      />
                    )}
                  </div>
                  
                  <div className="text-center space-y-2">
                    <div className="flex items-center justify-center gap-2 text-cyan-400">
                      <Smartphone className="w-5 h-5" />
                      <span className="font-medium">Scan with Microsoft Authenticator</span>
                    </div>
                    <p className="text-sm text-gray-400">
                      Open the Microsoft Authenticator app on your mobile device and scan this QR code
                    </p>
                  </div>

                  {/* Timer */}
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                    <span className="text-gray-400">
                      Code expires in: <span className="text-cyan-400 font-mono font-bold">{formatTime(timeRemaining)}</span>
                    </span>
                  </div>

                  {/* Demo OTP Display */}
                  <div className="mt-4 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl space-y-3">
                    <p className="text-xs text-yellow-400 mb-2">🎯 Demo Mode - Use this OTP:</p>
                    <div className="flex items-center justify-center gap-3">
                      <p className="text-2xl font-mono font-bold text-yellow-300 text-center tracking-wider select-all">
                        {generatedOTP}
                      </p>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(generatedOTP);
                          toast.success('OTP copied to clipboard!');
                        }}
                        className="px-3 py-1 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/40 rounded-lg text-xs text-yellow-300 transition-all"
                      >
                        Copy
                      </button>
                    </div>
                    <p className="text-xs text-yellow-400/70 mt-2">
                      To enable real Microsoft auth, configure Azure AD credentials in /src/app/utils/authConfig.ts
                    </p>
                  </div>
                </div>

                <Button
                  onClick={handleQRScanned}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                >
                  I've Scanned the QR Code
                </Button>
              </motion.div>
            )}

            {/* Step 2: OTP Entry */}
            {step === 'otp' && (
              <motion.div
                key="otp-step"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="py-6 space-y-6"
              >
                <div className="flex flex-col items-center space-y-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Smartphone className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="text-center space-y-2">
                    <h3 className="text-xl font-semibold">Enter Verification Code</h3>
                    <p className="text-sm text-gray-400">
                      Enter the 6-digit code from your Microsoft Authenticator app
                    </p>
                    {/* Quick fill button for demo */}
                    <button
                      onClick={() => setOtp(generatedOTP)}
                      className="text-xs text-cyan-400 hover:text-cyan-300 underline mt-2"
                    >
                      🎯 Demo: Auto-fill OTP
                    </button>
                  </div>

                  {/* OTP Input */}
                  <div className="flex justify-center py-4">
                    <div className="flex gap-2">
                      {[0, 1, 2, 3, 4, 5].map((index) => (
                        <input
                          key={index}
                          type="text"
                          maxLength={1}
                          value={otp[index] || ''}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (value.match(/^[0-9]$/)) {
                              const newOtp = otp.split('');
                              newOtp[index] = value;
                              setOtp(newOtp.join(''));
                              setError('');
                              
                              // Auto-focus next input
                              if (index < 5 && value) {
                                const nextInput = e.target.nextElementSibling as HTMLInputElement;
                                nextInput?.focus();
                              }
                            } else if (value === '') {
                              const newOtp = otp.split('');
                              newOtp[index] = '';
                              setOtp(newOtp.join(''));
                            }
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Backspace' && !otp[index] && index > 0) {
                              const prevInput = e.currentTarget.previousElementSibling as HTMLInputElement;
                              prevInput?.focus();
                            }
                          }}
                          className="w-12 h-14 text-2xl text-center bg-white/5 border border-white/20 rounded-lg text-white focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all"
                        />
                      ))}
                    </div>
                  </div>

                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/30 rounded-lg p-3"
                    >
                      {error}
                    </motion.div>
                  )}

                  <div className="text-center text-xs text-gray-500">
                    Didn't receive a code?{' '}
                    <button
                      onClick={() => setStep('qr')}
                      className="text-cyan-400 hover:text-cyan-300 underline"
                    >
                      Generate new QR code
                    </button>
                  </div>
                </div>

                <Button
                  onClick={handleVerifyOTP}
                  disabled={otp.length !== 6 || isVerifying}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 disabled:opacity-50"
                >
                  {isVerifying ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    'Verify & Sign In'
                  )}
                </Button>
              </motion.div>
            )}

            {/* Step 3: Success */}
            {step === 'success' && (
              <motion.div
                key="success-step"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-12 flex flex-col items-center space-y-4"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                >
                  <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-12 h-12 text-white" />
                  </div>
                </motion.div>
                
                <div className="text-center space-y-2">
                  <h3 className="text-2xl font-bold text-green-400">Authentication Successful!</h3>
                  <p className="text-gray-400">Redirecting to your dashboard...</p>
                </div>

                <div className="flex gap-2">
                  <motion.div
                    className="w-2 h-2 bg-green-400 rounded-full"
                    animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-green-400 rounded-full"
                    animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-green-400 rounded-full"
                    animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  );
}