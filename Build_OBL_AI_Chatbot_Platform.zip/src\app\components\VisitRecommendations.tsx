import { motion } from 'motion/react';
import { MapPin, Navigation, Calendar, TrendingUp, ExternalLink, Phone, Mail } from 'lucide-react';
import { getVisitRecommendations } from '../data/mockData';
import { Button } from './ui/button';

export function VisitRecommendations() {
  const recommendations = getVisitRecommendations();

  const openInMaps = (dealer: any) => {
    if (dealer.latitude && dealer.longitude) {
      const url = `https://www.google.com/maps/search/?api=1&query=${dealer.latitude},${dealer.longitude}`;
      window.open(url, '_blank');
    }
  };

  const openDirections = (dealer: any) => {
    if (dealer.latitude && dealer.longitude) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${dealer.latitude},${dealer.longitude}`;
      window.open(url, '_blank');
    }
  };

  const getPriorityColor = (priority: number) => {
    if (priority >= 80) return 'text-red-400 bg-red-500/20 border-red-500/30';
    if (priority >= 60) return 'text-orange-400 bg-orange-500/20 border-orange-500/30';
    return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30';
  };

  const getPriorityLabel = (priority: number) => {
    if (priority >= 80) return 'Urgent';
    if (priority >= 60) return 'High';
    return 'Medium';
  };

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="p-6 pb-4 flex-shrink-0">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Navigation className="w-6 h-6 text-cyan-400" />
          Geo-Based Visit Recommendations
        </h2>
        <p className="text-gray-400 text-sm mt-2">
          AI-powered visit planning with live map integration
        </p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-6">
        <div className="space-y-4">
          {recommendations.map((rec, index) => (
            <motion.div
              key={rec.dealer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-white">{rec.dealer.name}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getPriorityColor(rec.priority)}`}>
                      {getPriorityLabel(rec.priority)} Priority
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                    <MapPin className="w-4 h-4 text-cyan-400" />
                    <span>{rec.dealer.address || rec.dealer.location}</span>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                    <Calendar className="w-4 h-4 text-purple-400" />
                    <span>Last visited {rec.daysSinceVisit} days ago</span>
                    <span className="mx-2">•</span>
                    <TrendingUp className={`w-4 h-4 ${
                      rec.dealer.salesPotential === 'high' ? 'text-green-400' :
                      rec.dealer.salesPotential === 'medium' ? 'text-yellow-400' :
                      'text-orange-400'
                    }`} />
                    <span className="capitalize">{rec.dealer.salesPotential} potential</span>
                  </div>

                  <p className="text-sm text-gray-300 mb-4">
                    {rec.reason}
                  </p>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-white/5 rounded-lg p-3">
                      <p className="text-xs text-gray-400">Last Purchase</p>
                      <p className="text-lg font-bold text-white">
                        <span className="font-extrabold">₹</span> {(rec.dealer.lastPurchase / 100000).toFixed(1)}L
                      </p>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3">
                      <p className="text-xs text-gray-400">Outstanding</p>
                      <p className="text-lg font-bold text-orange-400">
                        <span className="font-extrabold">₹</span> {(rec.dealer.outstandingAmount / 100000).toFixed(1)}L
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Map Actions */}
              <div className="flex gap-3">
                <Button
                  onClick={() => openInMaps(rec.dealer)}
                  className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
                  disabled={!rec.dealer.latitude || !rec.dealer.longitude}
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  View on Map
                  <ExternalLink className="w-3 h-3 ml-2" />
                </Button>
                
                <Button
                  onClick={() => openDirections(rec.dealer)}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-sky-600 hover:from-blue-700 hover:to-sky-700 text-white"
                  disabled={!rec.dealer.latitude || !rec.dealer.longitude}
                >
                  <Navigation className="w-4 h-4 mr-2" />
                  Get Directions
                  <ExternalLink className="w-3 h-3 ml-2" />
                </Button>
              </div>

              {/* Quick Actions */}
              <div className="flex gap-2 mt-3">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-white/10 text-gray-300 hover:bg-white/5"
                >
                  <Phone className="w-3 h-3 mr-1" />
                  Call
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-white/10 text-gray-300 hover:bg-white/5"
                >
                  <Mail className="w-3 h-3 mr-1" />
                  Email
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-white/10 text-gray-300 hover:bg-white/5"
                >
                  Schedule Visit
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}