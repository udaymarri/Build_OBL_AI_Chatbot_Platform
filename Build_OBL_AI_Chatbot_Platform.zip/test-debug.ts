

async function test() {
    const OPENROUTER_API_KEY = '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';
    const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';

    const response = await fetch(OPENROUTER_API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
            'HTTP-Referer': 'http://localhost:5173',
            'X-Title': 'OBL AI Chatbot'
        },
        body: JSON.stringify({
            messages: [{ role: 'user', content: 'What is OBL?' }],
            model: 'google/gemini-2.0-flash-lite-preview-02-05:free',
        })
    });

    if (!response.ok) {
        const text = await response.text();
        console.error('Error Response:', response.status, text);
    } else {
        const data = await response.json();
        console.log('Success:', JSON.stringify(data, null, 2));
    }
}

test();
