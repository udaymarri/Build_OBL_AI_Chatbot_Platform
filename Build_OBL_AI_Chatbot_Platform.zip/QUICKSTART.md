# 🚀 Quick Start Guide - OBL AI

Get started with the OBL AI Conversational Intelligence Assistant in 3 simple steps!

---

## Step 1️⃣: Launch the Application

The application is ready to run! Simply open it in your browser.

---

## Step 2️⃣: Select Your Role

On the **login screen**, you'll see 5 role cards:

| Role | Access Level | Example User |
|------|--------------|--------------|
| 🎯 **Salesperson** | Territory data | Rajesh Kumar |
| 🏢 **Branch Head** | Branch analytics | Priya Sharma |
| 🌏 **Zonal Manager** | Zone-wide metrics | Amit Patel |
| 🇮🇳 **India Head** | Regional insights | Vikram Singh |
| 👔 **CEO** | Complete company view | Deepak Malhotra |

**Choose your role** and click **"Enter Dashboard"**

---

## Step 3️⃣: Start Chatting!

You'll land in the **AI Assistant** view. Try these queries:

### 💬 Your First Questions

**Sales & Revenue:**
```
Show sales growth for last 6 months
```

**Outstanding Payments:**
```
What is my outstanding amount?
```

**Visit Recommendations:**
```
Which dealer should I visit today?
```

**Smart Insights:**
```
Show me gap selling opportunities
```

---

## 🎯 Navigation Overview

### Left Sidebar Menu

| Icon | Section | What You'll Find |
|------|---------|-----------------|
| 🏠 | **Dashboard** | Draggable KPI cards + Analytics |
| 💬 | **AI Assistant** | Natural language chat interface |
| 📈 | **Analytics** | Detailed charts and visualizations |
| 👥 | **Dealers** | Coming soon |
| 📦 | **Products** | Interactive 3D tile showcase |
| 📄 | **Reports** | Coming soon |

---

## ✨ Cool Features to Try

### 1. Drag & Drop KPIs
On the **Dashboard** screen:
- Click and hold any KPI card
- Drag it to reorder
- Release to drop

### 2. 3D Product Models
Go to **Products** section:
- View rotating 3D tiles
- Drag with mouse to spin them
- Hover for glow effects

### 3. Smart Suggestions
After each AI response:
- See **suggested follow-up questions**
- Click any suggestion to continue the conversation

### 4. Quick Actions
In the chat interface:
- Click the **colored action buttons** at the top
- Instant queries for common tasks

---

## 📊 Sample Queries by Category

### 💰 Financial
```
What is my outstanding amount?
Show dealers with overdue payments
```

### 📈 Performance
```
Show my target achievement
How much to reach 100% target?
```

### 👥 Dealers
```
Which dealer should I visit?
Show top priority visits
```

### 🎯 Recommendations
```
Gap selling opportunities
Cross-selling suggestions
```

### 🎁 Schemes
```
What are the active schemes?
Which dealers qualify for bulk discount?
```

---

## 🎨 UI Tips

### Collapsible Sidebar
- Click the **☰ hamburger icon** (top-left) to toggle the sidebar
- More space for chat and analytics

### Live Indicator
- The green **"● Live"** badge shows real-time connection status

### User Profile
- Your avatar and name appear in the sidebar
- Role badge displays your access level

---

## 🆘 Quick Help

### Can't see the sidebar?
**Solution**: Click the ☰ menu icon in the top-left corner

### AI not understanding my question?
**Solution**: Try:
1. Use simpler language
2. Click a suggested query
3. Check the SAMPLE_QUERIES.md file

### Want to change roles?
**Solution**: Click **Logout** in sidebar footer, then select a new role

### Charts not showing?
**Solution**: Ask a specific question like "Show sales for last 6 months"

---

## 🎓 Learn More

| Document | What's Inside |
|----------|---------------|
| **README.md** | Full technical documentation |
| **USER_GUIDE.md** | Detailed user manual |
| **FEATURES.md** | Complete feature list |
| **SAMPLE_QUERIES.md** | 50+ example questions |

---

## 🎯 Recommended Flow

**First-Time Users:**
1. ✅ Select a role (try CEO for full access)
2. ✅ Complete the welcome tutorial (4 steps)
3. ✅ Try the quick action buttons
4. ✅ Ask "Show sales growth for last 6 months"
5. ✅ Click a suggested follow-up
6. ✅ Go to Dashboard and drag a KPI card
7. ✅ Visit Products to see 3D tiles

**Power Users:**
1. ✅ Type complex queries directly
2. ✅ Use keyboard Enter to send
3. ✅ Export charts (Download button)
4. ✅ Explore all 6 navigation sections

---

## 🌟 Pro Tips

💡 **Type naturally** - The AI understands conversational language

💡 **Follow suggestions** - Click the gray suggestion boxes after each answer

💡 **Explore sections** - Each sidebar item has unique content

💡 **Hover for effects** - Cards, buttons, and charts have smooth animations

💡 **Drag to reorder** - KPI cards on Dashboard are repositionable

💡 **Rotate products** - 3D tiles respond to mouse drag

💡 **Check documentation** - 4 guide files available

---

## 🎉 You're All Set!

You now have access to a **premium AI-powered business intelligence platform** with:

✅ Natural language queries
✅ Real-time analytics
✅ Smart recommendations
✅ Interactive 3D graphics
✅ Role-based insights
✅ Beautiful glassmorphism UI

**Start exploring and enjoy the OBL AI experience!** 🚀

---

## 📞 Need Help?

- Check **USER_GUIDE.md** for detailed instructions
- Browse **SAMPLE_QUERIES.md** for query examples
- Review **FEATURES.md** for complete capabilities
- Read **README.md** for technical details

**Happy Chatting!** 💬✨
