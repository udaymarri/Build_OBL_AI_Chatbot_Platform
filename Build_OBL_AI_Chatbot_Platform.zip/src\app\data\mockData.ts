// Mock data for the enterprise chatbot

export interface User {
  id: string;
  name: string;
  role: 'salesperson' | 'branch_head' | 'zonal_manager' | 'india_head' | 'ceo';
  territory?: string;
  branch?: string;
  zone?: string;
}

export interface SalesData {
  month: string;
  revenue: number;
  target: number;
  growth: number;
}

export interface Dealer {
  id: string;
  name: string;
  location: string;
  latitude?: number;
  longitude?: number;
  address?: string;
  lastVisit: string;
  salesPotential: 'high' | 'medium' | 'low';
  lastPurchase: number;
  outstandingAmount: number;
  products: string[];
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  image?: string;
}

export interface VisitLog {
  id: string;
  dealerId: string;
  dealerName: string;
  date: string;
  purpose: string;
  outcome: string;
}

export interface SAPMaterial {
  itemCode: string;
  itemDesc: string;
  mfgPlant: string;
  dispatchLocation: string;
  itemGroup: string;
  sizeDesc: string;
  listPrice: number;
  unitOfMeasure: string;
  strategy: string;
  mfgStrategy: string;
}

export interface SAPSalesOrder {
  salesOrg: string;
  distributionChannel: string;
  division: string;
  salesOffice: string;
  customer: string;
  material: string;
  orderType: string;
  billingDate: string;
  netValue: number;
  taxAmount: number;
  grossValue: number;
  currency: string;
}

export interface Report {
  id: string;
  title: string;
  type: 'Sales' | 'Dealer' | 'Inventory' | 'Finance';
  date: string;
  status: 'Ready' | 'Processing';
  description: string;
}

// Sales data for different time periods
export const salesData: SalesData[] = [
  { month: 'Sep 2025', revenue: 45000000, target: 50000000, growth: 12 },
  { month: 'Oct 2025', revenue: 52000000, target: 55000000, growth: 15.5 },
  { month: 'Nov 2025', revenue: 48000000, target: 53000000, growth: 6.7 },
  { month: 'Dec 2025', revenue: 61000000, target: 60000000, growth: 27 },
  { month: 'Jan 2026', revenue: 58000000, target: 58000000, growth: -5 },
  { month: 'Feb 2026', revenue: 67000000, target: 62000000, growth: 15.5 },
];

// Dealer database
export const dealers: Dealer[] = [
  {
    id: 'D001',
    name: 'Marble Palace Tiles',
    location: 'Mumbai',
    latitude: 19.0760,
    longitude: 72.8777,
    address: 'Andheri East, Mumbai, Maharashtra 400069',
    lastVisit: '2026-02-18',
    salesPotential: 'high',
    lastPurchase: 4500000,
    outstandingAmount: 850000,
    products: ['Ceramic Tiles', 'Vitrified Tiles', 'Wall Tiles'],
  },
  {
    id: 'D002',
    name: 'Elite Surfaces Pvt Ltd',
    location: 'Delhi',
    latitude: 28.7041,
    longitude: 77.1025,
    address: 'Connaught Place, New Delhi, Delhi 110001',
    lastVisit: '2026-03-01',
    salesPotential: 'high',
    lastPurchase: 6200000,
    outstandingAmount: 320000,
    products: ['Vitrified Tiles', 'Parking Tiles'],
  },
  {
    id: 'D003',
    name: 'Crystal Tiles Co.',
    location: 'Bangalore',
    latitude: 12.9716,
    longitude: 77.5946,
    address: 'Koramangala, Bangalore, Karnataka 560034',
    lastVisit: '2026-02-10',
    salesPotential: 'medium',
    lastPurchase: 2100000,
    outstandingAmount: 450000,
    products: ['Wall Tiles', 'Designer Tiles'],
  },
  {
    id: 'D004',
    name: 'Architect XYZ',
    location: 'Mumbai',
    latitude: 19.1136,
    longitude: 72.8697,
    address: 'Bandra West, Mumbai, Maharashtra 400050',
    lastVisit: '2026-02-16',
    salesPotential: 'high',
    lastPurchase: 0,
    outstandingAmount: 0,
    products: [],
  },
  {
    id: 'D005',
    name: 'Premium Flooring Solutions',
    location: 'Chennai',
    latitude: 13.0827,
    longitude: 80.2707,
    address: 'T Nagar, Chennai, Tamil Nadu 600017',
    lastVisit: '2026-02-25',
    salesPotential: 'medium',
    lastPurchase: 1800000,
    outstandingAmount: 280000,
    products: ['Vitrified Tiles', 'Ceramic Tiles'],
  },
];

// Product catalog
export const products: Product[] = [
  { id: 'P001', name: 'Marble Series Premium', category: 'Marble Tiles', price: 850, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/marble_tile_premium_1772851525373.png' },
  { id: 'P002', name: 'Ceramic Classic', category: 'Ceramic Tiles', price: 350, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/ceramic_tile_classic_1772851547882.png' },
  { id: 'P003', name: 'Vitrified Elegance', category: 'Vitrified Tiles', price: 550, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/vitrified_tile_elegance_1772851562388.png' },
  { id: 'P004', name: 'Designer Wall Pro', category: 'Wall Tiles', price: 680, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/wall_tile_designer_1772851579657.png' },
  { id: 'P005', name: 'Parking Heavy Duty', category: 'Parking Tiles', price: 420, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/parking_tile_duty_1772851594198.png' },
  { id: 'P006', name: 'Digital Print Luxury', category: 'Designer Tiles', price: 1200, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/designer_tile_luxury_1772851609567.png' },
  { id: 'P007', name: 'Royal Onyx Marble', category: 'Marble Tiles', price: 950, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/marble_tile_premium_1772851525373.png' },
  { id: 'P008', name: 'Rustic Stone Ceramic', category: 'Ceramic Tiles', price: 380, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/ceramic_tile_classic_1772851547882.png' },
  { id: 'P009', name: 'Nano Polished Vitrified', category: 'Vitrified Tiles', price: 490, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/vitrified_tile_elegance_1772851562388.png' },
  { id: 'P010', name: 'Satin Finish Wall', category: 'Wall Tiles', price: 710, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/wall_tile_designer_1772851579657.png' },
  { id: 'P011', name: 'Anti-Skid Outdoor', category: 'Parking Tiles', price: 450, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/parking_tile_duty_1772851594198.png' },
  { id: 'P012', name: 'Glazed Vitrified Tile', category: 'Vitrified Tiles', price: 1100, image: '/brain/aa3b4d4f-3b87-4126-9bee-e4ec60269396/designer_tile_luxury_1772851609567.png' },
];

// Visit logs
export const visitLogs: VisitLog[] = [
  {
    id: 'V001',
    dealerId: 'D001',
    dealerName: 'Marble Palace Tiles',
    date: '2026-02-18',
    purpose: 'Product Demo - New Marble Series',
    outcome: 'Order placed for 5000 sq ft',
  },
  {
    id: 'V002',
    dealerId: 'D002',
    dealerName: 'Elite Surfaces Pvt Ltd',
    date: '2026-03-01',
    purpose: 'Outstanding collection',
    outcome: 'Partial payment received',
  },
  {
    id: 'V003',
    dealerId: 'D003',
    dealerName: 'Crystal Tiles Co.',
    date: '2026-02-10',
    purpose: 'Scheme discussion',
    outcome: 'Interested in festival offer',
  },
];

// SAP Master Data (Sampled from User Images)
export const sapMaterials: SAPMaterial[] = [
  { itemCode: '010105621810001031M', itemDesc: '300X450 OT4506 B Pcs Prem', mfgPlant: 'Plant2', dispatchLocation: 'PLANT_3', itemGroup: 'Ceramic', sizeDesc: '300X450', listPrice: 196, unitOfMeasure: 'SQ_MT', strategy: 'Retained', mfgStrategy: 'MTO' },
  { itemCode: '010104524100001102M', itemDesc: '300X300 QT4122 15 Pcs Std', mfgPlant: 'Plant1', dispatchLocation: 'PLANT_4', itemGroup: 'Ceramic', sizeDesc: '300X300', listPrice: 748, unitOfMeasure: 'SQ_MT', strategy: 'Non Retained', mfgStrategy: 'MTO' },
  { itemCode: '010105383220758151W', itemDesc: '300X300 Baby Pink Gloss Mosaic 20 Pcs Prem', mfgPlant: 'Plant1', dispatchLocation: 'PLANT_4', itemGroup: 'Ceramic', sizeDesc: '300X300', listPrice: 677, unitOfMeasure: 'SQ_MT', strategy: 'Retained', mfgStrategy: 'MTO' },
  { itemCode: '0101053B3270758151W', itemDesc: '300X300 Matte Aqua Mosaic 20 Pcs Prem', mfgPlant: 'Plant1', dispatchLocation: 'PLANT_4', itemGroup: 'Ceramic', sizeDesc: '300X300', listPrice: 293, unitOfMeasure: 'SQ_MT', strategy: 'Retained', mfgStrategy: 'MTO' },
  { itemCode: '010105607470782032M', itemDesc: '300X450 Luxor Beige OT 4564 8 Pcs Std', mfgPlant: 'Plant2', dispatchLocation: 'PLANT_3', itemGroup: 'Ceramic', sizeDesc: '300X450', listPrice: 757, unitOfMeasure: 'SQ_MT', strategy: 'Non Retained', mfgStrategy: 'Non-Retained' },
  { itemCode: '010105624890791011M', itemDesc: '300X450 Cosmo Sandune OT 4582 6 Pcs Prem', mfgPlant: 'Plant2', dispatchLocation: 'PLANT_3', itemGroup: 'Ceramic', sizeDesc: '300X450', listPrice: 961, unitOfMeasure: 'SQ_MT', strategy: 'Non Retained', mfgStrategy: 'Non-Retained' },
];

export const sapSalesOrders: SAPSalesOrder[] = [
  { salesOrg: '1000', distributionChannel: '10', division: '01', salesOffice: '1010', customer: 'CUST-001', material: '010105621810001031M', orderType: 'OR', billingDate: '2024-02-15', netValue: 15000, taxAmount: 2700, grossValue: 17700, currency: 'INR' },
  { salesOrg: '1000', distributionChannel: '10', division: '01', salesOffice: '1020', customer: 'CUST-002', material: '010104524100001102M', orderType: 'OR', billingDate: '2024-02-18', netValue: 45000, taxAmount: 8100, grossValue: 53100, currency: 'INR' },
  { salesOrg: '2000', distributionChannel: '20', division: '02', salesOffice: '2010', customer: 'CUST-003', material: '010105383220758151W', orderType: 'ZRE', billingDate: '2024-02-20', netValue: 12000, taxAmount: 2160, grossValue: 14160, currency: 'INR' },
  { salesOrg: '1000', distributionChannel: '10', division: '01', salesOffice: '1010', customer: 'CUST-001', material: '010105607470782032M', orderType: 'OR', billingDate: '2024-02-22', netValue: 25000, taxAmount: 4500, grossValue: 29500, currency: 'INR' },
];

// KPI data based on role
export const getKPIData = (role: string) => {
  const baseData = {
    salesperson: {
      salesRevenue: 4200000,
      outstanding: 850000,
      pendingOrders: 8,
      visitCount: 24,
      targetAchievement: 87,
      territory: 'Mumbai West',
    },
    branch_head: {
      salesRevenue: 28500000,
      outstanding: 5200000,
      pendingOrders: 45,
      visitCount: 156,
      targetAchievement: 92,
      branch: 'Mumbai Branch',
    },
    zonal_manager: {
      salesRevenue: 82000000,
      outstanding: 14800000,
      pendingOrders: 128,
      visitCount: 420,
      targetAchievement: 88,
      zone: 'West Zone',
    },
    india_head: {
      salesRevenue: 450000000,
      outstanding: 65000000,
      pendingOrders: 680,
      visitCount: 2100,
      targetAchievement: 91,
      region: 'Pan India',
    },
    ceo: {
      salesRevenue: 1250000000,
      outstanding: 180000000,
      pendingOrders: 1850,
      visitCount: 5800,
      targetAchievement: 94,
      scope: 'Company Wide',
    },
  };

  return baseData[role as keyof typeof baseData] || baseData.salesperson;
};

// Recommendation engine
export const getSalesRecommendations = (dealerId: string) => {
  const dealer = dealers.find(d => d.id === dealerId);
  if (!dealer) return [];

  const allCategories = ['Marble Tiles', 'Ceramic Tiles', 'Vitrified Tiles', 'Wall Tiles', 'Parking Tiles', 'Designer Tiles'];
  const purchasedCategories = dealer.products.map(p => {
    const product = products.find(pr => pr.category.includes(p));
    return product?.category;
  }).filter(Boolean);

  const gapProducts = products.filter(p => !purchasedCategories.includes(p.category));

  return gapProducts.map(p => ({
    product: p,
    reason: `${dealer.name} has not purchased ${p.category}. High upsell opportunity.`,
    potentialRevenue: p.price * 1000,
  }));
};

export const getVisitRecommendations = () => {
  const today = new Date('2026-03-06');

  return dealers.map(dealer => {
    const lastVisitDate = new Date(dealer.lastVisit);
    const daysSinceVisit = Math.floor((today.getTime() - lastVisitDate.getTime()) / (1000 * 60 * 60 * 24));

    let priority = 0;
    if (daysSinceVisit > 15 && dealer.salesPotential === 'high') priority = 90;
    else if (daysSinceVisit > 20) priority = 70;
    else if (dealer.salesPotential === 'high') priority = 60;
    else priority = 40;

    return {
      dealer,
      daysSinceVisit,
      priority,
      reason: daysSinceVisit > 15
        ? `Not visited in ${daysSinceVisit} days with ${dealer.salesPotential} project probability.`
        : `High potential dealer - ${dealer.salesPotential} sales opportunity.`,
    };
  }).sort((a, b) => b.priority - a.priority);
};

// Schemes data
export const schemes = [
  {
    id: 'S001',
    name: 'Festival Bonanza 2026',
    discount: 15,
    validTill: '2026-03-31',
    applicableOn: 'All Marble Series',
  },
  {
    id: 'S002',
    name: 'Bulk Purchase Offer',
    discount: 12,
    validTill: '2026-04-15',
    applicableOn: 'Vitrified Tiles (>5000 sq ft)',
  },
  {
    id: 'S003',
    name: 'Designer Collection Launch',
    discount: 20,
    validTill: '2026-03-20',
    applicableOn: 'New Designer Tiles Range',
  },
];

export const reports: Report[] = [
  { id: 'R001', title: 'Monthly Sales Analysis', type: 'Sales', date: '2026-03-01', status: 'Ready', description: 'Comprehensive breakdown of sales performance across all regions for February 2026.' },
  { id: 'R002', title: 'Dealer Performance Review', type: 'Dealer', date: '2026-03-05', status: 'Ready', description: 'Ranking of dealers based on revenue, visit frequency, and project probability.' },
  { id: 'R003', title: 'Outstanding Aging Report', type: 'Finance', date: '2026-03-07', status: 'Ready', description: 'Detailed list of receivables categorized by payment delay (0-30, 31-60, 61+ days).' },
  { id: 'R004', title: 'Inventory Stock Status', type: 'Inventory', date: '2026-03-07', status: 'Processing', description: 'Real-time stock levels for premium categories and manufacturing plant dispatch schedules.' },
];