import { createBrowserRouter } from "react-router";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Auth,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
]);