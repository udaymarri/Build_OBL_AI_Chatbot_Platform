import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Mic, Sparkles, TrendingUp, Users, Package } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { aiResponseEngine, callGrokAPI } from '../utils/aiEngine';
import { getRelevantExcelContext } from '../utils/contextFilter';
import { getKPIData } from '../data/mockData';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  chart?: any;
  suggestions?: string[];
}

interface ChatInterfaceProps {
  userRole: string;
  onChartGenerated?: (data: any) => void;
}

export function ChatInterface({ userRole, onChartGenerated }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: `Hello! I'm your OBL AI Assistant. I can help you with sales data, visit recommendations, dealer insights, and more. What would you like to know?`,
      timestamp: new Date(),
      suggestions: [
        'What is my outstanding amount?',
        'Show sales growth for last 6 months',
        'Which dealer should I visit today?',
        'Show me gap selling opportunities',
      ],
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const scrollViewportRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const finalTranscriptRef = useRef('');
  const currentTextRef = useRef('');

  const suggestedQuestions = [
    { icon: TrendingUp, text: 'Show sales trends', color: 'from-blue-500 to-cyan-500' },
    { icon: Users, text: 'Dealer recommendations', color: 'from-blue-600 to-sky-500' },
    { icon: Package, text: 'Gap selling opportunities', color: 'from-green-500 to-emerald-500' },
  ];

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Speech Recognition Logic
  useEffect(() => {
    if (isRecording) {
      finalTranscriptRef.current = input; // capture existing input
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        alert("Speech recognition is not supported in this browser.");
        setIsRecording(false);
        return;
      }

      const recognition = new SpeechRecognition();
      recognition.lang = 'en-IN';
      recognition.interimResults = true; // High sensitivity: show results as you speak
      recognition.continuous = true;
      recognition.maxAlternatives = 1;

      recognition.onresult = (event: any) => {
        let newlyFinalized = '';
        let currentInterim = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            newlyFinalized += event.results[i][0].transcript;
          } else {
            currentInterim += event.results[i][0].transcript;
          }
        }

        if (newlyFinalized) {
          finalTranscriptRef.current += (finalTranscriptRef.current && !finalTranscriptRef.current.endsWith(' ') ? ' ' : '') + newlyFinalized.trim();
        }

        const newText = finalTranscriptRef.current + (currentInterim && finalTranscriptRef.current && !finalTranscriptRef.current.endsWith(' ') ? ' ' : '') + currentInterim;
        currentTextRef.current = newText;
        setInput(newText);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        if (event.error !== 'no-speech') {
          setIsRecording(false);
        }
      };

      recognition.onend = () => {
        // Automatically restart if still in recording mode (for low voice gap handling)
        if (isRecording) {
          // Commit any unfinalized text before restarting so it's not lost!
          if (currentTextRef.current) {
            finalTranscriptRef.current = currentTextRef.current;
          }
          setTimeout(() => {
            try { recognition.start(); } catch (e) { }
          }, 50);
        }
      };

      recognition.start();

      return () => {
        recognition.stop();
      };
    }
  }, [isRecording]);

  const handleSend = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: messageText,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI processing
    setTimeout(async () => {
      let aiText = '';
      let chatResponse = aiResponseEngine(messageText, userRole);

      try {
        const { sapMaterials, sapSalesOrders, salesData, dealers, schemes } = await import('../data/mockData');
        const { excelData } = await import('../data/excelData');

        // Filter the huge excel database to only send relevant rows
        const filteredExcelData = getRelevantExcelContext(messageText, excelData);

        const contextData = JSON.stringify({
          kpiData: getKPIData(userRole),
          materials: sapMaterials,
          orders: sapSalesOrders,
          salesData: salesData,
          dealers: dealers,
          schemes: schemes,
          excelDatabase: filteredExcelData
        });
        const grokAnswer = await callGrokAPI(messageText, userRole, contextData);
        if (grokAnswer) {
          aiText = grokAnswer;
        }
      } catch (e: any) {
        console.error("Grok API call failed.", e);
        aiText = "API Connection Error: " + (e.message || "Invalid Key or Rate Limit reached.");
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: aiText || chatResponse.text,
        timestamp: new Date(),
        chart: chatResponse.chart,
        suggestions: chatResponse.suggestions,
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);

      if (chatResponse.chart && onChartGenerated) {
        onChartGenerated(chatResponse.chart);
      }
    }, 500);
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSend(suggestion);
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-transparent to-black/5 overflow-hidden">
      {/* Quick Actions */}
      <div className="p-4 border-b border-white/10 flex-shrink-0 bg-black/10 backdrop-blur-sm">
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {suggestedQuestions.map((item, idx) => (
            <motion.button
              key={idx}
              onClick={() => handleSend(item.text)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r ${item.color} text-white whitespace-nowrap text-sm font-medium`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <item.icon className="w-4 h-4" />
              {item.text}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 min-h-0">
        <ScrollArea className="h-full">
          <div className="p-6 pb-4">
            <AnimatePresence>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${message.type === 'user'
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                      : 'bg-white/10 backdrop-blur-xl text-white border border-white/10'
                      }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                    {message.suggestions && (
                      <div className="mt-3 space-y-2">
                        {message.suggestions.map((suggestion, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="w-full text-left text-xs bg-white/5 px-3 py-2 rounded-lg border border-white/10 hover:bg-white/10 hover:border-cyan-400/50 transition-all cursor-pointer"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Typing Indicator */}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 mb-6"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div className="flex gap-1 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl px-6 py-4">
                  <motion.div
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                  />
                  <motion.div
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                  />
                </div>
              </motion.div>
            )}

            {/* Scroll anchor */}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>

      {/* Input */}
      <div className="p-4 border-t border-white/10 bg-black/20 backdrop-blur-xl flex-shrink-0">
        <div className="flex gap-3 items-center">
          <div className="flex-1 relative">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask me anything about your business..."
              className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pr-12 h-12 rounded-xl"
            />
            <Button
              size="icon"
              variant="ghost"
              className={`absolute right-2 top-1/2 -translate-y-1/2 transition-colors ${isRecording ? 'text-red-500' : 'text-gray-400 hover:text-cyan-400'}`}
              onClick={() => setIsRecording(!isRecording)}
            >
              <Mic className="w-5 h-5" />
            </Button>
          </div>

          <Button
            onClick={() => handleSend()}
            disabled={!input.trim()}
            className="h-12 px-6 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white rounded-xl"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}