import { motion } from 'motion/react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, Download } from 'lucide-react';
import { Button } from './ui/button';
import { salesData } from '../data/mockData';

interface AnalyticsPanelProps {
  chartData?: any;
}

export function AnalyticsPanel({ chartData }: AnalyticsPanelProps) {
  const displayData = chartData?.data || salesData;
  const chartType = chartData?.type || 'line';
  const chartTitle = chartData?.title || 'Sales Performance Overview';

  const handleDownload = () => {
    if (!displayData || !displayData.length) return;

    // Convert JSON to CSV
    const headers = Object.keys(displayData[0]);
    const csvContent = [
      headers.join(','),
      ...displayData.map((row: any) =>
        headers.map(header => JSON.stringify(row[header])).join(',')
      )
    ].join('\n');

    // Create a blob and download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${chartTitle.replace(/\s+/g, '_')}_Report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Format large numbers for Y-axis
  const formatYAxis = (value: number) => {
    if (value >= 10000000) {
      return `${(value / 10000000).toFixed(0)}Cr`;
    } else if (value >= 100000) {
      return `${(value / 100000).toFixed(0)}L`;
    } else if (value >= 1000) {
      return `${(value / 1000).toFixed(0)}K`;
    }
    return value.toString();
  };

  // Format tooltip values
  const formatTooltipValue = (value: number) => {
    if (value >= 10000000) {
      return `₹${(value / 10000000).toFixed(2)} Cr`;
    } else if (value >= 100000) {
      return `₹${(value / 100000).toFixed(2)} L`;
    }
    return `₹${value.toLocaleString()}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="h-full flex flex-col overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-white/10 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-cyan-400" />
              Analytics
            </h2>
            <p className="text-sm text-gray-400 mt-1">Real-time insights & visualizations</p>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={handleDownload}
              className="bg-gradient-to-r from-orange-400 to-rose-500 hover:from-orange-500 hover:to-rose-600 text-white border-none shadow-lg shadow-orange-500/20 px-6"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Chart Area */}
      <div className="flex-1 p-6 overflow-y-auto min-h-0">
        <motion.div
          key={chartTitle}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="backdrop-blur-xl border border-white/10 rounded-2xl p-6"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
        >
          <h3 className="text-lg font-semibold text-white mb-6">{chartTitle}</h3>

          {chartType === 'line' && (
            <ResponsiveContainer width="100%" height={300} key="analytics-line-chart">
              <LineChart data={displayData}>
                <defs>
                  <linearGradient id="analyticsColorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00D4FF" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#00D4FF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" key="grid-analytics-line" />
                <XAxis
                  dataKey="month"
                  stroke="#D1D5DB"
                  key="xaxis-analytics-line"
                  style={{ fontSize: '13px', fontWeight: '500' }}
                />
                <YAxis
                  stroke="#D1D5DB"
                  key="yaxis-analytics-line"
                  tickFormatter={formatYAxis}
                  style={{ fontSize: '14px', fontWeight: '600' }}
                  width={60}
                />
                <Tooltip
                  key="tooltip-analytics-line"
                  contentStyle={{
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                    color: '#fff',
                  }}
                  formatter={formatTooltipValue}
                />
                <Legend key="legend-analytics-line" />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#00D4FF"
                  strokeWidth={3}
                  dot={{ fill: '#00D4FF', r: 6 }}
                  activeDot={{ r: 8 }}
                  key="line-revenue"
                />
                <Line
                  type="monotone"
                  dataKey="target"
                  stroke="#9333EA"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ fill: '#9333EA', r: 4 }}
                  key="line-target"
                />
              </LineChart>
            </ResponsiveContainer>
          )}

          {chartType === 'bar' && (
            <ResponsiveContainer width="100%" height={300} key="analytics-bar-chart">
              <BarChart data={displayData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" key="grid-analytics-bar" />
                <XAxis
                  dataKey="month"
                  stroke="#D1D5DB"
                  key="xaxis-analytics-bar"
                  style={{ fontSize: '13px', fontWeight: '500' }}
                />
                <YAxis
                  stroke="#D1D5DB"
                  key="yaxis-analytics-bar"
                  tickFormatter={formatYAxis}
                  style={{ fontSize: '14px', fontWeight: '600' }}
                  width={60}
                />
                <Tooltip
                  key="tooltip-analytics-bar"
                  contentStyle={{
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                    color: '#fff',
                  }}
                  formatter={formatTooltipValue}
                />
                <Legend key="legend-analytics-bar" />
                <Bar dataKey="revenue" fill="#00D4FF" radius={[8, 8, 0, 0]} key="bar-revenue" />
                <Bar dataKey="target" fill="#9333EA" radius={[8, 8, 0, 0]} key="bar-target" />
              </BarChart>
            </ResponsiveContainer>
          )}

          {chartType === 'table' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    {Object.keys(displayData[0] || {}).map(key => (
                      <th key={key} className="text-left py-3 px-4 text-sm font-semibold text-gray-300 uppercase">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {displayData.map((row: any, idx: number) => (
                    <motion.tr
                      key={idx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="border-b border-white/5 hover:bg-white/5"
                    >
                      {Object.values(row).map((value: any, i) => (
                        <td key={i} className="py-3 px-4 text-sm text-gray-300">
                          {typeof value === 'number' ? value.toLocaleString() : value}
                        </td>
                      ))}
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>

        {/* Additional Stats */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 backdrop-blur-xl border border-cyan-500/20 rounded-xl p-4"
          >
            <div className="text-sm text-gray-400 mb-1">Avg Monthly Growth</div>
            <div className="text-2xl font-bold text-white">+12.5%</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-blue-600/20 to-sky-600/20 backdrop-blur-xl border border-blue-500/20 rounded-xl p-4"
          >
            <div className="text-sm text-gray-400 mb-1">YTD Revenue</div>
            <div className="text-2xl font-bold text-white">
              <span className="font-extrabold">₹</span> 12.5 Cr
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}