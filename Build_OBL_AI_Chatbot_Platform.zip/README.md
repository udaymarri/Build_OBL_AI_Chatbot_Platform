# OBL AI - Conversational Intelligence Assistant

## Premium Enterprise AI Chatbot Platform for Orientbell Limited

A full-stack AI-powered enterprise chatbot platform featuring **glassmorphism UI, 3D graphics, smooth animations, and intelligent business insights** through natural language conversations.

---

## 🎯 Project Overview

**OBL AI** is an enterprise-grade conversational intelligence platform designed for Orientbell Limited employees to interact with business data through natural language. The system provides role-based access to sales analytics, dealer insights, visit recommendations, and gap selling opportunities.

### User Roles
- **Salesperson** - Territory data access
- **Branch Head** - Branch-level analytics
- **Zonal Manager** - Zone-wide insights
- **India Head** - Regional performance
- **CEO** - Complete enterprise view

---

## 🚀 Features

### ✨ Premium UI/UX
- **Glassmorphism Design** - Frosted glass effects with backdrop blur
- **3D Graphics** - Three.js powered rotating logo and visual elements
- **Particle Background** - Animated particle network with dynamic connections
- **Smooth Animations** - Motion (Framer Motion) powered transitions
- **Draggable Widgets** - React DnD powered movable KPI cards
- **Neon Gradients** - Cyan (#00D4FF) and Purple (#9333EA) color scheme

### 🤖 AI Assistant Features
- **Natural Language Queries** - Ask questions in plain English
- **Contextual Responses** - Role-based intelligent answers
- **Dynamic Visualizations** - Auto-generated charts and tables
- **Smart Suggestions** - Follow-up question recommendations
- **Typing Animation** - Realistic AI thinking indicator
- **Voice Input UI** - Microphone interface (simulated)

### 📊 Analytics & Insights
- **Sales Trends** - 6-month growth analysis with line/bar charts
- **Outstanding Tracking** - Dealer-wise payment status
- **Visit Recommendations** - AI-powered priority dealer visits
- **Gap Selling** - Upsell opportunity identification
- **KPI Dashboard** - Real-time metrics (Revenue, Target, Visits)
- **Interactive Charts** - Recharts powered visualizations

### 🎯 Smart Recommendations
- **Sales Recommendations** - Product gap analysis for dealers
- **Visit Prioritization** - Days since visit + sales potential scoring
- **Scheme Applicability** - Active offers and discount calculations
- **Route Optimization** - Territory-based visit planning (coming soon)

---

## 📁 Project Structure

```
src/
├── app/
│   ├── components/
│   │   ├── ui/                    # Shadcn UI components
│   │   ├── ParticleBackground.tsx # Animated particle system
│   │   ├── Logo3D.tsx            # Three.js 3D logo
│   │   ├── DraggableKPI.tsx      # Drag & drop KPI cards
│   │   ├── ChatInterface.tsx     # AI chat component
│   │   └── AnalyticsPanel.tsx    # Charts & visualizations
│   │
│   ├── pages/
│   │   ├── Login.tsx             # Role selection screen
│   │   └── Dashboard.tsx         # Main dashboard layout
│   │
│   ├── data/
│   │   └── mockData.ts           # Sample business data
│   │
│   ├── utils/
│   │   └── aiEngine.ts           # AI response logic
│   │
│   ├── routes.tsx                # React Router config
│   └── App.tsx                   # Root component
│
├── styles/
│   ├── theme.css                 # Custom CSS variables & glassmorphism
│   ├── tailwind.css              # Tailwind imports
│   └── fonts.css                 # Font imports
│
└── ...
```

---

## 🧠 AI Response Engine

The **aiEngine.ts** module simulates intelligent responses by:

1. **Query Analysis** - Pattern matching user input
2. **Data Aggregation** - Fetching relevant mock data based on role
3. **Response Generation** - Contextual text answers
4. **Chart Selection** - Choosing appropriate visualization type
5. **Suggestion Engine** - Providing follow-up questions

### Supported Queries

| Query Type | Example | Response Includes |
|------------|---------|-------------------|
| Outstanding | "What is my outstanding amount?" | Amount breakdown, top dealers |
| Sales Growth | "Show sales for last 6 months" | Line chart, growth %, targets |
| Visit Reco | "Which dealer should I visit?" | Priority list with scoring |
| Gap Selling | "Show upsell opportunities" | Product recommendations |
| Schemes | "Active offers" | Discount details, validity |
| KPIs | "Show my dashboard" | Real-time metrics |

---

## 📦 Technology Stack

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **React Router 7** - Navigation
- **TailwindCSS v4** - Utility-first styling
- **Motion (Framer Motion)** - Animations
- **Three.js** - 3D graphics
- **@react-three/fiber** - React Three.js renderer
- **@react-three/drei** - Three.js helpers
- **Recharts** - Chart library
- **React DnD** - Drag and drop
- **Shadcn UI** - Component library

### Mock Data Layer
- **mockData.ts** - Simulated ERP/CRM data
- **aiEngine.ts** - Pattern-based AI responses

---

## 🎨 Design System

### Color Palette
```css
Primary Cyan:   #00D4FF (Neon Blue)
Primary Purple: #9333EA (Electric Purple)
Background:     #000000 - #1a1a1a (Dark gradient)
Glass Overlay:  rgba(255,255,255,0.05) + backdrop-blur
Accent Green:   #10B981 (Success states)
Accent Orange:  #F97316 (Warnings)
```

### Typography
- **Headings**: System font stack
- **Body**: 16px base
- **Weights**: 400 (normal), 500 (medium), 600 (semibold)

### Effects
- **Glassmorphism**: `backdrop-blur-xl` + `bg-white/5`
- **Glow**: `box-shadow` with color opacity
- **Gradients**: Linear 135deg cyan-to-blue/purple
- **Animations**: Spring physics, stagger delays

---

## 🔐 Role-Based Access Control

Data filtering is implemented in the mock layer:

```typescript
// Salesperson sees only their territory
if (role === 'salesperson') {
  return filteredData.territory === user.territory;
}

// CEO sees everything
if (role === 'ceo') {
  return allData;
}
```

**Note**: In production, this would be enforced server-side with proper authentication.

---

## 🚦 Getting Started

### Installation
```bash
# Project dependencies are already installed
# No additional setup needed
```

### Usage
1. Open the application
2. Select your role (Salesperson, Branch Head, etc.)
3. Click "Enter Dashboard"
4. Start chatting with the AI assistant!

### Sample Queries to Try
```
"What is my outstanding amount?"
"Show sales growth for last 6 months"
"Which dealer should I visit today?"
"Show me gap selling opportunities"
"What are the active schemes?"
"Show my performance dashboard"
```

---

## 📊 Mock Data Sources

The application simulates integration with:

- **ERP System** - Sales revenue, orders, targets
- **CRM System** - Dealer information, contacts
- **Laksha Visit Logs** - Field visit tracking
- **Quicklook Product Catalog** - Product inventory
- **Scheme Database** - Active offers & discounts

### Sample Dealers
```javascript
Marble Palace Tiles - Mumbai (High potential, ₹8.5L outstanding)
Elite Surfaces - Delhi (High potential, ₹3.2L outstanding)
Crystal Tiles - Bangalore (Medium potential, ₹4.5L outstanding)
Architect XYZ - Mumbai (High potential, new prospect)
Premium Flooring - Chennai (Medium potential)
```

---

## 🎯 Key Algorithms

### Visit Recommendation Scoring
```typescript
priority = (daysSinceVisit > 15 && potential === 'high') ? 90 :
           (daysSinceVisit > 20) ? 70 :
           (potential === 'high') ? 60 : 40;
```

### Gap Selling Logic
```typescript
// Find products dealer hasn't purchased
const gapProducts = allProducts.filter(p => 
  !dealer.purchasedCategories.includes(p.category)
);

// Calculate potential revenue
potentialRevenue = productPrice * estimatedVolume;
```

---

## 🔮 Future Enhancements

### Phase 2 (Backend Integration)
- [ ] Real Grok AI API integration
- [ ] Supabase authentication
- [ ] PostgreSQL database
- [ ] Edge Functions for secure API calls
- [ ] Real-time data sync

### Phase 3 (Advanced Features)
- [ ] Voice-to-text (Web Speech API)
- [ ] Text-to-speech responses
- [ ] PDF report generation
- [ ] Email notifications
- [ ] Mobile app (React Native)
- [ ] Offline mode with sync

### Phase 4 (Enterprise)
- [ ] Multi-language support
- [ ] Advanced analytics (Predictive AI)
- [ ] Integration with SAP/Oracle
- [ ] Compliance & audit logs
- [ ] White-label customization

---

## ⚠️ Important Notes

### Current Implementation
- **Frontend Only** - No backend/database (uses mock data)
- **Simulated AI** - Pattern-based responses (not real LLM)
- **Demo Data** - Not connected to real ERP/CRM
- **Client-side Auth** - Role selection without security

### Production Requirements
For a real enterprise deployment, you would need:
- Secure authentication (OAuth 2.0, SAML)
- Backend API (Node.js/FastAPI)
- Database (PostgreSQL/MongoDB)
- LLM integration (OpenAI/Grok/Claude)
- Data encryption (at-rest & in-transit)
- Compliance (GDPR, SOC2)
- Load balancing & CDN
- Monitoring & logging

---

## 📝 License

This is a demonstration project created for Orientbell Limited.

---

## 👨‍💻 Architecture Decisions

### Why React Router?
Multi-page navigation (Login → Dashboard) with clean URL structure.

### Why Three.js?
Premium 3D visual effects for enterprise branding impact.

### Why Recharts?
Excellent TypeScript support and customization for business charts.

### Why React DnD?
Professional drag-and-drop for personalized dashboard layouts.

### Why Motion?
Best-in-class React animations with spring physics.

---

## 🎓 Learning Resources

- [React Router Documentation](https://reactrouter.com)
- [Three.js Fundamentals](https://threejs.org/manual/)
- [Recharts Examples](https://recharts.org/en-US/examples)
- [Motion Documentation](https://motion.dev/)
- [Glassmorphism Design](https://hype4.academy/tools/glassmorphism-generator)

---

**Built with ❤️ for Enterprise AI Excellence**
