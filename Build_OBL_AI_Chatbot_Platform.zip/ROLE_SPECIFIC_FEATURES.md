# OBL AI - Role-Specific Features Documentation

## Overview

Each role in the OBL AI platform now has unique, specialized dashboards and features tailored to their specific responsibilities and hierarchy level. Access these through the **"My Role"** navigation menu item.

---

## 🎯 Salesperson Dashboard

**Target Users:** Field sales representatives managing territories and dealer relationships

### Unique Features

#### 1. **Monthly Target Tracker**
- Real-time progress visualization
- Days remaining counter
- Dynamic progress bar with animations
- Achievement percentage calculation

#### 2. **Commission Calculator**
- Current month commission
- Projected commission based on performance
- 6-month commission history chart
- Breakdown by base salary, incentives, and bonuses

#### 3. **Today's Visit Planner**
- Route-optimized daily schedule
- Priority-based dealer visits (High/Medium/Low)
- Distance calculations for each visit
- Time slot management
- Visit purpose and context
- Real-time status tracking (Pending/Scheduled/Completed)

#### 4. **Performance Metrics**
- Monthly target vs achieved
- Daily average required to meet target
- Outstanding collection focus
- Visit count tracking

### Sample Data

```javascript
Daily Visits: 4 planned visits with GPS-based routing
Commission Range: ₹59K - ₹82K (last 6 months)
Average Target Achievement: 87%
```

### Use Cases
- Plan optimal daily routes to maximize dealer coverage
- Track commission earnings in real-time
- Prioritize high-value dealer visits
- Monitor progress toward monthly targets

---

## 👥 Branch Head Dashboard

**Target Users:** Branch managers overseeing sales teams and operations

### Unique Features

#### 1. **Team Performance Matrix**
- Individual salesperson comparison charts
- Achievement percentage tracking
- Sales vs target visualization
- Visit count monitoring
- Territory assignment display

#### 2. **Team Member Details**
- 6 salespeople with detailed metrics
- Performance status indicators (color-coded)
- Individual progress bars
- Active/Inactive status tracking

#### 3. **Branch Inventory Management**
- Real-time stock levels for all product categories
- Low stock alerts
- Minimum level thresholds
- Stock status indicators (Healthy/Low Stock)
- 6 product categories monitored

#### 4. **Top/Bottom Performer Insights**
- Automatic identification of top performer
- "Needs Attention" count (below 80% target)
- Team average achievement calculation

### Sample Data

```javascript
Team Size: 6 salespeople
Average Achievement: 86.8%
Top Performer: Vikram Patel (102%)
Inventory Categories: 6 (Marble, Ceramic, Vitrified, Wall, Designer, Parking)
```

### Use Cases
- Identify underperforming team members for coaching
- Manage branch inventory proactively
- Allocate resources based on team performance
- Approve discount requests and schemes

---

## 🌍 Zonal Manager Dashboard

**Target Users:** Zone-level managers overseeing multiple branches

### Unique Features

#### 1. **Multi-Branch Comparison**
- Side-by-side branch performance analysis
- Sales vs target bar charts
- Achievement percentage tracking
- Team size comparison
- Branch rating system (out of 5.0)

#### 2. **Zone Market Heatmap**
- Market share by city (Radar chart)
- Growth percentage visualization
- Competitor analysis by location
- 4-city market intelligence (Mumbai, Pune, Surat, Ahmedabad)

#### 3. **Branch Details Grid**
- 4 branches in West Zone
- Location-based grouping
- Performance color coding
- Real-time achievement status

#### 4. **Zone-Wide Metrics**
- Total zone sales aggregation
- Combined team size across branches
- Average branch rating
- Zone target achievement

### Sample Data

```javascript
Branches: 4 (Mumbai, Pune, Surat, Ahmedabad)
Total Sales: ₹82 Crores
Total Team: 18 salespeople
Best Branch: Pune (91.7% achievement)
Market Share Range: 12.2% - 22.3%
```

### Use Cases
- Identify best practices from top-performing branches
- Reallocate resources across branches
- Monitor market share by geography
- Plan zone-wide strategies and campaigns

---

## 🇮🇳 India Head Dashboard

**Target Users:** National heads managing regional zones

### Unique Features

#### 1. **Regional Zone Overview**
- 4 zones (West, North, South, East)
- Zone manager identification
- Branch count per zone
- Achievement ranking

#### 2. **National Performance Charts**
- Combined Line + Bar charts
- Sales vs Target comparison
- Achievement trend lines
- Quarterly performance tracking

#### 3. **State-wise Performance**
- Top 3 performing states highlighted
- Sales by state (6 major states)
- Dealer count tracking
- Growth percentage by region

#### 4. **Product Category Distribution**
- National product mix analysis (Pie chart)
- Category-wise sales share
- Growth rates by product line
- 6 product categories tracked

### Sample Data

```javascript
Total Zones: 4 covering Pan India
National Sales: ₹450 Crores
Total Branches: 23 across zones
Total Dealers: 1,120 active
Best Zone: South Zone (96% achievement)
Top State: Delhi NCR (₹88 Cr sales)
```

### Use Cases
- Compare zonal performance for strategic planning
- Identify state-level growth opportunities
- Optimize product category mix
- Allocate national budgets by region

---

## 💼 CEO Dashboard

**Target Users:** C-suite executives requiring enterprise-wide visibility

### Unique Features

#### 1. **Executive Command Center**
- Board-ready metrics display
- Company-wide KPI summary
- Financial performance overview
- Enterprise health indicators

#### 2. **Quarterly Financial Performance**
- Revenue and profit trends (Area charts)
- Profit margin tracking
- 4-quarter comparison (Q1-Q4 FY26)
- Growth trajectory visualization

#### 3. **Competitive Landscape Analysis**
- 6 competitor comparison (horizontal bar chart)
- Market share positioning
- Growth rate benchmarking
- Industry ranking (#2 position)

#### 4. **Strategic Initiatives Tracker**
- 4 major initiatives monitored
- Completion percentage tracking
- Impact level classification (High/Medium)
- Status monitoring (On Track/In Progress/Planning)
- Deadline tracking

#### 5. **Network Coverage Metrics**
- 4 zones, 28 branches
- 1,250 dealers nationwide
- 850 employees
- Comprehensive reach visualization

### Sample Data

```javascript
Annual Revenue: ₹1,250 Crores
YoY Growth: 18.5%
Market Share: 24.5% (#2 in industry)
Profit Margin: 22.8%
Total Employees: 850
Strategic Initiatives: 4 (75% avg completion)
```

### Strategic Initiatives Tracked
1. **Digital Transformation** - 75% complete
2. **Market Expansion (Tier 2 Cities)** - 45% complete
3. **Premium Product Line Launch** - 20% complete
4. **Sustainability Initiative** - 60% complete

### Use Cases
- Prepare board presentations with real-time data
- Monitor competitive positioning
- Track strategic initiative progress
- Make enterprise-wide investment decisions
- Analyze financial health and profitability

---

## 🎨 UI/UX Features (All Roles)

### Consistent Design Elements

1. **Glassmorphism Effects**
   - Backdrop blur on all panels
   - Translucent backgrounds
   - Border highlights with opacity

2. **Color-Coded Status Indicators**
   - 🟢 Green: Achieving/Exceeding targets (≥100%)
   - 🔵 Cyan/Blue: On track (80-99%)
   - 🟠 Orange/Red: Needs attention (<80%)

3. **Interactive Charts**
   - Recharts library integration
   - Hover tooltips
   - Smooth animations
   - Responsive sizing

4. **Motion Animations**
   - Entrance animations (fade + slide)
   - Hover effects with scale
   - Progress bar animations
   - Stagger delays for lists

### Navigation

Access role-specific features through:
```
Dashboard > My Role (Yellow Target Icon)
```

The system automatically shows the correct dashboard based on logged-in user role.

---

## 🔄 Data Flow & Integration Points

### Current State (Mock Data)
All dashboards use predefined sample data from:
- `/src/app/data/roleFeatures.ts`
- `/src/app/data/mockData.ts`

### Future Integration Requirements

**Salesperson:**
- GPS integration for visit routing
- Commission calculation engine
- Daily visit sync with calendar
- Real-time target updates

**Branch Head:**
- HR system integration for team data
- Inventory management system sync
- Real-time stock level updates
- Performance management system

**Zonal Manager:**
- Multi-branch ERP data aggregation
- Market intelligence feeds
- Competitor data sources
- Geographic information systems (GIS)

**India Head:**
- Regional ERP consolidation
- State-level government data
- Product lifecycle management
- National sales forecasting

**CEO:**
- Financial system integration
- Board reporting automation
- Competitor intelligence platforms
- Strategic planning tools

---

## 📊 Key Metrics by Role

| Metric | Salesperson | Branch Head | Zonal Manager | India Head | CEO |
|--------|------------|-------------|---------------|------------|-----|
| **Primary KPI** | Monthly Sales | Team Achievement | Zone Sales | National Revenue | Company Growth |
| **Team Size** | Self | 6 people | 4 branches | 4 zones | 850 employees |
| **Geographic Scope** | Territory | Branch | Zone (4 cities) | Pan India | National |
| **Time Horizon** | Daily/Monthly | Weekly/Monthly | Monthly/Quarterly | Quarterly/Yearly | Yearly/Strategic |
| **Data Granularity** | Individual | Team | Branch | State/Zone | Enterprise |

---

## 🚀 Technical Implementation

### Component Structure

```
/src/app/components/roles/
├── SalespersonDashboard.tsx      (Visit planner, Commission tracker)
├── BranchHeadDashboard.tsx       (Team performance, Inventory)
├── ZonalManagerDashboard.tsx     (Multi-branch, Market analysis)
├── IndiaHeadDashboard.tsx        (National overview, Product mix)
└── CEODashboard.tsx              (Executive summary, Strategy)
```

### Data Source

```
/src/app/data/roleFeatures.ts
├── Daily visit plans
├── Team member data
├── Branch information
├── Zone metrics
├── Regional performance
├── Financial metrics
└── Strategic initiatives
```

### Integration in Dashboard

```typescript
{activeSection === 'my-role' && (
  <>
    {userRole === 'salesperson' && <SalespersonDashboard />}
    {userRole === 'branch_head' && <BranchHeadDashboard />}
    {userRole === 'zonal_manager' && <ZonalManagerDashboard />}
    {userRole === 'india_head' && <IndiaHeadDashboard />}
    {userRole === 'ceo' && <CEODashboard />}
  </>
)}
```

---

## 🎯 Future Enhancements

### Planned Features

1. **Salesperson**
   - Voice-activated visit logging
   - AR product demonstrations
   - Dealer sentiment analysis
   - Automated expense tracking

2. **Branch Head**
   - Real-time attendance dashboard
   - Automated performance reviews
   - Dynamic territory allocation
   - Scheme approval workflow

3. **Zonal Manager**
   - Predictive branch performance
   - Resource optimization engine
   - Cross-branch collaboration tools
   - Market opportunity scoring

4. **India Head**
   - AI-powered demand forecasting
   - State-wise product recommendations
   - Expansion opportunity analysis
   - Regulatory compliance dashboard

5. **CEO**
   - Board presentation generator
   - What-if scenario modeling
   - M&A opportunity screening
   - ESG metrics dashboard

---

## 📱 Mobile Responsiveness

All role dashboards are fully responsive:
- Mobile: Single column layout
- Tablet: 2-column grid
- Desktop: Multi-column complex layouts
- Charts: Responsive containers with auto-resize

---

## 🔐 Role-Based Access Control

Each dashboard automatically:
1. Detects user role from localStorage
2. Shows only relevant features for that role
3. Filters data based on hierarchy level
4. Restricts actions based on permissions

**Hierarchy Levels:**
```
CEO (Level 5)
└── India Head (Level 4)
    └── Zonal Manager (Level 3)
        └── Branch Head (Level 2)
            └── Salesperson (Level 1)
```

---

**Last Updated:** March 6, 2026  
**Version:** 2.0.0  
**Status:** Production Ready (Frontend)
