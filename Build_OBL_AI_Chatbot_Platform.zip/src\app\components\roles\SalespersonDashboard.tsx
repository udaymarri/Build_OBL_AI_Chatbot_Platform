import { motion } from 'motion/react';
import { 
  MapPin, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Navigation,
  Clock,
  Target,
  Award,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { dailyVisitPlan, salespersonTeamData, commissionHistory } from '../../data/roleFeatures';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function SalespersonDashboard() {
  const progressPercentage = (salespersonTeamData.achieved / salespersonTeamData.myTarget) * 100;

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Header Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Target className="w-5 h-5 text-cyan-400" />
              <span className="text-sm text-gray-400">Monthly Target</span>
            </div>
            <p className="text-2xl font-bold text-white">
              <span className="font-extrabold">₹</span> {(salespersonTeamData.myTarget / 100000).toFixed(1)}L
            </p>
            <p className="text-xs text-cyan-400 mt-1">{salespersonTeamData.daysLeft} days left</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl border border-green-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-sm text-gray-400">Achieved</span>
            </div>
            <p className="text-2xl font-bold text-white">
              <span className="font-extrabold">₹</span> {(salespersonTeamData.achieved / 100000).toFixed(1)}L
            </p>
            <p className="text-xs text-green-400 mt-1">{progressPercentage.toFixed(1)}% complete</p>
          </div>

          <div className="bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">Commission</span>
            </div>
            <p className="text-2xl font-bold text-white">
              <span className="font-extrabold">₹</span> {(salespersonTeamData.commission.current / 1000).toFixed(0)}K
            </p>
            <p className="text-xs text-blue-400 mt-1">
              Projected: <span className="font-extrabold">₹</span> {(salespersonTeamData.commission.projected / 1000).toFixed(0)}K
            </p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl border border-orange-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-orange-400" />
              <span className="text-sm text-gray-400">Daily Avg Req</span>
            </div>
            <p className="text-2xl font-bold text-white">₹{(salespersonTeamData.averageRequired / 1000).toFixed(0)}K</p>
            <p className="text-xs text-orange-400 mt-1">To meet target</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-semibold text-white">Target Progress</h3>
            <span className="text-cyan-400 font-bold">{progressPercentage.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-gray-800 rounded-full h-4 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 1, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full relative"
            >
              <div className="absolute inset-0 bg-white/20 animate-pulse" />
            </motion.div>
          </div>
          <div className="flex justify-between text-xs text-gray-500 mt-2">
            <span><span className="font-bold">₹</span> 0</span>
            <span><span className="font-bold">₹</span> {(salespersonTeamData.myTarget / 100000).toFixed(1)}L</span>
          </div>
        </div>

        {/* Today's Visit Plan */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Navigation className="w-5 h-5 text-cyan-400" />
              Today's Visit Plan
            </h3>
            <span className="text-sm text-gray-400">{dailyVisitPlan.length} visits</span>
          </div>

          <div className="space-y-3">
            {dailyVisitPlan.map((visit, idx) => (
              <motion.div
                key={visit.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className={`p-4 rounded-xl border backdrop-blur-sm transition-all hover:scale-[1.02] ${
                  visit.priority === 'high'
                    ? 'bg-red-500/10 border-red-500/30'
                    : visit.priority === 'medium'
                    ? 'bg-yellow-500/10 border-yellow-500/30'
                    : 'bg-green-500/10 border-green-500/30'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-white">{visit.dealerName}</h4>
                      {visit.status === 'completed' && (
                        <CheckCircle2 className="w-4 h-4 text-green-400" />
                      )}
                      {visit.priority === 'high' && visit.status !== 'completed' && (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-400 mb-2">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {visit.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {visit.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <Navigation className="w-3 h-3" />
                        {visit.distance} km
                      </span>
                    </div>
                    <p className="text-sm text-gray-300">{visit.purpose}</p>
                  </div>
                  <div className={`px-3 py-1 rounded-lg text-xs font-medium ${
                    visit.priority === 'high'
                      ? 'bg-red-500/20 text-red-400'
                      : visit.priority === 'medium'
                      ? 'bg-yellow-500/20 text-yellow-400'
                      : 'bg-green-500/20 text-green-400'
                  }`}>
                    {visit.priority.toUpperCase()}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Commission History */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <DollarSign className="w-5 h-5 text-green-400" />
            Commission History (Last 6 Months)
          </h3>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%" key="salesperson-commission">
              <BarChart data={commissionHistory}>
                <defs>
                  <linearGradient id="commissionGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.8}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" key="grid-salesperson" />
                <XAxis dataKey="month" stroke="#9CA3AF" key="xaxis-salesperson" />
                <YAxis stroke="#9CA3AF" key="yaxis-salesperson" />
                <Tooltip
                  key="tooltip-salesperson"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="total" fill="url(#commissionGradient)" radius={[8, 8, 0, 0]} key="bar-total-commission" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-4">
            <div className="text-center">
              <p className="text-xs text-gray-400">Avg Commission</p>
              <p className="text-lg font-bold text-white">
                <span className="font-extrabold">₹</span> 70.7K
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400">Highest</p>
              <p className="text-lg font-bold text-green-400">
                <span className="font-extrabold">₹</span> 82K
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400">Total (6M)</p>
              <p className="text-lg font-bold text-cyan-400">
                <span className="font-extrabold">₹</span> 4.24L
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}