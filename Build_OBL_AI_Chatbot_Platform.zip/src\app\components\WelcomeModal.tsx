import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, MessageSquare, TrendingUp, Package } from 'lucide-react';
import { Button } from './ui/button';

interface WelcomeModalProps {
  userName: string;
  onClose: () => void;
}

export function WelcomeModal({ userName, onClose }: WelcomeModalProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      icon: Sparkles,
      title: `Welcome, ${userName}!`,
      description: 'OBL AI is your intelligent business assistant. Get instant insights through natural conversation.',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      icon: MessageSquare,
      title: 'Ask Me Anything',
      description: 'Type questions like "What is my outstanding?" or "Show sales trends" in plain English.',
      color: 'from-blue-600 to-sky-500',
    },
    {
      icon: TrendingUp,
      title: 'Get Smart Insights',
      description: 'I provide charts, recommendations, and follow-up suggestions based on your role.',
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: Package,
      title: 'Explore Features',
      description: 'Check out draggable KPIs, 3D products, and analytics. Click anywhere to start!',
      color: 'from-orange-500 to-red-500',
    },
  ];

  const currentStepData = steps[currentStep];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handleSkip = () => {
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="relative max-w-md w-full bg-gray-900/90 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-2xl"
      >
        {/* Close button */}
        <button
          onClick={handleSkip}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="text-center"
          >
            {/* Icon */}
            <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-br ${currentStepData.color} mb-6`}>
              <currentStepData.icon className="w-10 h-10 text-white" />
            </div>

            {/* Title */}
            <h2 className="text-2xl font-bold text-white mb-3">
              {currentStepData.title}
            </h2>

            {/* Description */}
            <p className="text-gray-300 mb-8 leading-relaxed">
              {currentStepData.description}
            </p>

            {/* Progress dots */}
            <div className="flex gap-2 justify-center mb-6">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentStep
                      ? 'bg-cyan-400 w-6'
                      : index < currentStep
                      ? 'bg-cyan-400/50'
                      : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              {currentStep < steps.length - 1 ? (
                <>
                  <Button
                    onClick={handleSkip}
                    variant="outline"
                    className="flex-1 border-white/10 text-gray-300 hover:bg-white/5"
                  >
                    Skip
                  </Button>
                  <Button
                    onClick={handleNext}
                    className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white"
                  >
                    Next
                  </Button>
                </>
              ) : (
                <Button
                  onClick={handleNext}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white"
                >
                  Get Started!
                </Button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
}