import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

// Add type definition for jspdf-autotable
declare module 'jspdf' {
    interface jsPDF {
        autoTable: (options: any) => jsPDF;
    }
}

export interface AgingRecord {
    dealerName: string;
    totalOutstanding: number;
    days0_30: number;
    days31_60: number;
    days61_90: number;
    days91_plus: number;
    lastPaymentDate: string;
}

/**
 * Generates realistic aging data for >30 persons
 */
export const generateAgingData = (count: number = 35): AgingRecord[] => {
    const dealers = [
        'Marble Palace Tiles', 'Elite Surfaces Pvt Ltd', 'Crystal Tiles Co.', 'Premium Flooring Solutions',
        'Modern Ceramics', 'Royal Stone & Tiles', 'Skyline Décor', 'Heritage Marbles', 'Urban Living Tiles',
        'Galaxy Interio', 'Prism Tiles', 'Apex Surfaces', 'Classic Floorings', 'Design Studio',
        'Zenith Tiles', 'Nova Surfaces', 'Ethereal Designs', 'Metropolis Tiles', 'Luxe Living',
        'Infinite Surfaces', 'Golden Gate Tiles', 'Silver Line Marbles', 'Titan Flooring',
        'United Ceramics', 'Vanguard Tiles', 'Western Surfaces', 'Xcel Designs', 'Yorkshire Tiles',
        'Zion Interio', 'Alpha Marbles', 'Beta Ceramics', 'Gamma Tiles', 'Delta Surfaces',
        'Omega Floorings', 'Sigma Designs', 'Kappa Marbles', 'Omega Tiles'
    ];

    return Array.from({ length: Math.max(count, dealers.length) }, (_, i) => {
        const dealerName = dealers[i % dealers.length] + (i >= dealers.length ? ` (Branch ${Math.floor(i / dealers.length) + 1})` : '');
        const total = Math.floor(Math.random() * 800000) + 100000;

        // Distribute the total across different aging buckets
        const p1 = Math.random();
        const p2 = Math.random() * (1 - p1);
        const p3 = Math.random() * (1 - p1 - p2);
        const p4 = 1 - p1 - p2 - p3;

        return {
            dealerName,
            totalOutstanding: total,
            days0_30: Math.floor(total * p1),
            days31_60: Math.floor(total * p2),
            days61_90: Math.floor(total * p3),
            days91_plus: Math.floor(total * p4),
            lastPaymentDate: new Date(Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]
        };
    });
};

/**
 * Export data to PDF
 */
export const downloadPDFReport = (title: string, data: AgingRecord[]) => {
    const doc = new jsPDF();

    // Header
    doc.setFontSize(20);
    doc.setTextColor(0, 150, 200);
    doc.text('Orientbell Limited', 14, 22);

    doc.setFontSize(16);
    doc.setTextColor(100);
    doc.text(title, 14, 32);

    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 40);

    // Table
    const tableColumn = ["Dealer Name", "Total (₹)", "0-30 Days", "31-60 Days", "61-90 Days", "90+ Days", "Last Payment"];
    const tableRows = data.map(record => [
        record.dealerName,
        record.totalOutstanding.toLocaleString('en-IN'),
        record.days0_30.toLocaleString('en-IN'),
        record.days31_60.toLocaleString('en-IN'),
        record.days61_90.toLocaleString('en-IN'),
        record.days91_plus.toLocaleString('en-IN'),
        record.lastPaymentDate
    ]);

    doc.autoTable({
        startY: 45,
        head: [tableColumn],
        body: tableRows,
        headStyles: { fillColor: [0, 150, 200], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [240, 240, 240] },
        margin: { top: 45 },
    });

    doc.save(`${title.replace(/\s+/g, '_')}_${new Date().getTime()}.pdf`);
};

/**
 * Export data to Excel
 */
export const exportExcelData = (fileName: string, data: AgingRecord[]) => {
    const worksheet = XLSX.utils.json_to_sheet(data.map(record => ({
        "Dealer Name": record.dealerName,
        "Total Outstanding (INR)": record.totalOutstanding,
        "0-30 Days": record.days0_30,
        "31-60 Days": record.days31_60,
        "61-90 Days": record.days61_90,
        "90+ Days": record.days91_plus,
        "Last Payment Date": record.lastPaymentDate
    })));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Aging Data");

    // Create a blob and trigger download
    XLSX.writeFile(workbook, `${fileName.replace(/\s+/g, '_')}_${new Date().getTime()}.xlsx`);
};
