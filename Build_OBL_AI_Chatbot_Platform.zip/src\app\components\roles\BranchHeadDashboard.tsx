import { motion } from 'motion/react';
import { Users, TrendingUp, Package, AlertTriangle, Trophy, Activity } from 'lucide-react';
import { branchTeamMembers, branchInventory } from '../../data/roleFeatures';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export function BranchHeadDashboard() {
  const topPerformer = branchTeamMembers.reduce((prev, current) => 
    prev.achievement > current.achievement ? prev : current
  );
  const needsAttention = branchTeamMembers.filter(m => m.achievement < 80);

  const teamData = branchTeamMembers.map(m => ({
    name: m.name.split(' ')[0],
    achievement: m.achievement,
    sales: m.sales / 100000,
    id: m.id,
  }));

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Header Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">Team Size</span>
            </div>
            <p className="text-2xl font-bold text-white">{branchTeamMembers.length}</p>
            <p className="text-xs text-blue-400 mt-1">Active salespeople</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl border border-green-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-sm text-gray-400">Avg Achievement</span>
            </div>
            <p className="text-2xl font-bold text-white">
              {(branchTeamMembers.reduce((sum, m) => sum + m.achievement, 0) / branchTeamMembers.length).toFixed(1)}%
            </p>
            <p className="text-xs text-green-400 mt-1">Branch average</p>
          </div>

          <div className="bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Trophy className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">Top Performer</span>
            </div>
            <p className="text-lg font-bold text-white">{topPerformer.name.split(' ')[0]}</p>
            <p className="text-xs text-blue-400 mt-1">{topPerformer.achievement}% achieved</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-xl border border-orange-500/30 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <AlertTriangle className="w-5 h-5 text-orange-400" />
              <span className="text-sm text-gray-400">Needs Attention</span>
            </div>
            <p className="text-2xl font-bold text-white">{needsAttention.length}</p>
            <p className="text-xs text-orange-400 mt-1">Below 80% target</p>
          </div>
        </div>

        {/* Team Performance Chart */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-cyan-400" />
            Team Performance Comparison
          </h3>

          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%" key="branch-team-performance">
              <BarChart data={teamData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" key="grid-branch" />
                <XAxis dataKey="name" stroke="#9CA3AF" key="xaxis-branch" />
                <YAxis stroke="#9CA3AF" key="yaxis-branch" />
                <Tooltip
                  key="tooltip-branch"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="sales" name="Sales (Lakhs)" radius={[8, 8, 0, 0]} key="bar-sales-performance">
                  {teamData.map((entry, index) => (
                    <Cell 
                      key={`cell-${entry.id}`}
                      fill={entry.achievement >= 100 ? '#10B981' : entry.achievement >= 85 ? '#06B6D4' : '#F59E0B'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Team Members Detail */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-purple-400" />
            Team Members Detail
          </h3>

          <div className="space-y-3">
            {branchTeamMembers.map((member, idx) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                      <span className="text-white font-bold">{member.name.charAt(0)}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white">{member.name}</h4>
                      <p className="text-xs text-gray-400">{member.territory}</p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-lg text-xs font-medium ${
                    member.achievement >= 100
                      ? 'bg-green-500/20 text-green-400'
                      : member.achievement >= 80
                      ? 'bg-cyan-500/20 text-cyan-400'
                      : 'bg-orange-500/20 text-orange-400'
                  }`}>
                    {member.achievement}% Achieved
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400 text-xs">Sales</p>
                    <p className="text-white font-semibold">
                      <span className="font-extrabold">₹</span> {(member.sales / 100000).toFixed(1)}L
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs">Visits</p>
                    <p className="text-white font-semibold">{member.visits}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs">Status</p>
                    <p className={`font-semibold ${member.status === 'active' ? 'text-green-400' : 'text-gray-400'}`}>
                      {member.status}
                    </p>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-3">
                  <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        member.achievement >= 100
                          ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                          : member.achievement >= 80
                          ? 'bg-gradient-to-r from-cyan-500 to-blue-600'
                          : 'bg-gradient-to-r from-orange-500 to-red-500'
                      }`}
                      style={{ width: `${Math.min(member.achievement, 100)}%` }}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Branch Inventory Status */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Package className="w-5 h-5 text-orange-400" />
            Branch Inventory Status
          </h3>

          <div className="space-y-3">
            {branchInventory.map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="p-4 rounded-xl bg-white/5 border border-white/10"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-white">{item.category}</h4>
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    item.status === 'healthy'
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {item.status === 'healthy' ? 'Healthy' : 'Low Stock'}
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-400">Current Stock</span>
                  <span className="text-white font-semibold">{item.stock.toLocaleString()} sq ft</span>
                </div>

                <div className="flex items-center justify-between text-sm mb-3">
                  <span className="text-gray-400">Min Level</span>
                  <span className="text-gray-300">{item.minLevel.toLocaleString()} sq ft</span>
                </div>

                {/* Stock bar */}
                <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      item.status === 'healthy'
                        ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                        : 'bg-gradient-to-r from-red-500 to-orange-500'
                    }`}
                    style={{ width: `${Math.min((item.stock / item.minLevel) * 50, 100)}%` }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}