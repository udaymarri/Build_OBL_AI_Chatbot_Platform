// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDeppU_hYU6jsP5nYa8C668eAC2OwtKGCc",
    authDomain: "bol-ai-chatbot.firebaseapp.com",
    projectId: "bol-ai-chatbot",
    storageBucket: "bol-ai-chatbot.firebasestorage.app",
    messagingSenderId: "167617445332",
    appId: "1:167617445332:web:221accbc4e09e51aac2a41",
    measurementId: "G-RYBE8N91FR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Analytics (Only in browser environments where supported)
let analytics;
if (typeof window !== 'undefined') {
    isSupported().then((supported) => {
        if (supported) {
            analytics = getAnalytics(app);
        }
    });
}

// Initialize Firestore
export const db = getFirestore(app);
export const auth = getAuth(app);
export { app, analytics };
