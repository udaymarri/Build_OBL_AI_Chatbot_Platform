import { motion } from 'motion/react';
import { Building2 } from 'lucide-react';
import { memo } from 'react';

// Memoize to prevent re-renders
export const Logo3D = memo(function Logo3D() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8 }}
      className="w-24 h-24 relative perspective-1000"
    >
      {/* Optimized 3D Cube - slower rotation for better performance */}
      <motion.div 
        className="w-full h-full relative preserve-3d"
        animate={{ 
          rotateY: 360,
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        {/* Front face - Cyan gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 via-blue-500 to-cyan-600 rounded-lg shadow-2xl shadow-cyan-500/50 flex items-center justify-center"
             style={{ transform: 'translateZ(48px)' }}>
          <Building2 className="w-10 h-10 text-white/80" />
        </div>
        
        {/* Right face - Blue gradient transition */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-600 rounded-lg opacity-90"
             style={{ transform: 'rotateY(90deg) translateZ(48px)' }} />
        
        {/* Back face - Deep blue gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-indigo-600 to-blue-800 rounded-lg opacity-85"
             style={{ transform: 'rotateY(180deg) translateZ(48px)' }} />
        
        {/* Left face - Navy to cyan transition */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-700 via-blue-500 to-cyan-500 rounded-lg opacity-90"
             style={{ transform: 'rotateY(-90deg) translateZ(48px)' }} />
        
        {/* Top face - Royal blue gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-blue-700 to-blue-800 rounded-lg opacity-80"
             style={{ transform: 'rotateX(90deg) translateZ(48px)' }} />
        
        {/* Bottom face - Deep navy gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-800 via-indigo-700 to-blue-900 rounded-lg opacity-75"
             style={{ transform: 'rotateX(-90deg) translateZ(48px)' }} />
      </motion.div>

      {/* Simplified glow effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 to-blue-700 rounded-lg blur-2xl opacity-30 -z-10" />
    </motion.div>
  );
});