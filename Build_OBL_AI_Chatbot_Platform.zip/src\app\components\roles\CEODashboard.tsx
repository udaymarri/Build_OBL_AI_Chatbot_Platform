import { motion } from 'motion/react';
import { 
  Briefcase, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Building2,
  Target,
  Globe,
  Zap,
  Award
} from 'lucide-react';
import { executiveSummary, financialMetrics, competitiveAnalysis, strategicInitiatives } from '../../data/roleFeatures';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';

export function CEODashboard() {
  const latestQuarter = financialMetrics[financialMetrics.length - 1];

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Executive Summary Header */}
        <div className="bg-gradient-to-br from-blue-700/20 via-indigo-600/20 to-blue-800/20 backdrop-blur-xl border border-blue-600/30 rounded-3xl p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center">
              <Briefcase className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white">Executive Command Center</h2>
              <p className="text-gray-300">Real-time enterprise intelligence & strategic insights</p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="text-sm text-gray-300 mb-1">Annual Revenue</p>
              <p className="text-2xl font-bold text-white">
                <span className="font-extrabold">₹</span> {(executiveSummary.totalRevenue / 100000000).toFixed(0)}Cr
              </p>
              <p className="text-xs text-green-400 mt-1">↑ {executiveSummary.yearlyGrowth}% YoY</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="text-sm text-gray-300 mb-1">Market Share</p>
              <p className="text-2xl font-bold text-white">{executiveSummary.marketShare}%</p>
              <p className="text-xs text-cyan-400 mt-1">Industry position #2</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="text-sm text-gray-300 mb-1">Profit Margin</p>
              <p className="text-2xl font-bold text-white">{executiveSummary.profitMargin}%</p>
              <p className="text-xs text-purple-400 mt-1">Above industry avg</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <p className="text-sm text-gray-300 mb-1">Total Employees</p>
              <p className="text-2xl font-bold text-white">{executiveSummary.totalEmployees}</p>
              <p className="text-xs text-orange-400 mt-1">{executiveSummary.branches} branches</p>
            </div>
          </div>
        </div>

        {/* Financial Performance */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              Quarterly Financial Performance
            </h3>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs text-gray-400">Latest Profit</p>
                <p className="text-lg font-bold text-green-400">₹{(latestQuarter.profit / 10000000).toFixed(0)}Cr</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-400">Margin</p>
                <p className="text-lg font-bold text-cyan-400">{latestQuarter.margin}%</p>
              </div>
            </div>
          </div>

          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%" key="ceo-financial-performance">
              <AreaChart data={financialMetrics}>
                <defs>
                  <linearGradient id="ceoColorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06B6D4" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="ceoColorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" key="grid-ceo-financial" />
                <XAxis dataKey="quarter" stroke="#9CA3AF" key="xaxis-ceo-financial" />
                <YAxis stroke="#9CA3AF" label={{ value: 'Crores (₹)', angle: -90, position: 'insideLeft', fill: '#9CA3AF' }} key="yaxis-ceo-financial" />
                <Tooltip
                  key="tooltip-ceo-financial"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
                <Legend key="legend-ceo-financial" />
                <Area type="monotone" dataKey="revenue" name="Revenue (Cr)" stroke="#06B6D4" fillOpacity={1} fill="url(#ceoColorRevenue)" key="area-revenue" />
                <Area type="monotone" dataKey="profit" name="Profit (Cr)" stroke="#10B981" fillOpacity={1} fill="url(#ceoColorProfit)" key="area-profit" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Competitive Analysis */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 mb-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-yellow-400" />
            Competitive Landscape Analysis
          </h3>

          <div className="h-80 mb-4">
            <ResponsiveContainer width="100%" height="100%" key="ceo-competitive-analysis">
              <BarChart data={competitiveAnalysis} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" key="grid-ceo-competitive" />
                <XAxis type="number" stroke="#9CA3AF" key="xaxis-ceo-competitive" />
                <YAxis dataKey="company" type="category" stroke="#9CA3AF" width={150} key="yaxis-ceo-competitive" />
                <Tooltip
                  key="tooltip-ceo-competitive"
                  contentStyle={{
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '8px',
                  }}
                />
                <Legend key="legend-ceo-competitive" />
                <Bar dataKey="marketShare" name="Market Share %" fill="#06B6D4" radius={[0, 8, 8, 0]} key="bar-marketshare" />
                <Bar dataKey="growth" name="Growth %" fill="#10B981" radius={[0, 8, 8, 0]} key="bar-growth" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30">
              <p className="text-sm text-gray-300 mb-1">Our Position</p>
              <p className="text-3xl font-bold text-white">#2</p>
              <p className="text-xs text-cyan-400 mt-1">In market share</p>
            </div>
            <div className="p-4 rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30">
              <p className="text-sm text-gray-300 mb-1">Growth Lead</p>
              <p className="text-3xl font-bold text-white">+6.2%</p>
              <p className="text-xs text-green-400 mt-1">Above competitor avg</p>
            </div>
            <div className="p-4 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30">
              <p className="text-sm text-gray-300 mb-1">Gap to #1</p>
              <p className="text-3xl font-bold text-white">3.7%</p>
              <p className="text-xs text-purple-400 mt-1">Closing rapidly</p>
            </div>
          </div>
        </div>

        {/* Strategic Initiatives */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-orange-400" />
            Strategic Initiatives Tracker
          </h3>

          <div className="space-y-4">
            {strategicInitiatives.map((initiative, idx) => (
              <motion.div
                key={initiative.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="p-5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="font-semibold text-white text-lg mb-1">{initiative.title}</h4>
                    <p className="text-sm text-gray-400">Deadline: {new Date(initiative.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className={`px-3 py-1 rounded-lg text-xs font-medium ${
                      initiative.status === 'On Track'
                        ? 'bg-green-500/20 text-green-400'
                        : initiative.status === 'In Progress'
                        ? 'bg-cyan-500/20 text-cyan-400'
                        : 'bg-orange-500/20 text-orange-400'
                    }`}>
                      {initiative.status}
                    </div>
                    <div className={`px-3 py-1 rounded-lg text-xs font-medium ${
                      initiative.impact === 'High'
                        ? 'bg-red-500/20 text-red-400'
                        : 'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {initiative.impact} Impact
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-400">Progress</span>
                      <span className="text-sm font-semibold text-white">{initiative.completion}%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${initiative.completion}%` }}
                        transition={{ duration: 1, delay: idx * 0.1 }}
                        className={`h-full rounded-full ${
                          initiative.completion >= 75
                            ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                            : initiative.completion >= 50
                            ? 'bg-gradient-to-r from-cyan-500 to-blue-600'
                            : 'bg-gradient-to-r from-orange-500 to-red-500'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <Globe className="w-6 h-6 text-blue-400" />
              <h4 className="font-semibold text-white">Network Coverage</h4>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Zones</span>
                <span className="text-white font-semibold">{executiveSummary.zones}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Branches</span>
                <span className="text-white font-semibold">{executiveSummary.branches}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Dealers</span>
                <span className="text-white font-semibold">{executiveSummary.totalDealers}</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-xl border border-green-500/30 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <TrendingUp className="w-6 h-6 text-green-400" />
              <h4 className="font-semibold text-white">Growth Metrics</h4>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">YoY Growth</span>
                <span className="text-green-400 font-semibold">+{executiveSummary.yearlyGrowth}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Market Share</span>
                <span className="text-green-400 font-semibold">{executiveSummary.marketShare}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Profit Margin</span>
                <span className="text-green-400 font-semibold">{executiveSummary.profitMargin}%</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <Users className="w-6 h-6 text-purple-400" />
              <h4 className="font-semibold text-white">Human Capital</h4>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Employees</span>
                <span className="text-white font-semibold">{executiveSummary.totalEmployees}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Sales Team</span>
                <span className="text-white font-semibold">~450</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Avg Productivity</span>
                <span className="text-purple-400 font-semibold">
                  <span className="font-extrabold">₹</span> 2.8Cr/person
                </span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}