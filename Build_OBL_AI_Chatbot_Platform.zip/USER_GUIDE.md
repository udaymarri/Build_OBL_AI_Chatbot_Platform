# OBL AI - User Guide

## Welcome to OBL AI Conversational Intelligence Assistant

This guide will help you get started with the enterprise AI chatbot platform.

---

## 🚀 Getting Started

### Step 1: Select Your Role
When you first open the application, you'll see the login screen with 5 role options:

1. **Salesperson** - Access territory-level data
2. **Branch Head** - View branch performance
3. **Zonal Manager** - Monitor zone-wide metrics
4. **India Head** - Regional analytics
5. **CEO** - Complete enterprise overview

Click on your role card and press **"Enter Dashboard"**

### Step 2: Explore the Dashboard
After login, you'll land on the **AI Assistant** screen by default. The interface has three main areas:

- **Left Sidebar** - Navigation menu
- **Center Panel** - AI chat interface
- **Right Panel** - Live analytics (desktop only)

---

## 💬 How to Use the AI Assistant

### Quick Actions
At the top of the chat, you'll see three colorful buttons for instant queries:
- **Show sales trends** (Blue)
- **Dealer recommendations** (Purple)
- **Gap selling opportunities** (Green)

### Typing Your Query
Simply type your question in natural language and press **Send** or hit **Enter**.

### Sample Queries to Try

#### 📊 Sales & Revenue
```
"What is my sales revenue?"
"Show sales growth for last 6 months"
"Compare this month with last month"
"Show my target achievement"
```

#### 💰 Outstanding & Collections
```
"What is my outstanding amount?"
"Which dealers have overdue payments?"
"Show collection status"
```

#### 👥 Dealer & Visit Management
```
"Which dealer should I visit today?"
"Show top priority visits"
"Dealer visit recommendations"
"Show route optimization"
```

#### 🎯 Recommendations
```
"Show gap selling opportunities"
"Which products can I upsell?"
"Cross selling recommendations"
"Show me dealers for Marble Series"
```

#### 🎁 Schemes & Offers
```
"What are the active schemes?"
"Show current offers"
"Which dealers qualify for bulk discount?"
```

#### 📦 Products
```
"Show product catalog"
"What is the price of Marble Series?"
"Show all vitrified tiles"
```

---

## 🎛️ Dashboard Navigation

### Left Sidebar Menu

#### 🏠 Dashboard
- View **draggable KPI cards** (Sales, Outstanding, Visits, Target)
- See sales trend charts
- Monitor real-time performance

**Pro Tip**: You can **drag and rearrange** the KPI cards to customize your view!

#### 💬 AI Assistant
- Main chat interface
- Ask questions in natural language
- Get instant AI responses with charts

#### 📈 Analytics
- Detailed charts and visualizations
- Export reports (simulated)
- Historical trend analysis

#### 👥 Dealers
Coming soon - Dealer management interface

#### 📦 Products
- Interactive **3D product showcase**
- Browse Orientbell tile catalog
- View prices and specifications
- **Rotating 3D tiles** for each product

#### 📄 Reports
Coming soon - Generate and download reports

---

## 🎨 UI Features

### Glassmorphism Design
The entire interface uses modern "frosted glass" effects with:
- Semi-transparent panels
- Backdrop blur
- Subtle borders
- Glow effects on hover

### 3D Graphics
- **Login Screen**: Rotating 3D cube logo
- **Product Catalog**: Interactive 3D tile models
- **Particles**: Animated background network

### Smooth Animations
- Page transitions
- Card hover effects
- Button micro-interactions
- Typing indicators
- Chart animations

### Drag & Drop
On the **Dashboard** screen, you can:
1. Grab any KPI card by clicking and holding
2. Drag it to a new position
3. Release to drop
4. Your layout is customized!

---

## 📊 Understanding AI Responses

### Text Responses
The AI provides contextual answers based on your role. For example:
- Salesperson sees territory data
- CEO sees company-wide metrics

### Charts
The AI auto-generates visualizations:
- **Line Charts** - Sales trends over time
- **Bar Charts** - Comparative analysis
- **Tables** - Detailed data breakdowns

### Smart Suggestions
After each answer, you'll see **follow-up suggestions** in gray boxes. Click them to continue the conversation!

---

## 🎯 KPI Metrics Explained

### Sales Revenue
Total sales value in your scope (territory/branch/zone/company)

### Outstanding Amount
Pending payments from dealers

### Visit Count
Number of dealer visits completed

### Target Achievement
Percentage of monthly target completed

### Pending Orders
Orders placed but not yet delivered

---

## 🔄 Role-Based Data Access

Your role determines what data you see:

| Role | Data Scope | Example Query Result |
|------|-----------|---------------------|
| Salesperson | Territory only | "Your territory outstanding: ₹8.5L" |
| Branch Head | Branch level | "Mumbai branch revenue: ₹28.5Cr" |
| Zonal Manager | Zone wide | "West zone achievement: 88%" |
| India Head | Regional | "North India visits: 2,100" |
| CEO | Company wide | "Total company revenue: ₹125Cr" |

---

## 🎨 Customization

### Theme Toggle
Click the **Sun/Moon icon** in the sidebar footer to switch themes (coming soon)

### Layout
- **Collapse Sidebar**: Click the hamburger menu (☰) in top-left
- **Drag KPIs**: Rearrange dashboard cards
- **Resize Panels**: Adjust view as needed

---

## 📱 Responsive Design

The application works on:
- **Desktop** (recommended) - Full 3-panel layout
- **Tablet** - Collapsible sidebar
- **Mobile** - Stacked layout

---

## 🎤 Voice Input

Click the **microphone icon** in the chat input to activate voice query (simulated feature).

---

## 💾 Export & Download

### Charts
Click the **Download** button in the Analytics panel to export charts as PDF (simulated).

### Reports
Use the **Reports** section to generate custom reports (coming soon).

---

## 🔔 Live Indicator

The green **"● Live"** badge in the top-right shows the system is connected and receiving real-time data.

---

## 🎓 Tips & Tricks

### 1. Use Natural Language
Don't worry about exact keywords. The AI understands:
- "Show me money owed" = Outstanding
- "Who should I meet?" = Visit recommendations
- "What can I sell more?" = Gap opportunities

### 2. Follow Suggestions
The AI provides smart follow-ups after each answer. Click them to dive deeper!

### 3. Explore Different Sections
Switch between Dashboard, Chat, Analytics, and Products to see different views of your data.

### 4. Try Specific Queries
Be specific for better results:
- ❌ "Sales"
- ✅ "Show sales growth for last 6 months"

### 5. Check the 3D Products
Go to **Products** section to see interactive 3D tile models. You can rotate them with your mouse!

---

## ❓ Common Questions

### Q: Can I export the charts?
A: Yes! Click the **Download** button in the Analytics panel (currently simulated).

### Q: How do I see dealer details?
A: Ask the AI: "Show dealer information for [dealer name]"

### Q: Can I filter by date range?
A: Try: "Show sales for Q4 2025" or "Last 3 months revenue"

### Q: How accurate is the data?
A: This is a demo with sample data. In production, it would connect to your real ERP/CRM systems.

### Q: What if the AI doesn't understand?
A: Try rephrasing your question or use one of the suggested queries.

---

## 🛠️ Troubleshooting

### Issue: Sidebar disappeared
**Solution**: Click the hamburger menu (☰) in top-left to toggle

### Issue: Charts not loading
**Solution**: Refresh the page or ask the AI a specific chart query

### Issue: 3D products not rotating
**Solution**: Use your mouse to drag on the 3D model

### Issue: Role data seems wrong
**Solution**: Logout and select the correct role again

---

## 🔐 Security Note

This is a **demonstration application** with simulated data. For production use:
- Real authentication required
- Backend database needed
- API security implementation
- Role permissions enforced server-side
- Encryption for sensitive data

---

## 📞 Support

For questions or issues with the platform:
- Contact your IT administrator
- Refer to the technical documentation (README.md)
- Check the system status indicator

---

## 🎉 Enjoy Your AI Assistant!

The OBL AI platform is designed to make your work easier by providing instant access to business insights through natural conversation. Explore, experiment, and discover new ways to use AI for smarter decision-making!

**Happy Querying!** 🚀
