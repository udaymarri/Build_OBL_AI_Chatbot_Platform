import { useState, useEffect, lazy, Suspense } from 'react';
import { useNavigate } from 'react-router';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { motion, AnimatePresence } from 'motion/react';
import {
  Menu,
  X,
  Home,
  MessageSquare,
  TrendingUp,
  Users,
  Package,
  Settings,
  LogOut,
  Sun,
  Moon,
  DollarSign,
  Target,
  Calendar,
  FileText,
  Navigation,
  Sparkles,
  Bot,
} from 'lucide-react';
import { NetworkBackground3D } from '../components/NetworkBackground3D';
import { FloatingShapes3D } from '../components/FloatingShapes3D';
import { AnimatedGradient } from '../components/AnimatedGradient';
import { ChatInterface } from '../components/ChatInterfaceAdvanced';
import { AnalyticsPanel } from '../components/AnalyticsPanel';
import { DraggableKPI } from '../components/DraggableKPI';
import { Button } from '../components/ui/button';

// Lazy load heavy components
const LocationMap = lazy(() => import('../components/LocationMap').then(module => ({ default: module.LocationMap })));
import { getKPIData, products, reports, dealers } from '../data/mockData';
import { Product3DTile } from '../components/Product3DTileAdvanced';
import { WelcomeModal } from '../components/WelcomeModal';
import { SalespersonDashboard } from '../components/roles/SalespersonDashboard';
import { BranchHeadDashboard } from '../components/roles/BranchHeadDashboard';
import { ZonalManagerDashboard } from '../components/roles/ZonalManagerDashboard';
import { IndiaHeadDashboard } from '../components/roles/IndiaHeadDashboard';
import { CEODashboard } from '../components/roles/CEODashboard';
import { VisitRecommendations } from '../components/VisitRecommendations';
import { AvatarSelector } from '../components/AvatarSelector';
import { useMsal } from '@azure/msal-react';
import { ExcelDataGrid } from '../components/ExcelDataGrid';
import { generateAgingData, downloadPDFReport, exportExcelData } from '../utils/reportUtils';
import { auth, db } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, updateDoc } from 'firebase/firestore';

// Avatar gradient options
const avatarGradients: Record<string, string> = {
  'male-premium-royal': 'from-indigo-600 via-blue-700 to-blue-800',
  'female-premium-royal': 'from-blue-600 via-indigo-600 to-blue-700',
  'male-premium-ocean': 'from-blue-600 via-cyan-600 to-teal-600',
  'female-premium-ocean': 'from-sky-600 via-blue-600 to-indigo-600',
  'male-premium-sunset': 'from-orange-600 via-red-600 to-rose-600',
  'female-premium-sunset': 'from-amber-600 via-orange-600 to-red-600',
  'male-premium-emerald': 'from-green-600 via-emerald-600 to-teal-600',
  'female-premium-emerald': 'from-teal-600 via-green-600 to-lime-600',
  'male-premium-gold': 'from-yellow-600 via-amber-600 to-orange-600',
  'female-premium-gold': 'from-amber-600 via-yellow-600 to-orange-600',
  'male-premium-cosmic': 'from-violet-600 via-purple-600 to-indigo-600',
  'female-premium-cosmic': 'from-fuchsia-600 via-violet-600 to-purple-600',
  // Legacy support
  'gradient-purple': 'from-indigo-600 via-purple-600 to-pink-600',
  'gradient-blue': 'from-blue-600 via-cyan-600 to-teal-600',
  'gradient-green': 'from-green-600 via-emerald-600 to-teal-600',
  'gradient-orange': 'from-orange-600 via-red-600 to-rose-600',
  'gradient-indigo': 'from-indigo-600 via-purple-600 to-pink-600',
  'gradient-teal': 'from-teal-600 via-blue-600 to-indigo-600',
  'gradient-pink': 'from-rose-600 via-pink-600 to-fuchsia-600',
  'gradient-yellow': 'from-yellow-600 via-amber-600 to-orange-600',
  'gradient-violet': 'from-violet-600 via-purple-600 to-indigo-600',
  'gradient-cyan': 'from-blue-600 via-cyan-600 to-teal-600',
  'gradient-lime': 'from-teal-600 via-green-600 to-lime-600',
  'gradient-amber': 'from-amber-600 via-yellow-600 to-orange-600',
};

// Avatar emoji mapping
const avatarEmojis: Record<string, string> = {
  'male-premium-royal': '👨‍💼',
  'female-premium-royal': '👩‍💼',
  'male-premium-ocean': '👨‍💻',
  'female-premium-ocean': '👩‍💻',
  'male-premium-sunset': '👨‍🔬',
  'female-premium-sunset': '👩‍🔬',
  'male-premium-emerald': '👨‍🎓',
  'female-premium-emerald': '👩‍🎓',
  'male-premium-gold': '👨‍⚖️',
  'female-premium-gold': '👩‍⚖️',
  'male-premium-cosmic': '👨‍🚀',
  'female-premium-cosmic': '👩‍🚀',
};

// Main Dashboard Component
export default function Dashboard() {
  const navigate = useNavigate();
  const { instance } = useMsal();
  const [userRole, setUserRole] = useState('');
  const [userName, setUserName] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [activeSection, setActiveSection] = useState('chat');
  const [chartData, setChartData] = useState<any>(null);
  const [kpiData, setKpiData] = useState<any>(null);
  const [showWelcome, setShowWelcome] = useState(false);
  const [showAvatarSelector, setShowAvatarSelector] = useState(false);
  const [userAvatar, setUserAvatar] = useState('male-premium-royal');
  const [selectedReport, setSelectedReport] = useState<any>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        // Only redirect if no localStorage fallback either (for guest mode)
        const guestRole = localStorage.getItem('userRole');
        if (!guestRole) {
          navigate('/');
        } else {
          setUserRole(guestRole || '');
          setKpiData(getKPIData(guestRole || 'salesperson'));
          setUserName(localStorage.getItem('userName') || 'Guest');
          setUserAvatar(localStorage.getItem('userAvatar') || 'male-premium-royal');
        }
        return;
      }

      // User is signed in via Firebase
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          setUserRole(userData.role);
          setUserName(userData.name);
          setKpiData(getKPIData(userData.role));

          if (userData.avatar) {
            setUserAvatar(userData.avatar);
          } else {
            // Fallback to gendered default if no avatar saved in firestore
            const defaultAvatar = userData.name.toLowerCase().includes('sharma') ? 'female-premium-royal' : 'male-premium-royal';
            setUserAvatar(defaultAvatar);
          }
        }
      } catch (error) {
        console.error("Error fetching user data from Firestore:", error);
      }
    });

    return () => unsub();
  }, [navigate]);

  const handleAvatarSelect = async (avatarId: string) => {
    setUserAvatar(avatarId);
    localStorage.setItem('userAvatar', avatarId);

    // Save to Firestore if user is authenticated
    if (auth.currentUser) {
      try {
        await updateDoc(doc(db, 'users', auth.currentUser.uid), {
          avatar: avatarId
        });
      } catch (error) {
        console.error("Error updating avatar in Firestore:", error);
      }
    }
  };

  const handleLogout = async () => {
    localStorage.removeItem('userRole');
    localStorage.removeItem('userName');
    localStorage.removeItem('userAvatar');

    try {
      await auth.signOut();
      await instance.logoutPopup();
    } catch (error) {
      console.error("Logout error:", error);
    }
    navigate('/');
  };

  const navItems = [
    { id: 'home', icon: Home, label: 'Dashboard', color: 'text-cyan-400' },
    { id: 'my-role', icon: Target, label: 'My Role', color: 'text-yellow-400' },
    { id: 'chat', icon: MessageSquare, label: 'AI Assistant', color: 'text-purple-400' },
    { id: 'analytics', icon: TrendingUp, label: 'Analytics', color: 'text-green-400' },
    { id: 'visit-recommendations', icon: Navigation, label: 'Visit Planner', color: 'text-orange-400' },
    { id: 'dealers', icon: Users, label: 'Dealers', color: 'text-blue-400' },
    { id: 'products', icon: Package, label: 'Products', color: 'text-orange-400' },
    { id: 'reports', icon: FileText, label: 'Reports', color: 'text-pink-400' },
  ];

  if (!kpiData) return null;

  return (
    <DndProvider backend={HTML5Backend}>
      <div className={(isDarkMode
        ? 'bg-gradient-to-br from-gray-900 via-black to-gray-900'
        : 'bg-gradient-to-br from-gray-50 via-white to-gray-100') + ' fixed inset-0 w-full h-full overflow-hidden transition-colors duration-500'}>

        {/* Particle Background */}
        {isDarkMode && (
          <>
            <div className="absolute inset-0 w-full h-full">
              <NetworkBackground3D />
            </div>
            <FloatingShapes3D />
          </>
        )}

        {/* Advanced Animated Gradient Orbs */}
        {isDarkMode && (
          <>
            <motion.div
              className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-cyan-500/20 rounded-full blur-3xl"
              animate={{
                x: [0, 50, 0],
                y: [0, 30, 0],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            <motion.div
              className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-purple-500/20 rounded-full blur-3xl"
              animate={{
                x: [0, -30, 0],
                y: [0, -50, 0],
                scale: [1, 1.15, 1],
              }}
              transition={{
                duration: 10,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            <motion.div
              className="absolute top-1/2 left-1/2 w-[400px] h-[400px] bg-pink-500/15 rounded-full blur-3xl"
              animate={{
                x: [-200, -150, -200],
                y: [-200, -250, -200],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 12,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </>
        )}

        {/* Grid overlay for futuristic effect */}
        {isDarkMode && (
          <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.03)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,#000,transparent)]" />
        )}

        <div className="relative z-10 flex w-full h-full">
          {/* Sidebar */}
          <AnimatePresence>
            {isSidebarOpen && (
              <motion.aside
                initial={{ x: -300 }}
                animate={{ x: 0 }}
                exit={{ x: -300 }}
                transition={{ type: 'spring', damping: 20 }}
                className={`fixed md:relative z-20 w-72 h-screen ${isDarkMode ? 'bg-black/40' : 'bg-white/80'
                  } backdrop-blur-xl border-r ${isDarkMode ? 'border-white/10' : 'border-gray-200'
                  } flex flex-col shadow-2xl`}
                style={{
                  boxShadow: isDarkMode ? '0 0 80px rgba(6, 182, 212, 0.15)' : 'none'
                }}
              >
                {/* Animated border glow */}
                {isDarkMode && (
                  <motion.div
                    className="absolute inset-0 rounded-l-2xl"
                    style={{
                      background: 'linear-gradient(180deg, rgba(6,182,212,0.1) 0%, transparent 50%, rgba(147,51,234,0.1) 100%)',
                      pointerEvents: 'none'
                    }}
                    animate={{
                      opacity: [0.3, 0.5, 0.3],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                )}

                {/* Logo */}
                <div className={`p-6 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'} relative z-10`}>
                  <motion.div
                    className="flex items-center gap-3"
                    whileHover={{ scale: 1.02 }}
                  >
                    <motion.div
                      className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg relative"
                      style={{ boxShadow: '0 10px 40px rgba(6, 182, 212, 0.3)' }}
                      animate={{
                        boxShadow: [
                          '0 10px 40px rgba(6, 182, 212, 0.3)',
                          '0 10px 60px rgba(6, 182, 212, 0.5)',
                          '0 10px 40px rgba(6, 182, 212, 0.3)',
                        ]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      <span className="text-white font-bold text-xl relative z-10">OBL</span>
                      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl blur-md opacity-50" />
                    </motion.div>
                    <div>
                      <h1 className={`${isDarkMode ? 'text-white' : 'text-gray-900'} font-bold text-lg`}>OBL AI</h1>
                      <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} text-xs`}>Intelligence Assistant</p>
                    </div>
                  </motion.div>
                </div>

                {/* User Profile */}
                <div className={`p-6 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'} relative z-10`}>
                  <div className="flex items-center gap-3">
                    <motion.button
                      onClick={() => setShowAvatarSelector(true)}
                      className={`w-12 h-12 bg-gradient-to-br ${avatarGradients[userAvatar]} rounded-full flex items-center justify-center ring-2 shadow-lg relative ${isDarkMode ? 'ring-white/20 hover:ring-white/40' : 'ring-gray-300 hover:ring-gray-400'
                        }`}
                      whileHover={{
                        scale: 1.1,
                        rotate: [0, -5, 5, 0],
                      }}
                      whileTap={{ scale: 0.95 }}
                      transition={{ duration: 0.3 }}
                    >
                      {avatarEmojis[userAvatar] ? (
                        <span className="text-2xl relative z-10">{avatarEmojis[userAvatar]}</span>
                      ) : (
                        <span className="text-white font-bold text-lg relative z-10">{userName.charAt(0)}</span>
                      )}
                      {/* Avatar glow */}
                      <motion.div
                        className={`absolute inset-0 bg-gradient-to-br ${avatarGradients[userAvatar]} rounded-full blur-xl opacity-50`}
                        animate={{
                          scale: [1, 1.2, 1],
                          opacity: [0.5, 0.7, 0.5],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                    </motion.button>
                    <div className="flex-1">
                      <h3 className={`${isDarkMode ? 'text-white' : 'text-gray-900'} font-semibold`}>{userName}</h3>
                      <p className={(isDarkMode ? 'text-gray-400' : 'text-gray-600') + ' text-xs capitalize'}>
                        {userRole.replace('_', ' ')}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Navigation */}
                <nav className="flex-1 p-4 overflow-y-auto">
                  {navItems.map((item) => (
                    <motion.button
                      key={item.id}
                      onClick={() => setActiveSection(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl mb-2 transition-all ${activeSection === item.id
                        ? isDarkMode
                          ? 'bg-white/10 text-white'
                          : 'bg-cyan-100 text-cyan-900'
                        : isDarkMode
                          ? 'text-gray-400 hover:bg-white/5 hover:text-white'
                          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                        }`}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <item.icon className={`w-5 h-5 ${activeSection === item.id ? item.color : ''}`} />
                      <span>{item.label}</span>
                    </motion.button>
                  ))}
                </nav>

                {/* Footer Actions */}
                <div className={`p-4 border-t ${isDarkMode ? 'border-white/10' : 'border-gray-200'} space-y-2`}>
                  <Button
                    onClick={() => setIsDarkMode(!isDarkMode)}
                    variant="ghost"
                    className={`w-full justify-start ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'
                      }`}
                  >
                    {isDarkMode ? <Sun className="w-5 h-5 mr-3" /> : <Moon className="w-5 h-5 mr-3" />}
                    {isDarkMode ? 'Light Mode' : 'Dark Mode'}
                  </Button>

                  <Button
                    onClick={handleLogout}
                    variant="ghost"
                    className={`w-full justify-start ${isDarkMode ? 'text-gray-400 hover:text-red-400' : 'text-gray-600 hover:text-red-600'
                      }`}
                  >
                    <LogOut className="w-5 h-5 mr-3" />
                    Logout
                  </Button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Main Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Top Bar */}
            <header className={`h-16 ${isDarkMode ? 'bg-black/40' : 'bg-white/80'
              } backdrop-blur-xl border-b ${isDarkMode ? 'border-white/10' : 'border-gray-200'
              } flex items-center justify-between px-6 relative shadow-lg`}
              style={{
                boxShadow: isDarkMode ? '0 4px 30px rgba(0, 0, 0, 0.3)' : '0 4px 30px rgba(0, 0, 0, 0.1)'
              }}
            >
              {/* Animated top border glow */}
              {isDarkMode && (
                <motion.div
                  className="absolute top-0 left-0 right-0 h-0.5"
                  style={{
                    background: 'linear-gradient(90deg, transparent, rgba(6,182,212,0.5), transparent)',
                  }}
                  animate={{
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              )}

              <div className="flex items-center gap-4">
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                    variant="ghost"
                    size="icon"
                    className={isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}
                  >
                    {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                  </Button>
                </motion.div>

                <div>
                  <h2 className={`${isDarkMode ? 'text-white' : 'text-gray-900'} font-semibold`}>
                    {activeSection === 'chat' ? 'AI Assistant' :
                      activeSection === 'home' ? 'Dashboard Overview' :
                        navItems.find(item => item.id === activeSection)?.label}
                  </h2>
                  <p className="text-gray-400 text-xs">Real-time business intelligence</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <motion.div
                  className="px-4 py-2 bg-green-500/20 border border-green-500/30 rounded-lg relative overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                >
                  {/* Pulsing background */}
                  <motion.div
                    className="absolute inset-0 bg-green-500/10"
                    animate={{
                      opacity: [0.2, 0.4, 0.2],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                  <span className="text-green-400 text-sm font-medium relative z-10 flex items-center gap-2">
                    <motion.span
                      animate={{
                        scale: [1, 1.2, 1],
                        opacity: [1, 0.6, 1],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      ●
                    </motion.span>
                    Live
                  </span>
                </motion.div>
              </div>
            </header>

            {/* Content Area */}
            <div className="flex-1 overflow-hidden">
              {activeSection === 'home' && (
                <div className="h-full overflow-y-auto p-6">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    {/* KPI Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                      <DraggableKPI
                        id="sales"
                        title="Sales Revenue"
                        value={
                          <>
                            <span className="font-extrabold">₹</span> {(kpiData.salesRevenue / 100000).toFixed(2)}L
                          </>
                        }
                        icon={DollarSign}
                        gradient="rgba(0, 212, 255, 0.2), rgba(59, 130, 246, 0.2)"
                        index={0}
                      />
                      <DraggableKPI
                        id="outstanding"
                        title="Outstanding"
                        value={`₹${(kpiData.outstanding / 100000).toFixed(2)}L`}
                        icon={TrendingUp}
                        gradient="rgba(147, 51, 234, 0.2), rgba(236, 72, 153, 0.2)"
                        index={1}
                      />
                      <DraggableKPI
                        id="visits"
                        title="Visit Count"
                        value={kpiData.visitCount}
                        icon={Calendar}
                        gradient="rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.2)"
                        index={2}
                      />
                      <DraggableKPI
                        id="target"
                        title="Target Achievement"
                        value={`${kpiData.targetAchievement}%`}
                        icon={Target}
                        gradient="rgba(249, 115, 22, 0.2), rgba(234, 88, 12, 0.2)"
                        index={3}
                      />
                    </div>

                    {/* Analytics Preview */}
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6">
                      <AnalyticsPanel />
                    </div>
                  </motion.div>
                </div>
              )}

              {activeSection === 'my-role' && (
                <>
                  {userRole === 'salesperson' && <SalespersonDashboard />}
                  {userRole === 'branch_head' && <BranchHeadDashboard />}
                  {userRole === 'zonal_manager' && <ZonalManagerDashboard />}
                  {userRole === 'india_head' && <IndiaHeadDashboard />}
                  {userRole === 'ceo' && <CEODashboard />}
                </>
              )}

              {activeSection === 'chat' && (
                <div className="h-full">
                  <ChatInterface
                    userRole={userRole}
                    onChartGenerated={setChartData}
                  />
                </div>
              )}

              {activeSection === 'analytics' && (
                <div className="h-full">
                  <AnalyticsPanel chartData={chartData} />
                </div>
              )}

              {activeSection === 'visit-recommendations' && (
                <VisitRecommendations />
              )}

              {activeSection === 'dealers' && (
                <div className="h-full p-6 flex flex-col gap-6 overflow-hidden">
                  <ExcelDataGrid />
                </div>
              )}

              {activeSection === 'products' && (
                <div className="h-full overflow-y-auto p-6">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <div className="mb-8">
                      <h2 className="text-3xl font-bold text-white mb-2">Product Catalog</h2>
                      <p className="text-gray-400">Interactive 3D showcase of Orientbell tiles</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {products.map((product, index) => {
                        const availableDealers = dealers
                          .filter(d => d.products.includes(product.category))
                          .map(d => d.name);

                        return (
                          <Product3DTile
                            key={product.id}
                            name={product.name}
                            category={product.category}
                            price={product.price}
                            image={product.image}
                            dealers={availableDealers}
                            color={
                              index % 6 === 0 ? '#00D4FF' :
                                index % 6 === 1 ? '#9333EA' :
                                  index % 6 === 2 ? '#10B981' :
                                    index % 6 === 3 ? '#F59E0B' :
                                      index % 6 === 4 ? '#EF4444' :
                                        '#EC4899'
                            }
                            index={index}
                          />
                        );
                      })}
                    </div>
                  </motion.div>
                </div>
              )}

              {activeSection === 'reports' && (
                <div className="h-full overflow-y-auto p-6 space-y-6">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-8"
                  >
                    <h2 className="text-3xl font-bold text-white mb-2">Reports & Documentation</h2>
                    <p className="text-gray-400">Official business intelligence and data exports</p>
                  </motion.div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {reports.map((report, index) => (
                      <motion.div
                        key={report.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all group"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className={`p-3 rounded-xl bg-gradient-to-br ${report.type === 'Sales' ? 'from-green-500 to-emerald-600' :
                            report.type === 'Dealer' ? 'from-blue-500 to-indigo-600' :
                              report.type === 'Finance' ? 'from-purple-500 to-pink-600' :
                                'from-orange-500 to-red-600'
                            } shadow-lg shadow-black/20`}>
                            <FileText className="w-6 h-6 text-white" />
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${report.status === 'Ready' ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                            }`}>
                            {report.status}
                          </span>
                        </div>
                        <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-cyan-400 transition-colors">{report.title}</h3>
                        <p className="text-gray-400 text-sm mb-4 line-clamp-2">{report.description}</p>
                        <div className="flex items-center justify-between mt-auto">
                          <span className="text-gray-500 text-xs flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(report.date).toLocaleDateString()}
                          </span>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-400/10 p-0 h-auto"
                            onClick={() => setSelectedReport(report)}
                          >
                            View Report →
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Analytics Panel (visible on chat view) */}
          {activeSection === 'chat' && (
            <motion.aside
              initial={{ x: 400 }}
              animate={{ x: 0 }}
              className="w-96 bg-black/40 backdrop-blur-xl border-l border-white/10 hidden xl:block"
            >
              <AnalyticsPanel chartData={chartData} />
            </motion.aside>
          )}
        </div>
      </div>

      {/* Welcome Modal */}
      {showWelcome && (
        <WelcomeModal
          userName={userName}
          onClose={() => {
            setShowWelcome(false);
            localStorage.setItem('hasSeenWelcome', 'true');
          }}
        />
      )}

      {/* Avatar Selector Modal */}
      {showAvatarSelector && (
        <AvatarSelector
          isOpen={showAvatarSelector}
          currentAvatar={userAvatar}
          onSelect={handleAvatarSelect}
          onClose={() => setShowAvatarSelector(false)}
          userName={userName}
        />
      )}

      {/* Report Viewer Modal */}
      <AnimatePresence>
        {selectedReport && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedReport(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-2xl bg-gray-900/90 backdrop-blur-2xl border border-white/10 rounded-3xl p-8 shadow-2xl overflow-hidden"
              style={{ boxShadow: '0 0 100px rgba(6, 182, 212, 0.2)' }}
            >
              {/* Decorative Glow */}
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl" />
              <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl" />

              <div className="relative z-10">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`p-4 rounded-2xl bg-gradient-to-br ${selectedReport.type === 'Sales' ? 'from-green-500 to-emerald-600' :
                      selectedReport.type === 'Dealer' ? 'from-blue-500 to-indigo-600' :
                        selectedReport.type === 'Finance' ? 'from-purple-500 to-pink-600' :
                          'from-orange-500 to-red-600'
                      } shadow-lg shadow-black/40`}>
                      <FileText className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold text-white mb-1">{selectedReport.title}</h2>
                      <p className="text-cyan-400/80 text-sm font-medium">{selectedReport.type} Intelligence Report</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedReport(null)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-6 h-6" />
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-4">
                    <p className="text-gray-400 text-xs mb-1">Generated On</p>
                    <p className="text-white font-semibold flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4 text-cyan-400" />
                      {new Date(selectedReport.date).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  </div>
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-4">
                    <p className="text-gray-400 text-xs mb-1">Status</p>
                    <p className="text-white font-semibold flex items-center gap-2 text-sm">
                      <span className={`w-2 h-2 rounded-full ${selectedReport.status === 'Ready' ? 'bg-green-500 animate-pulse' : 'bg-yellow-500 animate-pulse'}`} />
                      {selectedReport.status}
                    </p>
                  </div>
                  <div className="bg-white/5 border border-white/5 rounded-2xl p-4">
                    <p className="text-gray-400 text-xs mb-1">Data Confidence</p>
                    <p className="text-white font-semibold flex items-center gap-2 text-sm">
                      <Sparkles className="w-4 h-4 text-yellow-400" />
                      99.8% (Verified)
                    </p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="text-gray-200 font-semibold mb-2">Executive Summary</h4>
                    <p className="text-gray-400 leading-relaxed text-sm">
                      {selectedReport.description} This report provides high-level business intelligence synthesized from current SAP and CRM data flows. It contains sensitive enterprise metrics intended for {userRole.replace('_', ' ')} level oversight.
                    </p>
                  </div>

                  <div className="p-6 bg-cyan-500/10 border border-cyan-500/20 rounded-2xl">
                    <h4 className="text-cyan-400 font-semibold mb-3 flex items-center gap-2">
                      <Bot className="w-5 h-5" />
                      OBL AI Insights
                    </h4>
                    <p className="text-gray-300 text-sm italic">
                      "Analysis indicates a strong positive correlation between visit frequency and revenue retention for this period. Recommend immediate follow-up on outstanding collections to optimize cash flow."
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex gap-4">
                  <Button
                    onClick={() => {
                      const data = generateAgingData(35);
                      downloadPDFReport(selectedReport.title, data);
                    }}
                    className="flex-1 bg-cyan-600 hover:bg-cyan-500 text-white border-none rounded-xl py-6 font-semibold shadow-lg shadow-cyan-900/40"
                  >
                    Download PDF Analysis
                  </Button>
                  <Button
                    onClick={() => {
                      const data = generateAgingData(35);
                      exportExcelData(selectedReport.title, data);
                    }}
                    className="flex-1 bg-[#1a1a24] hover:bg-[#252535] border border-white/10 text-white rounded-xl py-6 font-semibold"
                  >
                    Export Raw Data (.xlsx)
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </DndProvider>
  );
}