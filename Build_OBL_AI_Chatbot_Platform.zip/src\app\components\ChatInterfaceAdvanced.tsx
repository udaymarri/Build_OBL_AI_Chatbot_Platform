import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Mic, Sparkles, TrendingUp, Users, Package, Bot, User as UserIcon, Zap, Stars } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { aiResponseEngine, callGrokAPI } from '../utils/aiEngine';
import { getRelevantExcelContext } from '../utils/contextFilter';
import { getKPIData } from '../data/mockData';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  chart?: any;
  suggestions?: string[];
}

interface ChatInterfaceProps {
  userRole: string;
  onChartGenerated?: (data: any) => void;
}

export function ChatInterface({ userRole, onChartGenerated }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: `Hello! I'm your OBL AI Assistant powered by advanced intelligence. I can help you with sales data, visit recommendations, dealer insights, and strategic analysis. What would you like to explore?`,
      timestamp: new Date(),
      suggestions: [
        'What is my outstanding amount?',
        'Show sales growth for last 6 months',
        'Which dealer should I visit today?',
        'Show me gap selling opportunities',
      ],
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [voiceLevel, setVoiceLevel] = useState(0);
  const scrollViewportRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const finalTranscriptRef = useRef('');
  const currentTextRef = useRef('');
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const suggestedQuestions = [
    { icon: TrendingUp, text: 'Show sales trends', color: 'from-blue-500 to-cyan-500', glow: 'rgba(6, 182, 212, 0.4)' },
    { icon: Users, text: 'Dealer recommendations', color: 'from-blue-600 to-sky-500', glow: 'rgba(37, 99, 235, 0.4)' },
    { icon: Package, text: 'Gap selling opportunities', color: 'from-green-500 to-emerald-500', glow: 'rgba(16, 185, 129, 0.4)' },
    { icon: Sparkles, text: 'AI insights & predictions', color: 'from-indigo-600 to-blue-600', glow: 'rgba(79, 70, 229, 0.4)' },
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Volume monitoring logic
  useEffect(() => {
    if (isRecording) {
      const startAudioMonitoring = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          audioContextRef.current = new AudioContext();
          analyserRef.current = audioContextRef.current.createAnalyser();
          const source = audioContextRef.current.createMediaStreamSource(stream);
          source.connect(analyserRef.current);
          analyserRef.current.fftSize = 256;

          const bufferLength = analyserRef.current.frequencyBinCount;
          const dataArray = new Uint8Array(bufferLength);

          const updateVolume = () => {
            if (!analyserRef.current) return;
            analyserRef.current.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < bufferLength; i++) {
              sum += dataArray[i];
            }
            const average = sum / bufferLength;
            setVoiceLevel(average); // average will be between 0-255
            animationFrameRef.current = requestAnimationFrame(updateVolume);
          };
          updateVolume();
        } catch (err) {
          console.error("Error accessing microphone for volume meter:", err);
        }
      };

      startAudioMonitoring();
    } else {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (audioContextRef.current) audioContextRef.current.close();
      setVoiceLevel(0);
    }

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, [isRecording]);

  // Speech Recognition Logic
  useEffect(() => {
    if (isRecording) {
      finalTranscriptRef.current = input;
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        alert("Speech recognition is not supported in this browser.");
        setIsRecording(false);
        return;
      }

      const recognition = new SpeechRecognition();
      recognition.lang = 'en-IN';
      recognition.interimResults = true; // High sensitivity: show results as you speak
      recognition.continuous = true;
      recognition.maxAlternatives = 1;

      recognition.onresult = (event: any) => {
        let newlyFinalized = '';
        let currentInterim = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            newlyFinalized += event.results[i][0].transcript;
          } else {
            currentInterim += event.results[i][0].transcript;
          }
        }

        if (newlyFinalized) {
          finalTranscriptRef.current += (finalTranscriptRef.current && !finalTranscriptRef.current.endsWith(' ') ? ' ' : '') + newlyFinalized.trim();
        }

        const newText = finalTranscriptRef.current + (currentInterim && finalTranscriptRef.current && !finalTranscriptRef.current.endsWith(' ') ? ' ' : '') + currentInterim;
        currentTextRef.current = newText;
        setInput(newText);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        // Restart on no-speech or network issues to keep active
        if (event.error === 'no-speech' || event.error === 'network') {
          try { recognition.stop(); } catch (e) { }
          return;
        }
        setIsRecording(false);
      };

      recognition.onend = () => {
        // Automatically restart if still in recording mode (for low voice gap handling)
        if (isRecording) {
          if (currentTextRef.current) {
            finalTranscriptRef.current = currentTextRef.current;
          }
          setTimeout(() => {
            try { recognition.start(); } catch (e) { }
          }, 10); // More aggressive restart
        }
      };

      try {
        recognition.start();
      } catch (e) {
        console.error("Recognition start attempt failed:", e);
      }

      return () => {
        recognition.stop();
      };
    }
  }, [isRecording]);

  const handleSend = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: messageText,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    setTimeout(async () => {
      let aiText = '';
      let chatResponse = aiResponseEngine(messageText, userRole);

      try {
        const { sapMaterials, sapSalesOrders, salesData, dealers, schemes, reports } = await import('../data/mockData');
        const { excelData } = await import('../data/excelData');

        // Filter the huge excel database to only send relevant rows
        const filteredExcelContext = getRelevantExcelContext(messageText, excelData);

        const contextData = JSON.stringify({
          kpiData: getKPIData(userRole),
          materials: sapMaterials,
          orders: sapSalesOrders,
          salesData: salesData,
          dealers: dealers,
          schemes: schemes,
          reports: reports,
          excelDatabase: filteredExcelContext
        });
        const grokAnswer = await callGrokAPI(messageText, userRole, contextData);
        if (grokAnswer) {
          aiText = grokAnswer;
        }
      } catch (e: any) {
        console.error("Grok API call failed.", e);
        aiText = "API Connection Error: " + (e.message || "Invalid Key or Rate Limit reached.");
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: aiText || chatResponse.text,
        timestamp: new Date(),
        chart: chatResponse.chart,
        suggestions: chatResponse.suggestions,
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);

      if (chatResponse.chart && onChartGenerated) {
        onChartGenerated(chatResponse.chart);
      }
    }, 500);
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSend(suggestion);
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-transparent to-black/5 overflow-hidden relative">
      {/* Ambient background particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/30 rounded-full"
            initial={{
              x: Math.random() * 100 + '%',
              y: Math.random() * 100 + '%',
            }}
            animate={{
              y: [Math.random() * 100 + '%', Math.random() * 100 + '%'],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Quick Actions */}
      <div className="p-4 border-b border-white/10 flex-shrink-0 bg-black/20 backdrop-blur-xl relative overflow-hidden">
        {/* Animated gradient border */}
        <motion.div
          className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-500 to-transparent"
          animate={{
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        />

        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {suggestedQuestions.map((sq, index) => (
            <motion.button
              key={index}
              onClick={() => handleSuggestionClick(sq.text)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r ${sq.color} text-white whitespace-nowrap font-medium shadow-lg backdrop-blur-sm relative overflow-hidden group`}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              style={{
                boxShadow: `0 10px 30px ${sq.glow}`,
              }}
            >
              {/* Shimmer effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                animate={{
                  x: ['-200%', '200%'],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 1,
                }}
              />

              <sq.icon className="w-4 h-4 relative z-10" />
              <span className="relative z-10 text-sm">{sq.text}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-cyan-500/20 scrollbar-track-transparent">
        <AnimatePresence mode="popLayout">
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-3 max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                {/* Avatar */}
                <motion.div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center relative overflow-hidden flex-shrink-0 ${message.type === 'user'
                    ? 'bg-gradient-to-br from-purple-500 to-pink-500'
                    : 'bg-gradient-to-br from-cyan-500 to-blue-600'
                    }`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  style={{
                    boxShadow: message.type === 'user'
                      ? '0 10px 40px rgba(168, 85, 247, 0.4)'
                      : '0 10px 40px rgba(6, 182, 212, 0.4)',
                  }}
                >
                  {/* Animated background */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent"
                    animate={{
                      rotate: [0, 360],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />

                  {message.type === 'user' ? (
                    <UserIcon className="w-5 h-5 text-white relative z-10" />
                  ) : (
                    <Bot className="w-5 h-5 text-white relative z-10" />
                  )}

                  {/* Glow effect */}
                  <motion.div
                    className={`absolute inset-0 ${message.type === 'user'
                      ? 'bg-gradient-to-br from-purple-500 to-pink-500'
                      : 'bg-gradient-to-br from-cyan-500 to-blue-600'
                      } blur-xl opacity-50`}
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0.5, 0.7, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                    }}
                  />
                </motion.div>

                {/* Message Bubble */}
                <div className="flex-1">
                  <motion.div
                    className={`relative rounded-2xl p-4 backdrop-blur-xl ${message.type === 'user'
                      ? 'bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30'
                      : 'bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20'
                      }`}
                    whileHover={{ scale: 1.02 }}
                    style={{
                      boxShadow: message.type === 'user'
                        ? '0 8px 32px rgba(168, 85, 247, 0.2)'
                        : '0 8px 32px rgba(6, 182, 212, 0.2)',
                    }}
                  >
                    {/* Shine effect on hover */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent rounded-2xl"
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 0.6 }}
                    />

                    <p className="text-white/90 text-sm leading-relaxed relative z-10 whitespace-pre-wrap">
                      {message.content}
                    </p>

                    {/* Timestamp */}
                    <p className="text-gray-400 text-xs mt-2 relative z-10">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>

                    {/* Suggestions */}
                    {message.suggestions && message.suggestions.length > 0 && (
                      <div className="mt-4 space-y-2 relative z-10">
                        <p className="text-gray-400 text-xs flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          Suggested questions:
                        </p>
                        {message.suggestions.map((suggestion, i) => (
                          <motion.button
                            key={i}
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="block w-full text-left px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-sm text-gray-300 transition-all"
                            whileHover={{ x: 4, backgroundColor: 'rgba(255, 255, 255, 0.15)' }}
                            whileTap={{ scale: 0.98 }}
                          >
                            {suggestion}
                          </motion.button>
                        ))}
                      </div>
                    )}
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center relative overflow-hidden">
              <Bot className="w-5 h-5 text-white relative z-10" />
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-600 blur-xl opacity-50"
                animate={{
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                }}
              />
            </div>

            <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-2xl p-4 backdrop-blur-xl">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 bg-cyan-400 rounded-full"
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.3, 1, 0.3],
                    }}
                    transition={{
                      duration: 1,
                      repeat: Infinity,
                      delay: i * 0.2,
                    }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-white/10 bg-black/20 backdrop-blur-xl relative overflow-hidden">
        {/* Animated gradient border */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-purple-500 to-transparent"
          animate={{
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        />

        <div className="flex gap-3">
          {/* Voice Input */}
          <motion.button
            onClick={() => setIsRecording(!isRecording)}
            className={`p-3 rounded-xl backdrop-blur-sm transition-all relative overflow-hidden ${isRecording
              ? 'bg-gradient-to-br from-red-500 to-pink-500 shadow-lg shadow-red-500/50'
              : 'bg-white/5 hover:bg-white/10 border border-white/10'
              }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isRecording && (
              <motion.div
                className="absolute inset-0 bg-red-500/30"
                animate={{
                  scale: [1, 2, 1],
                  opacity: [0.5, 0, 0.5],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                }}
              />
            )}

            {/* Volume Meter Visualizer */}
            {isRecording && (
              <div className="absolute inset-0 flex items-center justify-around px-1 pointer-events-none">
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="w-1 bg-white/60 rounded-full"
                    animate={{
                      height: [
                        '4px',
                        `${Math.max(4, (voiceLevel / 255) * 20 * (1 + Math.random()))}px`,
                        '4px'
                      ]
                    }}
                    transition={{
                      duration: 0.1,
                      repeat: Infinity,
                    }}
                  />
                ))}
              </div>
            )}

            <Mic className={`w-5 h-5 relative z-10 ${isRecording ? 'text-white' : 'text-gray-400'}`} />
          </motion.button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask me anything about your business..."
              className="w-full bg-white/5 border-white/10 text-white placeholder:text-gray-400 rounded-xl px-4 py-3 backdrop-blur-sm focus:bg-white/10 focus:border-cyan-500/50 transition-all"
              style={{
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.2)',
              }}
            />

            {/* AI indicator */}
            <motion.div
              className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-cyan-400 text-xs"
              animate={{
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            >
              <Sparkles className="w-3 h-3" />
              <span>AI</span>
            </motion.div>
          </div>

          {/* Send Button */}
          <motion.button
            onClick={() => handleSend()}
            disabled={!input.trim()}
            className={`p-3 rounded-xl backdrop-blur-sm relative overflow-hidden ${input.trim()
              ? 'bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/50'
              : 'bg-white/5 border border-white/10 cursor-not-allowed'
              }`}
            whileHover={input.trim() ? { scale: 1.05 } : {}}
            whileTap={input.trim() ? { scale: 0.95 } : {}}
          >
            {input.trim() && (
              <>
                {/* Shimmer effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  animate={{
                    x: ['-200%', '200%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 1,
                  }}
                />

                {/* Glow */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-cyan-500 to-blue-600 blur-xl opacity-50"
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                />
              </>
            )}

            <Send className={`w-5 h-5 relative z-10 ${input.trim() ? 'text-white' : 'text-gray-400'}`} />
          </motion.button>
        </div>

        {/* AI Status */}
        <motion.div
          className="mt-2 flex items-center justify-center gap-2 text-xs text-gray-500"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          >
            <Zap className="w-3 h-3 text-cyan-400" />
          </motion.div>
          <span>Powered by Advanced AI Intelligence</span>
        </motion.div>
      </div>
    </div>
  );
}