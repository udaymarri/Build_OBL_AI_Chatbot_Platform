import { callGrokAPI } from './src/app/utils/aiEngine.ts';
import { salesData, dealers, getKPIData, getSalesRecommendations, getVisitRecommendations, schemes, sapMaterials, sapSalesOrders } from './src/app/data/mockData.ts';

async function test() {
    console.log("Starting test...");
    const userRole = 'salesperson';
    const query = 'What is the top selling product and which dealer has the most outstanding amount?';

    const contextData = JSON.stringify({
        kpiData: getKPIData(userRole),
        materials: sapMaterials,
        orders: sapSalesOrders,
        salesData: salesData,
        dealers: dealers,
        schemes: schemes,
    });

    try {
        const response = await callGrokAPI(query, userRole, contextData);
        console.log("AI Response:", response);
    } catch (err) {
        console.error("Error:", err);
    }
}

test();
