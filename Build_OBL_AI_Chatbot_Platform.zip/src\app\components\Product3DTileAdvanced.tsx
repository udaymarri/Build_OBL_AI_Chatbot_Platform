import { motion } from 'framer-motion';
import { memo, useState } from 'react';
import { ExternalLink, Eye, Star } from 'lucide-react';

interface Product3DTileProps {
  name: string;
  category: string;
  price: number;
  color: string;
  index: number;
  image?: string;
  dealers?: string[];
}

export const Product3DTile = memo(function Product3DTile({ name, category, price, color, index, image, dealers }: Product3DTileProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        delay: index * 0.08,
        type: "spring",
        stiffness: 100,
        damping: 15
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative overflow-hidden rounded-3xl bg-black/40 backdrop-blur-2xl border border-white/10 p-6 group"
      whileHover={{ y: -12, scale: 1.02 }}
      style={{
        boxShadow: isHovered
          ? `0 30px 80px ${color}40, 0 0 60px ${color}30, inset 0 0 40px rgba(255, 255, 255, 0.05)`
          : `0 15px 40px ${color}20, 0 0 30px ${color}15`,
        transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
      }}
    >
      {/* Multi-layer glassmorphism */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent backdrop-blur-xl" />
      <div className="absolute inset-0 bg-gradient-to-tl from-black/20 to-transparent" />

      {/* Animated border glow */}
      <motion.div
        className="absolute inset-0 rounded-3xl border"
        style={{
          borderColor: color + '40',
        }}
        animate={{
          borderColor: isHovered ? color + '80' : color + '40',
        }}
        transition={{ duration: 0.3 }}
      />

      {/* Corner shine effects */}
      <motion.div
        className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30"
        style={{ backgroundColor: color }}
        transition={{ duration: 0.4 }}
      />

      {/* Enhanced 3D Tile with more dramatic effects */}
      <div className="w-full h-48 mb-6 flex items-center justify-center perspective-1000 relative">
        <motion.div
          className="w-40 h-40 relative preserve-3d"
          animate={{
            rotateY: isHovered ? 360 : 0,
            rotateX: isHovered ? 15 : 0,
          }}
          transition={{
            rotateY: { duration: 2, ease: "easeInOut" },
            rotateX: { duration: 0.3 }
          }}
          whileHover={{
            scale: 1.15,
            transition: { duration: 0.3 }
          }}
        >
          {/* Main tile face with enhanced effects */}
          <motion.div
            className="absolute inset-0 rounded-xl shadow-2xl overflow-hidden"
            style={{
              transform: 'translateZ(15px)',
              backgroundColor: color,
              backgroundImage: image ? `url('${image}')` : undefined,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              boxShadow: `
                0 0 40px ${color}80,
                inset 0 0 30px rgba(255, 255, 255, 0.2),
                inset -10px -10px 30px rgba(0, 0, 0, 0.3),
                inset 10px 10px 30px rgba(255, 255, 255, 0.1)
              `
            }}
          >
            {/* Glossy shine effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-transparent rounded-xl"
              animate={{
                opacity: isHovered ? 0.6 : 0.3,
              }}
            />

            {/* Pattern overlay */}
            <div
              className="absolute inset-0 rounded-xl opacity-20"
              style={{
                backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.1) 10px, rgba(255,255,255,0.1) 20px)',
              }}
            />
          </motion.div>

          {/* Back face */}
          <div
            className="absolute inset-0 rounded-xl opacity-90"
            style={{
              transform: 'rotateY(180deg) translateZ(15px)',
              backgroundColor: color,
              boxShadow: `0 0 30px ${color}60`
            }}
          />

          {/* Side faces with gradients */}
          <div
            className="absolute inset-0 rounded-xl"
            style={{
              transform: 'rotateY(90deg) translateZ(15px)',
              background: `linear-gradient(to bottom, ${color}, ${color}80)`,
              opacity: 0.7
            }}
          />
          <div
            className="absolute inset-0 rounded-xl"
            style={{
              transform: 'rotateY(-90deg) translateZ(15px)',
              background: `linear-gradient(to bottom, ${color}, ${color}80)`,
              opacity: 0.7
            }}
          />

          {/* Top and bottom faces */}
          <div
            className="absolute inset-0 rounded-xl"
            style={{
              transform: 'rotateX(90deg) translateZ(15px)',
              background: `linear-gradient(to right, ${color}90, ${color})`,
              opacity: 0.6
            }}
          />
          <div
            className="absolute inset-0 rounded-xl"
            style={{
              transform: 'rotateX(-90deg) translateZ(15px)',
              background: `linear-gradient(to right, ${color}, ${color}90)`,
              opacity: 0.6
            }}
          />

          {/* Floating glow around tile */}
          <motion.div
            className="absolute inset-0 rounded-xl blur-2xl"
            style={{ backgroundColor: color }}
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </motion.div>

        {/* Floating particles around tile */}
        {isHovered && (
          <>
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: color }}
                initial={{
                  x: 0,
                  y: 0,
                  opacity: 0,
                }}
                animate={{
                  x: Math.cos((i / 8) * Math.PI * 2) * 80,
                  y: Math.sin((i / 8) * Math.PI * 2) * 80,
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: i * 0.1,
                }}
              />
            ))}
          </>
        )}
      </div>

      {/* Product Info with enhanced styling */}
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-1">{name}</h3>
            <p className="text-sm text-gray-400 flex items-center gap-1">
              {category}
              {/* Rating stars */}
              <span className="ml-2 flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                ))}
              </span>
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              <span className="font-extrabold">₹</span>{price}
            </span>
            <span className="text-sm text-gray-500 ml-2">per sq ft</span>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2">
          <motion.button
            onClick={() => window.open('https://www.orientbell.com/tiles/floor-tiles', '_blank')}
            className="flex-1 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium shadow-lg relative overflow-hidden group/btn"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            style={{
              boxShadow: `0 10px 30px ${color}40`,
            }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
              animate={{
                x: ['-200%', '200%'],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1,
              }}
            />
            <span className="relative z-10 flex items-center justify-center gap-2">
              <ExternalLink className="w-4 h-4" />
              Explore Collection
            </span>
          </motion.button>

          <motion.button
            className="px-4 py-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20 transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Eye className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Dealers display */}
        {dealers && dealers.length > 0 && (
          <div className="mt-4 pt-3 border-t border-white/10">
            <p className="text-xs text-gray-400 mb-2 font-medium">Available at Dealers</p>
            <div className="flex flex-wrap gap-1.5">
              {dealers.map((dealer, i) => (
                <span key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded-md text-xs text-gray-300">
                  {dealer}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Animated gradient overlay */}
      <motion.div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none rounded-3xl"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${color}15, transparent 70%)`,
        }}
        transition={{ duration: 0.4 }}
      />

      {/* Multiple layer glows */}
      <motion.div
        className="absolute -top-20 -right-20 w-40 h-40 rounded-full blur-3xl opacity-0 group-hover:opacity-30"
        style={{ backgroundColor: color }}
        transition={{ duration: 0.4 }}
      />

      <motion.div
        className="absolute -bottom-16 -left-16 w-32 h-32 rounded-full blur-3xl"
        style={{ backgroundColor: color }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
        }}
      />
    </motion.div>
  );
});
