// Role-specific features and data

export interface TeamMember {
  id: string;
  name: string;
  achievement: number;
  sales: number;
  visits: number;
  territory: string;
  status: 'active' | 'inactive';
}

export interface Branch {
  id: string;
  name: string;
  location: string;
  sales: number;
  target: number;
  teamSize: number;
  rating: number;
}

export interface Zone {
  id: string;
  name: string;
  branches: number;
  sales: number;
  target: number;
  achievement: number;
  manager: string;
}

export interface DailyVisit {
  id: string;
  dealerName: string;
  location: string;
  time: string;
  priority: 'high' | 'medium' | 'low';
  distance: number;
  purpose: string;
  status: 'completed' | 'pending' | 'scheduled';
}

export interface Commission {
  month: string;
  baseSalary: number;
  incentive: number;
  bonus: number;
  total: number;
}

// SALESPERSON DATA
export const salespersonTeamData = {
  myTarget: 5000000,
  achieved: 4200000,
  daysLeft: 24,
  averageRequired: 33333,
  commission: {
    current: 42000,
    projected: 50000,
  },
};

export const dailyVisitPlan: DailyVisit[] = [
  {
    id: 'DV001',
    dealerName: 'Marble Palace Tiles',
    location: 'Andheri West',
    time: '10:00 AM',
    priority: 'high',
    distance: 3.2,
    purpose: 'Outstanding Collection - ₹8.5L',
    status: 'pending',
  },
  {
    id: 'DV002',
    dealerName: 'Elite Surfaces Pvt Ltd',
    location: 'Bandra East',
    time: '12:30 PM',
    priority: 'high',
    distance: 5.8,
    purpose: 'New Product Demo - Designer Series',
    status: 'pending',
  },
  {
    id: 'DV003',
    dealerName: 'Crystal Tiles Co.',
    location: 'Goregaon',
    time: '03:00 PM',
    priority: 'medium',
    distance: 8.5,
    purpose: 'Follow-up on Festival Scheme',
    status: 'scheduled',
  },
  {
    id: 'DV004',
    dealerName: 'Architect XYZ',
    location: 'Powai',
    time: '05:00 PM',
    priority: 'high',
    distance: 6.2,
    purpose: 'New Lead - Commercial Project',
    status: 'scheduled',
  },
];

export const commissionHistory: Commission[] = [
  { month: 'September', baseSalary: 40000, incentive: 18000, bonus: 5000, total: 63000 },
  { month: 'October', baseSalary: 40000, incentive: 22000, bonus: 8000, total: 70000 },
  { month: 'November', baseSalary: 40000, incentive: 16000, bonus: 3000, total: 59000 },
  { month: 'December', baseSalary: 40000, incentive: 28000, bonus: 12000, total: 80000 },
  { month: 'January', baseSalary: 40000, incentive: 24000, bonus: 6000, total: 70000 },
  { month: 'February', baseSalary: 40000, incentive: 32000, bonus: 10000, total: 82000 },
];

// BRANCH HEAD DATA
export const branchTeamMembers: TeamMember[] = [
  {
    id: 'SP001',
    name: 'Rajesh Kumar',
    achievement: 87,
    sales: 4200000,
    visits: 24,
    territory: 'Mumbai West',
    status: 'active',
  },
  {
    id: 'SP002',
    name: 'Amit Sharma',
    achievement: 95,
    sales: 5800000,
    visits: 28,
    territory: 'Mumbai Central',
    status: 'active',
  },
  {
    id: 'SP003',
    name: 'Priya Singh',
    achievement: 78,
    sales: 3900000,
    visits: 21,
    territory: 'Mumbai East',
    status: 'active',
  },
  {
    id: 'SP004',
    name: 'Vikram Patel',
    achievement: 102,
    sales: 6200000,
    visits: 32,
    territory: 'Navi Mumbai',
    status: 'active',
  },
  {
    id: 'SP005',
    name: 'Sneha Desai',
    achievement: 68,
    sales: 3400000,
    visits: 18,
    territory: 'Thane',
    status: 'active',
  },
  {
    id: 'SP006',
    name: 'Rahul Mehta',
    achievement: 91,
    sales: 5000000,
    visits: 26,
    territory: 'Mumbai South',
    status: 'active',
  },
];

export const branchInventory = [
  { category: 'Marble Tiles', stock: 45000, minLevel: 20000, status: 'healthy' },
  { category: 'Ceramic Tiles', stock: 12000, minLevel: 15000, status: 'low' },
  { category: 'Vitrified Tiles', stock: 38000, minLevel: 25000, status: 'healthy' },
  { category: 'Wall Tiles', stock: 8000, minLevel: 10000, status: 'low' },
  { category: 'Designer Tiles', stock: 15000, minLevel: 8000, status: 'healthy' },
  { category: 'Parking Tiles', stock: 22000, minLevel: 12000, status: 'healthy' },
];

// ZONAL MANAGER DATA
export const zoneBranches: Branch[] = [
  {
    id: 'B001',
    name: 'Mumbai Branch',
    location: 'Mumbai',
    sales: 28500000,
    target: 31000000,
    teamSize: 6,
    rating: 4.2,
  },
  {
    id: 'B002',
    name: 'Pune Branch',
    location: 'Pune',
    sales: 22000000,
    target: 24000000,
    teamSize: 5,
    rating: 4.5,
  },
  {
    id: 'B003',
    name: 'Surat Branch',
    location: 'Surat',
    sales: 18500000,
    target: 20000000,
    teamSize: 4,
    rating: 4.0,
  },
  {
    id: 'B004',
    name: 'Ahmedabad Branch',
    location: 'Ahmedabad',
    sales: 13000000,
    target: 17000000,
    teamSize: 3,
    rating: 3.5,
  },
];

export const zoneMarketData = [
  { city: 'Mumbai', marketShare: 18.5, growth: 12, competitors: 15 },
  { city: 'Pune', marketShare: 22.3, growth: 15, competitors: 12 },
  { city: 'Surat', marketShare: 15.8, growth: 8, competitors: 10 },
  { city: 'Ahmedabad', marketShare: 12.2, growth: 5, competitors: 14 },
];

// INDIA HEAD DATA
export const regionalZones: Zone[] = [
  {
    id: 'Z001',
    name: 'West Zone',
    branches: 4,
    sales: 82000000,
    target: 92000000,
    achievement: 89,
    manager: 'Amit Patel',
  },
  {
    id: 'Z002',
    name: 'North Zone',
    branches: 6,
    sales: 125000000,
    target: 135000000,
    achievement: 93,
    manager: 'Neha Gupta',
  },
  {
    id: 'Z003',
    name: 'South Zone',
    branches: 8,
    sales: 158000000,
    target: 165000000,
    achievement: 96,
    manager: 'Karthik Reddy',
  },
  {
    id: 'Z004',
    name: 'East Zone',
    branches: 5,
    sales: 85000000,
    target: 98000000,
    achievement: 87,
    manager: 'Arpita Das',
  },
];

export const statePerformance = [
  { state: 'Maharashtra', sales: 95000000, growth: 14, dealers: 245 },
  { state: 'Karnataka', sales: 78000000, growth: 18, dealers: 198 },
  { state: 'Tamil Nadu', sales: 82000000, growth: 12, dealers: 212 },
  { state: 'Gujarat', sales: 65000000, growth: 10, dealers: 165 },
  { state: 'Delhi NCR', sales: 88000000, growth: 16, dealers: 188 },
  { state: 'West Bengal', sales: 42000000, growth: 8, dealers: 112 },
];

export const productCategoryNational = [
  { category: 'Vitrified Tiles', sales: 180000000, share: 35, growth: 15 },
  { category: 'Ceramic Tiles', sales: 145000000, share: 28, growth: 10 },
  { category: 'Marble Tiles', sales: 95000000, share: 18, growth: 20 },
  { category: 'Designer Tiles', sales: 52000000, share: 10, growth: 25 },
  { category: 'Wall Tiles', sales: 35000000, share: 7, growth: 8 },
  { category: 'Parking Tiles', sales: 18000000, share: 2, growth: 5 },
];

// CEO DATA
export const executiveSummary = {
  totalRevenue: 1250000000,
  yearlyGrowth: 18.5,
  marketShare: 24.5,
  profitMargin: 22.8,
  totalDealers: 1250,
  totalEmployees: 850,
  branches: 28,
  zones: 4,
};

export const financialMetrics = [
  { quarter: 'Q1 FY26', revenue: 285000000, profit: 65000000, margin: 22.8 },
  { quarter: 'Q2 FY26', revenue: 298000000, profit: 68000000, margin: 22.8 },
  { quarter: 'Q3 FY26', revenue: 325000000, profit: 75000000, margin: 23.1 },
  { quarter: 'Q4 FY26', revenue: 342000000, profit: 78000000, margin: 22.8 },
];

export const competitiveAnalysis = [
  { company: 'Orientbell (Us)', marketShare: 24.5, growth: 18.5, revenue: 1250 },
  { company: 'Kajaria Ceramics', marketShare: 28.2, growth: 12.3, revenue: 1450 },
  { company: 'Somany Ceramics', marketShare: 15.8, growth: 10.5, revenue: 820 },
  { company: 'Nitco Tiles', marketShare: 12.3, growth: 8.2, revenue: 640 },
  { company: 'H&R Johnson', marketShare: 10.5, growth: 14.8, revenue: 545 },
  { company: 'Others', marketShare: 8.7, growth: 7.5, revenue: 450 },
];

export const strategicInitiatives = [
  {
    id: 'SI001',
    title: 'Digital Transformation',
    status: 'On Track',
    completion: 75,
    impact: 'High',
    deadline: '2026-06-30',
  },
  {
    id: 'SI002',
    title: 'Market Expansion - Tier 2 Cities',
    status: 'In Progress',
    completion: 45,
    impact: 'High',
    deadline: '2026-09-30',
  },
  {
    id: 'SI003',
    title: 'Premium Product Line Launch',
    status: 'Planning',
    completion: 20,
    impact: 'Medium',
    deadline: '2026-12-31',
  },
  {
    id: 'SI004',
    title: 'Sustainability Initiative',
    status: 'On Track',
    completion: 60,
    impact: 'Medium',
    deadline: '2026-08-31',
  },
];

// Function to get role-specific features
export const getRoleFeatures = (role: string) => {
  switch (role) {
    case 'salesperson':
      return {
        primary: 'Daily Visit Planner',
        features: [
          'Route-optimized visit schedule',
          'Commission calculator',
          'Dealer relationship tracker',
          'Product recommendation engine',
          'Outstanding collection alerts',
        ],
      };
    case 'branch_head':
      return {
        primary: 'Team Performance Dashboard',
        features: [
          'Salesperson comparison charts',
          'Territory allocation map',
          'Branch inventory management',
          'Discount approval workflow',
          'Team attendance tracking',
        ],
      };
    case 'zonal_manager':
      return {
        primary: 'Multi-Branch Analytics',
        features: [
          'Branch comparison matrix',
          'Zone-wide market heatmap',
          'Stock movement tracker',
          'Regional trend analysis',
          'Resource allocation planner',
        ],
      };
    case 'india_head':
      return {
        primary: 'National Performance Overview',
        features: [
          'State-wise sales dashboard',
          'Zone head performance review',
          'Market share tracking',
          'Product category analytics',
          'Strategic planning tools',
        ],
      };
    case 'ceo':
      return {
        primary: 'Executive Command Center',
        features: [
          'Board-ready insights',
          'Competitive intelligence',
          'Financial overview',
          'Strategic initiatives tracker',
          'Predictive analytics',
        ],
      };
    default:
      return {
        primary: 'Dashboard',
        features: [],
      };
  }
};
