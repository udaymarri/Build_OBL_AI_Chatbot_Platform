import { motion } from 'motion/react';

export function FloatingShapes3D() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Floating Cubes */}
      <motion.div
        className="absolute w-20 h-20"
        style={{
          top: '10%',
          left: '15%',
          perspective: '1000px',
        }}
        animate={{
          y: [0, -30, 0],
          rotateX: [0, 360],
          rotateY: [0, 360],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: 'linear',
        }}
      >
        <div
          className="w-full h-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-purple-500/30"
          style={{
            transform: 'rotateX(45deg) rotateY(45deg)',
            boxShadow: '0 0 40px rgba(168, 85, 247, 0.4)',
          }}
        />
      </motion.div>

      <motion.div
        className="absolute w-16 h-16"
        style={{
          top: '70%',
          right: '20%',
          perspective: '1000px',
        }}
        animate={{
          y: [0, 40, 0],
          rotateX: [0, -360],
          rotateZ: [0, 360],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: 'linear',
        }}
      >
        <div
          className="w-full h-full bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-sm border border-blue-500/30"
          style={{
            transform: 'rotateX(30deg) rotateZ(30deg)',
            boxShadow: '0 0 40px rgba(6, 182, 212, 0.4)',
          }}
        />
      </motion.div>

      {/* Floating Spheres */}
      <motion.div
        className="absolute w-24 h-24 rounded-full bg-gradient-to-br from-purple-600/30 to-pink-600/30 backdrop-blur-md border border-purple-500/40"
        style={{
          top: '20%',
          right: '10%',
          boxShadow: '0 0 60px rgba(168, 85, 247, 0.5), inset 0 0 30px rgba(168, 85, 247, 0.2)',
        }}
        animate={{
          y: [0, -50, 0],
          x: [0, 20, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <motion.div
        className="absolute w-32 h-32 rounded-full bg-gradient-to-br from-cyan-600/30 to-blue-600/30 backdrop-blur-md border border-cyan-500/40"
        style={{
          bottom: '15%',
          left: '10%',
          boxShadow: '0 0 60px rgba(6, 182, 212, 0.5), inset 0 0 30px rgba(6, 182, 212, 0.2)',
        }}
        animate={{
          y: [0, 40, 0],
          x: [0, -30, 0],
          scale: [1, 1.15, 1],
        }}
        transition={{
          duration: 17,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Wireframe Shapes */}
      <motion.div
        className="absolute"
        style={{
          top: '50%',
          right: '5%',
          width: '150px',
          height: '150px',
        }}
        animate={{
          rotate: [0, 360],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'linear',
        }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <defs>
            <linearGradient id="wireframeGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06B6D4" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0.6" />
            </linearGradient>
          </defs>
          <polygon
            points="50,10 90,30 90,70 50,90 10,70 10,30"
            fill="none"
            stroke="url(#wireframeGrad1)"
            strokeWidth="0.5"
            opacity="0.6"
          />
          <circle cx="50" cy="10" r="2" fill="#06B6D4" opacity="0.8" />
          <circle cx="90" cy="30" r="2" fill="#8B5CF6" opacity="0.8" />
          <circle cx="90" cy="70" r="2" fill="#06B6D4" opacity="0.8" />
          <circle cx="50" cy="90" r="2" fill="#8B5CF6" opacity="0.8" />
          <circle cx="10" cy="70" r="2" fill="#06B6D4" opacity="0.8" />
          <circle cx="10" cy="30" r="2" fill="#8B5CF6" opacity="0.8" />
        </svg>
      </motion.div>

      <motion.div
        className="absolute"
        style={{
          bottom: '30%',
          left: '5%',
          width: '120px',
          height: '120px',
        }}
        animate={{
          rotate: [0, -360],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: 'linear',
        }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <defs>
            <linearGradient id="wireframeGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#EC4899" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.6" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="40" fill="none" stroke="url(#wireframeGrad2)" strokeWidth="0.5" opacity="0.6" />
          <circle cx="50" cy="50" r="30" fill="none" stroke="url(#wireframeGrad2)" strokeWidth="0.5" opacity="0.6" />
          <circle cx="50" cy="50" r="20" fill="none" stroke="url(#wireframeGrad2)" strokeWidth="0.5" opacity="0.6" />
          <line x1="50" y1="10" x2="50" y2="90" stroke="url(#wireframeGrad2)" strokeWidth="0.5" opacity="0.4" />
          <line x1="10" y1="50" x2="90" y2="50" stroke="url(#wireframeGrad2)" strokeWidth="0.5" opacity="0.4" />
        </svg>
      </motion.div>
    </div>
  );
}